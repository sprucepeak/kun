/**
 * @Author: spruce
 * @Date: 2024-03-28 16:57
 * @Desc: 服务入口文件
 */

package main

import (
	"flag"

	"api/cmd/server/wire"
)

// @title api 项目
// @version 1.0
// @description 描述信息
// @contact.name spruce
// @host localhost:9009
func main() {
	var envConf = flag.String("conf", "configs/dev.yml", "config path, eg: -conf ./configs/dev.yml")
	flag.Parse()

	app, err := wire.WireApp(*envConf)
	if err != nil {
		panic(err)
	}
	if err = app.Start(); err != nil {
		panic(err)
	}
	app.AwaitSignal()
}
