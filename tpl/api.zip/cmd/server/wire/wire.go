//go:build wireinject
// +build wireinject

package wire

import (
	"api/internal/conf"
	"api/internal/handler"
	"api/internal/repository"
	"api/internal/repository/db"
	"api/internal/router"
	"api/internal/service"
	"api/pkg/token"
	"api/pkg/xdb"
	"api/pkg/xlog"
	"api/pkg/xredis"
	"api/pkg/xserver"
	xhttp "api/pkg/xserver/http"

	"github.com/google/wire"
	"github.com/redis/go-redis/v9"
)

// 依赖注入构造 Web 应用声明函数
func WireApp(env string) (*xserver.Server, error) {
	panic(wire.Build(
		// ====配置,日志,数据库链接等====
		conf.ProviderSet,
		xlog.New,

		xdb.New,
		xredis.New,
		wire.Bind(new(redis.UniversalClient), new(*xredis.Client)),

		db.NewConn,

		// token 单例:http 装配层(WriteAuth/路由)与 service 层共用同一实例,
		// 保证黑名单/轮换全局生效。
		token.NewJwt,

		// app 装配 gin 引擎 + 资源 closer
		NewHttp,
		wire.FieldsOf(new(*Assembly), "Engine", "Closer"),

		xhttp.New,

		repository.WireServerSet,
		service.WireServerSet,
		handler.WireServerSet,
		router.WireServerSet,

		xserver.New,
	))
}
