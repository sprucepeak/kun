/**
 * @Author: spruce
 * @Date: 2024-08-14
 * @Desc: HTTP 应用装配层
 *
 * 作为 Composition Root，在 cmd/server/wire 中完成 gin 引擎与各层业务组件（中间件/JWT/限流/路由）的组装，
 * 并注册资源关闭器，返回组装好的 *gin.Engine 与统一的资源关闭器 *xserver.Closer。
 *
 * jwt 由 wire 注入(与 service 层共用同一单例,保证黑名单/轮换全局生效)。
 */

package wire

import (
	"context"
	"time"

	"api/internal/conf"
	"api/internal/global"
	"api/internal/handler"
	"api/internal/middleware"
	"api/internal/router"
	"api/pkg/token"
	"api/pkg/validator"
	"api/pkg/xconfig"
	"api/pkg/xdb"
	"api/pkg/xhttp"
	"api/pkg/xlog"
	"api/pkg/xredis"
	"api/pkg/xserver"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
)

// Assembly 装配产物。
type Assembly struct {
	Engine *gin.Engine
	// Closer 聚合进程退出时需回收的全部资源(db/redis/tracer/xlog),
	// 交给 http.Server 在 Stop 时按 LIFO 统一关闭。
	Closer *xserver.Closer
}

// NewHttp 装配 http 引擎并注册资源关闭器:
// gin 模式、中间件、JWT、限流、路由,以及 db/redis/tracer/xlog 的回收。
// jwt 由 wire 注入,与 service 层共用同一实例。
func NewHttp(
	c *conf.Container,
	log *xlog.Logger,
	db *xdb.Client,
	redis *xredis.Client,
	jwt *token.Jwt,
	hdl *handler.Ctx,
	rtrs []router.Router,
) (*Assembly, error) {
	// 注册配置更新回调：热重载日志与 Token
	c.OnUpdate(func(newConf *conf.Conf) {
		if err := xlog.Reload(newConf.Log); err != nil {
			xlog.Error(context.Background(), "[xlog] 日志配置热更新失败", err)
		}
		if jwt != nil {
			if err := jwt.Reload(newConf.Token); err != nil {
				xlog.Error(context.Background(), "[jwt] Token配置热更新校验失败", err)
			} else {
				xlog.Info(context.Background(), "[jwt] Token配置热更新成功生效")
			}
		}
	})

	// 初始化校验器与中文翻译器
	validator.New("zh")

	// 显式装配 HTTP 层业务错误码字典与核心默认码
	xhttp.RegisterCodeLookup(global.Msg)
	xhttp.SetDefaultCodes(global.Unauthorized, global.NotFoundPath, global.BusinessError)

	// 在创建引擎前统一设置 gin 全局模式与输出,避免 gin.New() 先于 SetMode,
	// 也避免多 server 实例对全局 DefaultWriter 的重复覆盖。
	xserver.InitGinMode(c.Env)
	eng := gin.New()
	_ = eng.SetTrustedProxies(nil)
	// 生产环境前面挂了 Nginx / K8s Ingress 网关,仅信任指定内网网关转发的 X-Forwarded-For，安全获取用户的真实公网 IP
	// _ = eng.SetTrustedProxies([]string{"127.0.0.1", "10.0.0.0/8"})

	// 性能分析 - 正式环境不要使用！！！
	if c.Env == xconfig.EnvDebug {
		pprof.Register(eng)
	}

	serviceName := c.Server.Name
	if serviceName == "" {
		serviceName = c.Project
	}

	// 初始化 全链路跟踪 tracer
	tp := xlog.InitTracer(xlog.TracingConfig{
		ServiceName:    serviceName,
		ServiceVersion: c.Version,
		Endpoint:       c.Jaeger.Endpoint,
		SampleRate:     c.Jaeger.SampleRate,
	})

	// 接管gin框架默认的日志和捕获异常。
	// Recovery 必须最先注册(位于中间件链最外层),否则 Tracing 自身 panic 时无人兜住,
	// 会直接冒泡到 net/http 变成空的 500 且不打业务日志。
	eng.Use(
		middleware.Recovery(c.Env == xconfig.EnvDebug || c.Env == xconfig.EnvTest), // 测试或开发环境回显堆栈
		xlog.TracingWithLogger(log, serviceName),
	)

	// 跨域
	eng.Use(middleware.CORS(c.Server.AllowOrigins))

	// Prometheus 吞吐与耗时指标监控
	eng.Use(middleware.Metrics(serviceName))

	// 全局: 有 token 就解析写入 context,没有也放行(不强制)
	// 配合各业务组的 Auth() 中间件实现"默认公开,显式加锁"
	eng.Use(middleware.WriteAuth(jwt))

	// 全局限流: 每 IP 每分钟最多 600 次,超限封禁 1 分钟。
	// 登录等敏感接口在各自路由上再叠加更严格的 RateLimiter / RedisRateLimiter。
	// 注意:状态在进程内存,多副本部署时实际阈值 = 该值 × 副本数;
	// 需要精确全局限流请换成基于 Redis 的令牌桶。
	rlCtx, rlCancel := context.WithCancel(context.Background())
	eng.Use(middleware.RateLimiter(600, time.Minute, time.Minute, rlCtx))

	// 缺失路由
	eng.NoRoute(router.NotFoundHandle)

	// 探针路由: 注册 DB 与 Redis 等核心依赖探活
	var checkers []router.NamedChecker
	if db != nil {
		checkers = append(checkers, router.NamedChecker{
			Name: "database",
			Check: func(ctx context.Context) error {
				sqlDB, err := db.DB()
				if err != nil {
					return err
				}
				return sqlDB.PingContext(ctx)
			},
		})
	}
	if redis != nil {
		checkers = append(checkers, router.NamedChecker{
			Name: "redis",
			Check: func(ctx context.Context) error {
				return redis.Ping(ctx).Err()
			},
		})
	}
	router.HealthChecks(eng, checkers...)

	// Prometheus 监控指标端点
	router.Metrics(eng)
	// Swagger 路由 仅非生产环境启用
	if c.Env != xconfig.EnvRelease {
		router.SwaggerRouter(eng)
	}

	// 业务路由
	for _, r := range rtrs {
		r(eng, jwt, hdl)
	}

	// ============ 资源关闭器(LIFO 关闭)============
	// 注册顺序与期望关闭顺序相反:后注册的先关。
	// 期望关闭顺序:http(由 Server.Stop 直接关) -> etcd -> db -> redis -> tracer -> xlog
	// 因此注册顺序:xlog(最先注册,最后关) -> tracer -> redis -> db -> etcd
	closer := xserver.NewCloser()
	closer.Add(func() error { return xlog.Close() }, "xlog")
	// rlCancel 停止限流器内部清理 goroutine(先于其他资源取消,无副作用)
	closer.Add(func() error { rlCancel(); return nil }, "rate-limiter")
	if tp != nil {
		closer.Add(func() error {
			shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			return tp.Shutdown(shutdownCtx)
		}, "tracer")
	}
	if redis != nil {
		closer.Add(func() error { return redis.Close() }, "redis")
	}
	if db != nil {
		closer.Add(func() error {
			sqlDB, err := db.DB()
			if err != nil {
				return err
			}
			return sqlDB.Close()
		}, "db")
	}
	if c.Watcher != nil {
		closer.Add(func() error { return c.Watcher.Close() }, "etcd-watcher")
	}

	return &Assembly{
		Engine: eng,
		Closer: closer,
	}, nil
}
