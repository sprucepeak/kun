/**
 * @Author:
 * @Date: 2024-03-28 13:46
 * @Desc: 授权验证中间件
 */

package middleware

import (
	"errors"
	"strconv"

	"api/internal/global"
	"api/pkg/token"
	"api/pkg/xhttp"

	"github.com/gin-gonic/gin"
)

// Auth jwt授权
func Auth(jwt *token.Jwt) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		if _, exists := ctx.Get(global.CtxAuthUserId); exists {
			ctx.Next()
			return
		}
		tokenStr := jwt.Find(ctx.Request)
		err := parsePayload(ctx, jwt, tokenStr)
		if err != nil {
			var e *token.Error
			if errors.As(err, &e) {
				switch e.Errors {
				case token.ErrorExpiredToken:
					xhttp.AuthFail(ctx, global.AuthTimeOut)
					ctx.Abort()
					return
				case token.ErrorAuthorizeElsewhere:
					xhttp.AuthFail(ctx, global.AuthKickedOut)
					ctx.Abort()
					return
				case token.ErrorUserBanned:
					xhttp.AuthFail(ctx, global.UserBanned)
					ctx.Abort()
					return
				case token.ErrorInvalidToken, token.ErrorEmptyToken:
					xhttp.AuthFail(ctx, global.AuthError)
					ctx.Abort()
					return
				default:
					xhttp.AuthFail(ctx, global.AuthError)
					ctx.Abort()
					return
				}
			}
			// 非 token.Error(如 Redis 连接异常、网络错误等基础设施错误),返回系统业务错误,避免误导为 401 认证失败
			xhttp.BusFail(ctx, err)
			ctx.Abort()
			return
		}
		ctx.Next()
	}
}

// OptAuth 可选授权
func OptAuth(jwt *token.Jwt) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		if _, exists := ctx.Get(global.CtxAuthUserId); !exists {
			tokenStr := jwt.Find(ctx.Request)
			_ = parsePayload(ctx, jwt, tokenStr)
		}
		ctx.Next()
	}
}

// WriteAuth 全局可选解析——有 token 就写入 context,没有也放行。
// conf 参数已移除(无实际用途),调用方签名简化为 WriteAuth(jwt)。
func WriteAuth(jwt *token.Jwt) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		if tokenStr := jwt.Find(ctx.Request); tokenStr != "" {
			_ = parsePayload(ctx, jwt, tokenStr)
		}
		ctx.Next()
	}
}

// parsePayload 解析 JWT 并将 userId/roleId 写入 gin context。
// tokenStr 由调用方预先通过 jwt.Find 获取，避免在同一请求中重复解析 Header/Query。
func parsePayload(ctx *gin.Context, jwt *token.Jwt, tokenStr string) (err error) {
	if tokenStr == "" {
		return token.ErrEmptyToken
	}
	payload, parseErr := jwt.Parse(ctx.Request.Context(), tokenStr)
	if parseErr != nil {
		return parseErr
	}
	userId, err := strconv.ParseInt(payload.Subject, 10, 64)
	if err != nil || userId <= 0 {
		return token.ErrInvalidToken
	}
	roleId := payload.RoleId
	if roleId == 0 && payload.Issuer != "" {
		roleId, _ = strconv.ParseInt(payload.Issuer, 10, 64)
	}
	ctx.Set(global.CtxAuthToken, tokenStr)
	ctx.Set(global.CtxAuthUserId, userId)
	ctx.Set(global.CtxAuthRoleId, roleId)
	return nil
}
