package global

import (
	"api/pkg/xerror"
)

// 统一错误码定义
const (
	Success int = 0 // 成功
	Unknown int = 1 // 未知错误,服务不可用

	// 参数错误 1001-1999
	NotFoundPath    int = 1001 // 地址不存在
	ParamError      int = 1002 // 请求参数错误
	InvalidArgument int = 1003 // 参数无效

	// 用户与认证错误 2001-2999
	Unauthorized           int = 2001 // 未授权
	AuthError              int = 2002 // 授权信息错误
	AuthTimeOut            int = 2003 // 授权信息超时
	AuthRefreshErr         int = 2004 // 刷新token失败
	PermitError            int = 2005 // 权限错误
	AccountOrPasswordError int = 2006 // 账号或密码错误
	AuthKickedOut          int = 2007 // 账号已在其他设备登录
	UserBanned             int = 2008 // 账号已被封禁

	// 业务处理错误 3001-3999
	BusinessError int = 3001 // 业务处理失败
)

// CodeMap 业务错误码字典映射
var CodeMap = map[int]string{
	Success: "成功",
	Unknown: "未知错误,服务不可用",

	NotFoundPath:    "地址不存在",
	ParamError:      "请求参数错误",
	InvalidArgument: "参数无效",

	Unauthorized: "未知授权信息",

	AuthError:      "授权信息错误",
	AuthTimeOut:    "授权信息超时",
	AuthRefreshErr: "刷新token失败",
	PermitError:    "权限错误",

	AccountOrPasswordError: "账号或密码错误",
	AuthKickedOut:          "账号已在其他设备登录，当前会话已失效",
	UserBanned:             "账号已被封禁，如有疑问请联系管理员",

	BusinessError: "服务器错误",
}

// Msg 根据错误码获取描述文案
func Msg(code int) string {
	if msg, ok := CodeMap[code]; ok {
		return msg
	}
	return "未知错误"
}

// New 根据业务错误码与可选底层 error 快速创建 xerror.Error (默认使用 CodeMap[code] 文案)
func New(code int, err ...error) xerror.Error {
	var cause error
	if len(err) > 0 {
		cause = err[0]
	}
	return xerror.NewError(code, Msg(code), cause)
}

// NewMsg 根据业务错误码、自定义文案与可选底层 error 快速创建 xerror.Error
func NewMsg(code int, message string, err ...error) xerror.Error {
	var cause error
	if len(err) > 0 {
		cause = err[0]
	}
	return xerror.NewError(code, message, cause)
}
