/**
 * @Author: spruce
 * @Date: 2026-09-30 09:25
 * @Desc: xetcd 框架级自定义配置中心与负载均衡使用指南
 *
 * ============================================================================
 * 一、工程日志与框架桥接模式说明：
 * 4 个工程共用本文件模板。每个工程为一个完整独立的注释区块（包含 import 与实现）。
 * 跨工程迁移时，只需【整块取消/添加注释】，仅需操作一处，无需上下翻找！
 *
 * ============================================================================
 * 二、负载均衡器（pkg/xetcd/balancer）使用指南：
 *
 * 【场景 1】在 go-zero / zrpc 中使用
 * go-zero 原生 zrpc 客户端默认自带加权 p2c_ewma 调度，直接连接 alaya 即可自动生效；
 * 若需要指定其他负载均衡，可配置 conf.BalancerName = balancer.LeastConnection 等。
 *
 * 【场景 2】在标准 gRPC 客户端中使用（简单易用）
 * 导入 api/pkg/xetcd/balancer 即可完成自动注册：
 *
 * import (
 *     "google.golang.org/grpc"
 *     "google.golang.org/grpc/credentials/insecure"
 *     "api/pkg/xetcd/balancer"
 * )
 *
 * // 方式 1: 直接使用便捷 Option (推荐)
 * conn, err := grpc.NewClient(
 *     "alaya:///default/dev/demoServer",
 *     grpc.WithTransportCredentials(insecure.NewCredentials()),
 *     balancer.WithBalancer(balancer.ConsistentHash), // 或 balancer.LeastConnection, balancer.Version
 * )
 *
 * // 方式 2: 使用内置 ServiceConfig JSON 字符串
 * conn, err := grpc.NewClient(
 *     target,
 *     grpc.WithDefaultServiceConfig(balancer.ServiceConfig(balancer.LeastConnection)),
 * )
 *
 * 【场景 3】调用方动态路由指定
 * // 1. 一致性哈希：按用户/订单 ID 路由到同一节点
 * ctx := balancer.WithHashKey(ctx, "user-10086")
 * resp, err := client.FindById(ctx, req)
 *
 * // 2. 灰度发布：指定访问 v2.0.0 版本
 * ctx := balancer.WithTargetVersion(ctx, "v2.0.0")
 * resp, err := client.FindById(ctx, req)
 * ============================================================================
 */

package xetcd

// ============================================================================
// 1. 【go-zero 工程专用】
// 特性：自动桥接 go-zero logx 日志系统 + zrpc 权重负载均衡器
// 启用：取消本区块注释，将其他区块整块注释
// ============================================================================

//import (
//	"github.com/zeromicro/go-zero/core/logx"
//	"github.com/zeromicro/go-zero/zrpc"
//)
//
//var pkgLogger func(format string, args ...any) = func(format string, args ...any) {
//	logx.Infof(format, args...)
//}
//
//// WithWeightedBalancer 将 RpcClientConf 配置为使用 Alaya 加权 p2c 负载均衡器。
//// 自动读取实例权重（weight）进行加权路由，权重为 0 的实例不参与流量分配。
// func WithWeightedBalancer(conf zrpc.RpcClientConf) zrpc.RpcClientConf {
// 	//  自定义 conf.BalancerName = balancer.WeightedP2C,// 与 go-zero p2c 算法一致
// 	return conf // go-zero 原生默认即为 p2c 负载均衡 ,
// }

// ============================================================================
// 2. 【kun工程/zap库 专用】
// 特性：自动桥接 Zap 结构化日志系统
// 启用：取消本区块注释，将其他区块整块注释
// ============================================================================

import "go.uber.org/zap"

var pkgLogger func(format string, args ...any) = func(format string, args ...any) {
	zap.L().Sugar().Infof(format, args...)
}

// ============================================================================
// 3. 【log 标准库 专用】
// 特性：纯标准库 log.Printf，零额外第三方依赖
// 启用：取消本区块注释，将其他区块整块注释
// ============================================================================

//import "log"
//
//var pkgLogger func(format string, args ...any) = log.Printf
