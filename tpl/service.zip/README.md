# service — 高级企业级工程布局

`service` 是基于 Go 语言设计的高并发、高可用企业级微服务工程样板脚手架。项目采用模块化分层解耦架构，通过 Google `Wire` 在编译期完成强类型依赖注入；同时内置双进程 Supervisor 架构的异步事件调度中心，支持全链路分布式追踪、敏感信息自动脱敏、单槽 Lua 原子认证与高可靠云原生健康检测。

---

## 技术栈与核心组件

| 类别 | 库 / 组件 | 说明 |
|:---|:---|:---|
| **Web 框架** | [Gin](https://github.com/gin-gonic/gin) | 高性能 HTTP 路由引擎、上下文与中间件链路 |
| **ORM 引擎** | [GORM](https://github.com/go-gorm/gorm) + [dbresolver](https://gorm.io/plugin/dbresolver) | 支持 MySQL / PostgreSQL / SQLite / ClickHouse 多驱动与主从读写分离 |
| **依赖注入** | [Wire](https://github.com/google/wire) | Google 编译期静态依赖注入（Compile-time DI），杜绝运行时反射 |
| **配置与服务治理** | [Viper](https://github.com/spf13/viper) + [etcd](https://github.com/etcd-io/etcd) | 多环境本地 YAML 动态加载，支持 etcd v3 远程配置热更新、租约服务注册与 gRPC 负载均衡 |
| **结构化日志** | [Zap](https://github.com/uber-go/zap) | 高性能结构化日志，支持敏感字段自动脱敏、动态跳层（穿透生成代码）与业务穿透 |
| **链路追踪** | [OpenTelemetry](https://github.com/open-telemetry/opentelemetry-go) | 全链路分布式追踪（Jaeger / OTLP 导出），涵盖 HTTP、GORM、Redis、Kafka、Asynq |
| **认证与安全** | [Golang-jwt/jwt/v5](https://github.com/golang-jwt/jwt) | HS384 双 Token 轮换、单端互斥、防重放熔断、CSPRNG 安全随机数 |
| **缓存服务** | [go-redis/v9](https://github.com/redis/go-redis) | Redis 单机/集群客户端，单槽 `{u:userId}` Hash Tag 原子 Lua 脚本鉴权 |
| **异步任务 & 调度** | [Asynq](https://github.com/hibiken/asynq) | 基于 Redis 的分布式延迟队列、立即异步任务与动态周期性 Cron 调度 |
| **消息队列** | [kafka-go](https://github.com/segmentio/kafka-go) | 高吞吐事件驱动架构，支持跨进程分布式追踪上下文传播 |
| **模型上下文协议** | **MCP (JSON-RPC 2.0)** | 原生集成 Model Context Protocol，支持 AI Agent / LLM 客户端直连与工具调用 |
| **实时通信与流式** | **SSE / WebSocket** | 支持 Server-Sent Events 流式下发与 WebSocket 一次性 Ticket 安全升级连接 |
| **报表流式处理** | [Excelize](https://github.com/xuri/excelize) | 支持 StreamWriter 极速流式写入与导出，彻底规避海量数据内存溢出（OOM） |
| **参数校验** | [Validator/v10](https://github.com/go-playground/validator) | 请求参数规则校验、中文/多语言错误提示自动翻译与自定义规则扩展 |
| **接口文档** | [Swaggo](https://github.com/swaggo/swag) | 代码声明式 Swagger OpenAPI 3.0+ 接口文档生成 |

---

## 分层架构设计

项目采用严格的单向依赖与工程化分层解耦架构，通过 Google `Wire` 在编译期完成装配：

```
┌─────────────────────────────────────────────────────────┐
│                    router / handler                     │  ── 路由分发 & 控制层（参数校验、协议转换、SSE/WS/MCP）
├─────────────────────────────────────────────────────────┤
│                      service / svc                      │  ── 核心业务逻辑编排层（事务管理、领域规则、单飞防击穿）
├─────────────────────────────────────────────────────────┤
│           repository/db   |   repository/cache          │  ── 数据持久化访问层（DB CRUD/读写分离 + 本地/Redis二级缓存）
├─────────────────────────────────────────────────────────┤
│                     internal / event                    │  ── 事件驱动层（Kafka 事件发布/订阅 + Asynq 延时/周期任务）
├─────────────────────────────────────────────────────────┤
│                         pkg / x*                        │  ── 跨项目基础设施与公共组件库（日志、配置、Token、加解密等）
└─────────────────────────────────────────────────────────┘
```

- **handler**: 负责接收 HTTP / MCP 请求，执行入参校验（Validator），调用 Service 编排逻辑，返回统一 JSON 响应。
- **service (svc)**: 承载核心业务领域逻辑，负责分布式事务、Singleflight 防击穿、二级缓存策略、事件投递。
- **repository**: 屏蔽底层数据库与缓存的具体实现细节，提供纯粹的数据持久化接口（支持游标分页与 SQL 注入拦截）。
- **event**: 统一抽象事件发布者（`Pub`）与订阅者（`Sub`），集成 Kafka 与 Asynq 多种消息调度后端。
- **pkg**: 通用基础设施库（Zap 日志脱敏、Viper/etcd 动态配置、AES/RSA/Bcrypt 加解密、JWT 双 Token 中心等）。

---

## 目录结构

```
.
├── cmd/                           项目服务入口目录
│   ├── broker/                    异步调度服务器入口（消息消费、延时任务、定时任务）
│   │   ├── main.go                启动入口（命令行参数解析、Wire 依赖装配）
│   │   └── wire/                  Wire 依赖注入与应用装配
│   │       ├── app.go             Broker 应用装配（健康探针服务与子进程消费者启动器）
│   │       ├── wire.go            声明 Broker 全链路依赖 ProviderSet
│   │       └── wire_gen.go        Wire 自动生成装配代码
│   └── server/                    HTTP 业务服务入口
│       ├── main.go                启动入口（声明 Swagger 元信息、加载配置）
│       └── wire/                  Wire 依赖注入与应用装配
│           ├── app.go             HTTP 应用装配（Gin 引擎、中间件栈、路由挂载与生命周期资源回收）
│           ├── wire.go            声明 Server 全栈分层依赖 ProviderSet
│           └── wire_gen.go        Wire 自动生成装配代码
├── configs/                       配置文件目录
│   ├── dev.yml                    本地开发环境配置（包含 MySQL/Redis/Kafka/etcd 连接与数据库驱动切换示例）
│   └── release.yml                生产环境标准配置模板（支持无敏感明文，完全由环境变量注入）
├── deploy/                        部署编排与容器化
│   ├── .env.example               环境变量配置示例
│   ├── Dockerfile                 多阶段瘦身构建 Dockerfile（基于 Alpine，自动精简符号表）
│   └── docker-compose.yml         本地中间件一键编排启动（MySQL 8.0、Redis 6.2、Zookeeper、Kafka）
├── docs/                          项目文档与资产
│   └── sql/                       数据库初始化与变更脚本
│       └── service.sql           全量数据库表结构与初始演示数据
├── swagger/                       Swagger API 静态文档生成产物目录
├── internal/                      内部业务核心逻辑
│   ├── conf/                      应用配置模型与 Wire 依赖注入
│   │   └── conf.go                应用全量配置模型（Conf）与配置容器（Container），聚合组件独立配置并提供 Wire ProviderSet
│   ├── event/                     事件驱动抽象层
│   │   ├── publisher.go           消息发布器（Kafka 同步/类型消息 + Asynq 立即/延迟/周期任务）
│   │   ├── subscriber.go          订阅管理器（Kafka 消费者组并发拉取 + Asynq Worker 调度）
│   │   └── type.go                订阅任务与消费组实体定义
│   ├── global/                    全局常量与枚举
│   │   ├── code.go                业务错误码定义（统一错误码常量、CodeMap 映射字典与 Msg/New 便捷构造函数）
│   │   └── constant.go            上下文 Key、路由统一前缀与全局基础常量
│   │   ├── event.go               事件类型、Topic 与消费组枚举
│   │   └── pay.go                 业务状态与支付类型枚举
│   ├── handler/                   HTTP 控制器与处理器层
│   │   ├── demo/                  Demo 演示处理器
│   │   │   ├── demo.go            完整业务接口（CRUD、验证、Excel流式导出、SSE、WebSocket、登录/鉴权）
│   │   │   └── mcp.go             Model Context Protocol (JSON-RPC 2.0) 端点实现
│   │   └── serverDI.go            Wire DI 注册全部 Handler
│   ├── middleware/                HTTP 中间件
│   │   ├── auth.go                JWT 鉴权拦截器（支持 Auth 强制模式、WriteAuth 可选模式）
│   │   ├── cors.go                CORS 跨域安全配置（支持白名单精准匹配）
│   │   ├── csrf.go                基于 gorilla/csrf 的防跨站请求伪造保护
│   │   ├── metrics.go             Prometheus 吞吐量与请求耗时性能监控
│   │   ├── ratelimit.go           单机滑动窗口与 Redis 分布式限流器（支持触发封禁与 Retry-After）
│   │   └── recovery.go            Panic 异常捕获、调用栈格式化与全局错误日志落地
│   ├── repository/                数据访问与持久化层
│   │   ├── cache/                 缓存层
│   │   │   ├── demo.go            二级缓存实现（Local go-cache + Redis 互补）
│   │   │   ├── keys.go            缓存 Key 模板统一管理
│   │   │   └── local.go           线程安全本地内存缓存封装
│   │   ├── db/                    数据库持久化层
│   │   │   ├── db.go              GORM 客户端封装、事务（Transaction）、排序安全校验、通用分页逻辑
│   │   │   ├── demo.go            Demo 自定义业务查询（流式游标查询、多字段组合检索）
│   │   │   └── demo_gen.go        SqlGen 自动生成的标准 CRUD 样板代码
│   │   └── serverDI.go            Wire DI 注册全部 Repository
│   ├── router/                    路由注册层
│   │   ├── router.go              全局基础设施路由（404缺省、/metrics监控、/swagger文档、/healthz与/ready探活）
│   │   ├── serverDI.go            Wire DI 注册全部业务路由
│   │   └── v0/demo.go             v0 版本 RESTful 路由组、WebSocket 升级点与公开端点
│   └── service/                   业务服务层
│       ├── svc/                   核心业务逻辑实现
│       │   ├── broker.go          事件消费业务逻辑（Kafka 消费处理 + Asynq 异步任务处理）
│       │   ├── context.go         服务公共上下文定义与标准分页契约模型（PageReq/PageResp/PageMoreResp）
│       │   └── demo.go            Demo 业务逻辑实现（登录/单飞防击穿/加解密/流式导出/SSE/WS票据）
│       ├── brokerDI.go            Wire DI 注册 Broker 消费任务与服务
│       └── serverDI.go            Wire DI 注册 HTTP 服务层
├── pkg/                           通用跨项目公共基础设施工具库
│   ├── asynq/                     Asynq 驱动封装（基于独立 Config 驱动，异步任务、延时入队、动态周期任务与 OpenTelemetry 链路追踪）
│   ├── encrypt/                   安全加解密套件（AES-GCM/CBC、RSA 签名验签、MD5、Bcrypt 密码哈希）
│   ├── kafka/                     Kafka 客户端封装（基于独立 Config 驱动，Publisher、ConsumerGroup 消费组、跨进程追踪透传）
│   ├── token/                     JWT 认证中心（双 Token 轮换、单端互斥、防重放熔断、基于官方 redis.UniversalClient 接口单槽原子鉴权）
│   ├── utils/                     常用通用工具库（Sonyflake 雪花ID、时间/网络/文件/协程池/正则校验）
│   ├── validator/                 参数校验引擎（基于 Validator v10，内置常用正则与多语言翻译）
│   ├── xconfig/                   通用泛型配置管理器（Manager[T any]，零业务耦合、支持本地 YAML 与 etcd 远程互斥切换，原子快照与变更通知）
│   ├── xdb/                       数据库连接池封装（基于独立 Config 驱动，适配 MySQL/PG/SQLite/ClickHouse、dbresolver 读写分离）
│   ├── xerror/                    统一错误抽象契约模型（定义通用 Error 接口与标准状态，彻底解耦具体业务错误码）
│   ├── xetcd/                     etcd v3 客户端套件（租约心跳注册 Registrar、gRPC 发现 Resolver、配置 Watcher）
│   ├── xhttp/                     统一 HTTP JSON 响应封装（泛型支持、标准嵌套分页契约、支持外部错误码字典映射注入）
│   ├── xlog/                      高性能 Zap 结构化日志（基于独立 Config 驱动，40+类敏感数据掩码、链路 Span 关联、底层零偏移与业务动态跳层）
│   ├── xredis/                    Redis 连接池封装（基于独立 Config 驱动，单机/集群自适应、Lua 脚本预编译 EVALSHA、追踪注入）
│   └── xserver/                   服务抽象与生命周期管理（HTTP 服务装配、Broker 双进程守护、LIFO 资源回收 Closer）
│       ├── broker/                Broker 父子进程 Supervisor 守护器（基于独立 Config 驱动，移除多余资源依赖）
│       └── http/                  HTTP 服务生命周期托管（基于独立 Config 驱动）
├── test/                          自动化测试目录
├── Makefile                       编译构建与工程化自动化脚本
└── README.md                      项目技术说明文档
```

---

## 环境要求与初始化

- **Go**: `1.25.11` 或更高版本
- **Git**
- **Wire**: `go install github.com/google/wire/cmd/wire@latest`
- **Docker & Docker-Compose**（可选，用于本地一键拉起依赖中间件）

### 本地快速启动

```bash
# 1. 安装开发工具链 (Wire, Mockgen, Swag)
make init

# 2. 一键启动本地依赖中间件 (MySQL, Redis, Kafka, Zookeeper) 并启动服务
make bootstrap

# 或者单独编译与启动
kun run ./cmd/server
kun run ./cmd/broker
```

---

## 常用开发与运维命令

项目同时支持 `Makefile` 与 `kun` CLI 工具：

### 1. 服务运行与构建

```bash
# 运行 HTTP 服务
kun run
# 或
kun run ./cmd/server

# 运行 Broker 调度消费服务
kun run ./cmd/broker

# 静态交叉编译 Linux 二进制 (禁用 CGO，适配容器镜像)
make build

# 构建多阶段瘦身 Docker 镜像
make docker
```

### 2. 代码生成与依赖注入

```bash
# 修改了依赖注入代码后重新生成 wire_gen.go
kun wire
# 或执行
wire ./cmd/server/wire && wire ./cmd/broker/wire

# 生成 Swagger API 接口文档 (输出至 ./swagger 目录)
make swag

# 执行 Mock 桩代码生成
make mock

# 代码格式化与静态检查
make fmt
make vet
make lint

# 运行带竞态检测的单元测试
make test
```

### 3. 脚手架业务代码一键生成 (`kun gen`)

```bash
# 生成路由层代码
kun gen rt <module>

# 生成处理器层代码
kun gen hdl <module>

# 生成业务服务层代码
kun gen svc <module>

# 生成缓存层代码
kun gen cache <module>

# 一键生成 Handler + Service
kun gen hs <module>

# 一键生成 Router + Handler + Service (标准 CRUD)
kun gen crud <module>

# 数据库逆向代码生成（自动生成 Model 与 Repository 样板代码）
kun gen db "root:password@tcp(127.0.0.1:3306)/dbname" "*"
```

---

## 核心架构与功能特性详解

### 1. 异步任务与事件驱动体系 (`cmd/broker`)

`cmd/broker` 采用了**父子双进程 Supervisor 架构**：
- **父进程（Master）**：负责启动轻量 HTTP 健康检测探活服务（暴露 `/healthz` 与 `/ready` 探针），并拉起与看护子进程；子进程异常退出时自动进行退避重启。
- **子进程（Worker）**：独立初始化 OpenTelemetry Tracer，并发启动 Kafka 消费者组、Asynq 异步任务消费、Asynq 周期性 Cron 调度，并在收到停止信号时平滑退出。

#### 消息发布调用 (`*event.Pub`)

在 Service 层直接注入 `*event.Pub`，调用标准化发布接口：

```go
// 1. 发布 Kafka 消息 (带 Context 传播分布式链路追踪 Span)
err := s.pub.KafkaCtx(ctx, global.EventTopicPay, payloadBytes)

// 2. 发布带业务 Type 标识的 Kafka 消息
err := s.pub.KafkaWithTypeCtx(ctx, global.EventTopicPay, global.EventTypePayRecharge, payloadBytes)

// 3. 发布立即异步任务 (投递至 Asynq 队列)
err := s.pub.SyncCtx(ctx, global.EventTopicPay, string(payloadBytes))

// 4. 发布延迟任务 (指定秒级延迟，如 30 分钟未支付订单自动超时)
err := s.pub.DelayCtx(ctx, global.EventTopicPay, string(payloadBytes), 30*60)

// 5. 注册动态周期性定时任务 (动态 Hash 存储，无需重启服务即可生效)
err := s.pub.Cron(global.EventTopicPay, string(payloadBytes), "@every 1m")

// 6. 取消指定的动态定时任务
err := s.pub.DelCron(global.EventTopicPay)
```

#### 消费者编写 (`internal/service/svc/broker.go`)

```go
// Kafka 业务消费方法
func (b *brokerSvc) SubPayRecharge(ctx context.Context, key, value string) error {
    xlog.Info(ctx, "收到充值支付事件", xlog.KVStr("key", key), xlog.KVStr("payload", value))
    // 执行业务逻辑...
    return nil
}

// Asynq 任务处理方法
func (b *brokerSvc) SubAqPay(ctx context.Context, task *asynq.Task) error {
    xlog.Info(ctx, "处理 Asynq 调度任务", xlog.KVStr("type", task.Type()))
    // 解析 task.Payload() 并处理...
    return nil
}
```
编写完成后在 `internal/service/brokerDI.go` 中挂载至 `WireBrokerSet`，即可完成消费者注册。

---

### 2. 双模式配置中心与零停机热更新

项目内置统一配置容器 `xconfig.Conf`，支持本地 YAML 与远程 etcd 互斥加载，保障开发与生产环境的高可靠运行。

#### 运行模式切换 (`configs/dev.yml` 或 `configs/release.yml`)

```yaml
project: "service"
env: "debug"
version: "0.0.1"

# 远程配置中心配置:
# hosts 为空列表 [] 时：自动降级为【纯本地模式】，完全读取本地 YAML，监听本地文件改动并触发热更新；
# hosts 包含有效节点时：自动切换为【纯远程模式】，业务配置由 etcd 全权驱动并动态监听，杜绝本地冲突覆盖。
remoteConfig:
  hosts: []
  # - "127.0.0.1:2379"
  username: ""
  password: ""

# ──────────────── 常见支持热更新的配置节点 ────────────────
token:
  secret: "123456ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  refreshSecret: "abcdefghijklmnopqrstuvwxyz123456"
  csrfKey: "abcdefghijklmnopqrstuvwxyz123456"
  expire: 3600        # 短 Token 过期时间(秒)
  refresh: 604800     # 刷新 Token 存活时长(秒)
  maxRefresh: 2592000 # 绝对最大有效期(秒)
  gracePeriod: 30     # 轮换并发宽限期(秒)
  queryKey: "Authorization"
  multiLogin: false   # 是否允许多端登录

log:
  level: "debug"   # 日志级别: debug, info, warn, error (原子指针切换，纳秒级生效)
  filePath: ""     # 落盘路径，留空则不写文件
  stdout: true     # 是否输出控制台
  kafkaTopic: ""   # 日志推送 Kafka 主题
  kafkaBrokers: []
```

#### 业务代码获取热更新参数与精细化注入

项目全面落实**精细化配置注入**与**通用泛型配置管理**架构：
- **底层基础设施零业务依赖**：`pkg/xdb`、`pkg/xredis`、`pkg/xlog`、`pkg/token`、`pkg/kafka`、`pkg/asynq`、`pkg/xserver/http`、`pkg/xserver/broker` 等全部接收自身独立的 `Config` 结构体（如 `xdb.New(conf.Database)`），避免将全局大配置传给底层驱动，大幅提升内聚性。
- **业务配置容器编排**：由 `internal/conf/conf.go` 聚合全量业务配置 `Conf` 与泛型管理器 `Manager[Conf]` 构造 `Container`，并通过 Wire 提供精细化子配置注入。

- **方式一：原子快照读取（推荐）**  
  底层通过 `atomic.Pointer[Conf]` 托管最新配置，零锁开销、绝对线程安全：
  ```go
  func (s *demoSvc) Detail(ctx context.Context, id int64) (*DemoResp, error) {
      cfg := s.ctx.Conf.Get() // 获取不可变的最新配置快照 (*conf.Conf)
      writeTimeout := cfg.Server.WriteTimeout
      _ = writeTimeout
      return nil, nil
  }
  ```
- **方式二：注册变更回调（组件内部维护状态时使用）**  
  ```go
  c.OnUpdate(func(newConf *conf.Conf) {
      xlog.Info(context.Background(), "检测到配置变更，更新内部参数缓存")
  })
  ```

---

### 3. 高安全 JWT 双 Token 认证规范

项目遵循 `pkg/token/README.md` 全生命周期安全机制设计：

1. **双密钥物理隔离**：`Secret` 与 `RefreshSecret` 强制要求独立且长度 $\ge 32$ 字节（HS384 算法），杜绝 RefreshToken 伪装成 AccessToken 越权调用接口。
2. **CSPRNG 密码学随机 JTI**：使用 `crypto/rand` 底层安全熵池生成唯一 Token ID，杜绝碰撞与规律预测。
3. **Redis 单槽原子操作 (`Hash Tag`)**：所有用户关联的黑名单、活跃会话、封禁状态键名统一注入 `{u:userId}`，确保在 Redis 集群分片环境下 100% 路由至同一 Slot，避免 `CROSSSLOT` 错误。
4. **无感轮换与防重放熔断**：
   - 客户端携带 RefreshToken 请求 `/api/demo/refresh` 自动置换全新双 Token。
   - 内置 `GracePeriod`（默认 30 秒）宽限期，幂等抗击网络抖动与并发刷新。
   - 若已失效凭证在宽限期外被再次提交，系统立即判定为**凭证窃取重放攻击（Compromised）**，触发自动熔断并注销该用户全端会话。
5. **单端互斥与强制下线**：
   - `multiLogin: false` 时，新登录通过 Lua 脚本原子踢出旧会话（`oldSid` 状态置为 `kicked`）。
   - 管理员端点支持主动封禁（`BanUser`）、解封（`UnbanUser`）与全端强制下线（`KickAllDevices`）。

---

### 4. 模型上下文协议 (MCP) 原生集成

项目在 `internal/handler/demo/mcp.go` 中提供了面向大模型和 AI Agent 的标准 **Model Context Protocol** 端点：
- **挂载路由**：支持挂载于 `/api/demo/mcp` 与根路径 `/mcp`。
- **协议规范**：完全兼容标准 JSON-RPC 2.0 规范，提供 `initialize`、`tools/list`、`tools/call` 等核心方法。
- **支持调用**：支持直接通过 HTTP GET 查看演示信息，或通过 HTTP POST 发起 JSON-RPC 工具调用，无缝对接 Cursor、Claude Desktop 等 MCP 客户端。

---

### 5. 实时通信、流式处理与安全连接

1. **Server-Sent Events (SSE)**：
   - 接口 `/api/demo/sse` 实现了 `http.NewResponseController` 动态清除 `WriteDeadline`，避免流式推送被超时中间件掐断。
   - 响应封装层包装 `Unwrap() http.ResponseWriter`，支持原生 Flush 实时推送事件。
2. **WebSocket 一次性 Ticket 认证**：
   - 针对浏览器标准 WebSocket 无法自定义请求头携带 `Authorization` 的痛点，采用**两阶段安全连接**：
     1. 前端先调用需鉴权接口 `/api/demo/ws-ticket` 申请 30 秒有效的一次性随机票据；
     2. 连接 WebSocket 时携带 `?ticket=xxx`，服务端在升级连接前完成消费校验并立即销毁票据；彻底避免长效 Token 暴露在 URL 与访问日志中。
3. **海量数据 Excel 流式导出**：
   - 基于 `excelize.NewStreamWriter` 分批写入并即时刷盘流式下发，大幅降低堆内存占用，支撑百万级大文件导出。

---

### 6. 云原生健康检查与优雅关机

- **健康检查探针**：
  - `/healthz`（存活探针 Liveness）：服务进程启动且端口监听即返回 `UP`。
  - `/ready`（就绪探针 Readiness）：并发检测 MySQL 与 Redis 核心依赖连接健康状态。
- **流量摘除与平滑排空 (Graceful Drain)**：
  - 当服务收到 `SIGTERM` / `SIGINT` 退出信号时，首先通过 `xserver.SetDraining()` 标记排空状态，使 `/ready` 探针立即向 K8s Ingress / 负载均衡器返回 `503 Service Unavailable` 摘除外部流量；
  - 随后按注册逆序（LIFO）平滑关闭 HTTP 监听、释放消费者队列、断开数据库与 Redis 连接池、刷新并关闭 OpenTelemetry Tracer 与 Zap 日志落盘，杜绝丢单与数据截断。

---

## 核心设计与开发约定

1. **依赖注入约束**: 模块间均通过 Google `Wire` 强类型编排组装，严禁手写繁杂单例或使用全局变量传参。
2. **统一结构化日志**: 业务代码严格仅依赖 `pkg/xlog`；全日志自动关联 TraceID/SpanID，内置 40+ 类敏感信息脱敏；支持 `WithCallerSkip` 自动穿透 `_gen.go` 生成代码，准确定位业务代码行号。
3. **分层错误码与业务语义解耦**:
   - `pkg/xerror` 仅作为通用错误抽象契约层（定义 `Error` 接口及 `Success`/`Unknown` 标准码），零业务码污染。
   - 具体业务错误码及文案字典完全沉淀在 `internal/global/code.go`，提供 `global.Msg`、`global.New` 等便捷方法。
   - HTTP 装配层（`cmd/server/wire/app.go`）显式调用 `xhttp.RegisterCodeLookup(global.Msg)` 与 `xhttp.SetDefaultCodes(...)` 完成字典桥接。
6. **精细化配置依赖注入规范**:
   - 基础设施驱动层（`xdb`、`xredis`、`xlog`、`token`、`kafka`、`asynq`、`xserver/http`、`xserver/broker` 等）严格仅接收自身专有的 `Config` 结构体，禁止底层反向依赖全局配置；
   - `pkg/xconfig` 保持通用泛型 `Manager[T any]`，所有业务全量配置模型在 `internal/conf/conf.go` 集中聚合，并通过 `conf.ProviderSet` 供 Wire 精细按需注入。
4. **缓存规范与防击穿**:
   - 缓存 Key 模板必须严格集中在 `repository/cache/keys.go` 中管理，严禁业务代码硬编码拼装。
   - 高频查询场景使用 `singleflight.Group` 合并并发回源，防止缓存击穿与数据库雪崩。
5. **统一 HTTP 响应与分页契约**:
   - 响应格式全局统一为 `{ code, message, data }`。单体数据由 `xhttp.Data` 承载，分页数据由 `xhttp.List` 封装为嵌套结构 `data: { page, pageSize, total, items }`，杜绝平铺结构造成前端拦截器混乱。
   - 请求分页统一内嵌 `svc.PageReq`，支持 `form:"...,default=..."` 自动注入与 `ToDbSearchPage()` 默认值兜底。
   - 游标分页入参 `LastId` 规范声明为 `string` 类型，彻底规避雪花算法 64 位大整数在前端 JavaScript 中的精度截断问题。
