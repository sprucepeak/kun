package kafka

import (
	"context"
	"errors"
	"time"

	kafkaGo "github.com/segmentio/kafka-go"
)

type (
	// Publisher 复用底层 kafka Writer,避免每次发布都新建/关闭 Writer 造成连接抖动和批处理失效。
	// kafka-go 的 Writer 并发安全,可被多个 goroutine 共享。
	Publisher struct {
		writer *kafkaGo.Writer
	}
	Msg struct {
		Topic string
		Key   string
		Value []byte
	}
)

func NewPublisher(conf Config) *Publisher {
	if len(conf.Brokers) == 0 {
		panic("无可用的节点信息")
	}
	// 构造期即创建 Writer(不懒加载):Close 与并发 Publish 不再有对 writer 字段的读写竞态,
	// 生命周期也清晰--进程退出时 Close 一次即可。
	// 不在 Writer 上设置 Topic,由每条消息自带 Topic 字段决定目标分区,从而支持 Pub/PubWithKey/PubList 共用一个 Writer。
	return &Publisher{
		writer: &kafkaGo.Writer{
			Addr:         kafkaGo.TCP(conf.Brokers...),
			// 采用 ReferenceHash 对齐 Kafka 官方默认分区策略: 有 Key 按 Key Hash 保证顺序，无 Key 均匀轮询各分区，杜绝无 Key 消息全被塞入分区 0 造成单分区热点
			Balancer:     &kafkaGo.ReferenceHash{},
			Compression:  kafkaGo.Snappy,        // 启用压缩
			BatchTimeout: 50 * time.Millisecond, // linger.ms 如果消息的大小一直达不到batch.size设置的值，那么等待多久后任然允许发送消息
			// 设为同步安全投递，确保 WriteMessages 真实捕获 Broker 持久化错误并正确记录链路追踪
			Async: false,
			Completion: func(messages []kafkaGo.Message, err error) {
				if err != nil {
					klog.Printf("write message failed: %v (batch size=%d)", err, len(messages))
				}
			},
		},
	}
}

// Close 关闭底层 Writer,应在进程退出前调用。
func (p *Publisher) Close() error {
	if p.writer != nil {
		return p.writer.Close()
	}
	return nil
}

func (p *Publisher) Pub(topic string, value []byte) error {
	return p.PubCtx(context.Background(), topic, value)
}

// PubCtx 发布消息并把 ctx 中的 trace context 注入消息 header,串联生产者->消费者链路。
func (p *Publisher) PubCtx(ctx context.Context, topic string, value []byte) error {
	// 无类型消息:不设 Key(nil),由 ReferenceHash balancer 均匀轮询各分区。
	ctx, span, headers := startProducerSpan(ctx, topic)
	defer span.End()
	msg := kafkaGo.Message{
		Topic:   topic,
		Value:   value,
		Headers: headers,
	}
	if err := p.writer.WriteMessages(ctx, msg); err != nil {
		span.RecordError(err)
		return err
	}
	return nil
}

func (p *Publisher) PubWithKey(topic, key string, value []byte) error {
	return p.PubWithKeyCtx(context.Background(), topic, key, value)
}

// PubWithKeyCtx 同 PubCtx,但带业务 Key(决定分区)。
func (p *Publisher) PubWithKeyCtx(ctx context.Context, topic, key string, value []byte) error {
	ctx, span, headers := startProducerSpan(ctx, topic)
	defer span.End()
	msg := kafkaGo.Message{
		Topic:   topic,
		Key:     []byte(key),
		Value:   value,
		Headers: headers,
	}
	if err := p.writer.WriteMessages(ctx, msg); err != nil {
		span.RecordError(err)
		return err
	}
	return nil
}

func (p *Publisher) PubList(msgSet ...Msg) error {
	return p.PubListCtx(context.Background(), msgSet...)
}

// PubListCtx 批量发布,所有消息共享同一个 producer span。
func (p *Publisher) PubListCtx(ctx context.Context, msgSet ...Msg) error {
	if len(msgSet) == 0 {
		return errors.New("Msg 不能为空")
	}
	ctx, span, headers := startProducerSpan(ctx, "batch")
	defer span.End()
	msgList := make([]kafkaGo.Message, len(msgSet))
	for i, msg := range msgSet {
		msgList[i] = kafkaGo.Message{
			Topic:   msg.Topic,
			Key:     []byte(msg.Key),
			Value:   msg.Value,
			Headers: headers,
		}
	}
	if err := p.writer.WriteMessages(ctx, msgList...); err != nil {
		span.RecordError(err)
		return err
	}
	return nil
}
