/**
 * @Author: spruce
 * @Date: 2024-03-28 20:15
 * @Desc: etcd 分布式互斥锁组件
 */

package lock

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"go.etcd.io/etcd/client/v3/concurrency"
)

var (
	// ErrLocked 加锁失败：已被其他进程或协程持有
	ErrLocked = errors.New("etcd lock: key already locked by another process")
	// ErrNotLocked 锁未被持有（调用 Unlock 时）
	ErrNotLocked = errors.New("etcd lock: lock is not held")
	// ErrLockTimeout 等待加锁超时
	ErrLockTimeout = errors.New("etcd lock: acquisition timeout")
	// ErrNilClient 未提供有效的 etcd client
	ErrNilClient = errors.New("etcd lock: etcd client cannot be nil")
)

const (
	defaultDialTimeout = 5 * time.Second
	defaultLockTTL     = 10 // 默认租约维持时长 10 秒
)

// Conf 客户端连接配置 (兼容旧版 Addr 与新版规范)
type Conf struct {
	Hosts       []string `json:"hosts" yaml:"hosts"`             // etcd 服务节点列表
	Username    string   `json:"username" yaml:"username"`       // 认证账号 (可选)
	Password    string   `json:"password" yaml:"password"`       // 认证密码 (可选)
	DialTimeout int      `json:"dialTimeout" yaml:"dialTimeout"` // 拨号超时时长 (秒)
}

// Lock etcd 分布式锁实体
type Lock struct {
	client    *clientv3.Client
	ownClient bool // 是否内部创建的 client，若为 true 则在主动销毁时负责关闭

	key string
	ttl int // 租约续租周期/默认超时秒数 (防死锁守护)

	mu      sync.Mutex
	session *concurrency.Session
	mutex   *concurrency.Mutex
}

// Option 函数式选项
type Option func(*Lock)

// WithTTL 指定租约保持时长 (秒)
func WithTTL(ttl int) Option {
	return func(l *Lock) {
		if ttl > 0 {
			l.ttl = ttl
		}
	}
}

// New 使用现有的 etcd 客户端构造分布式锁 (推荐: 复用已有全局连接池，零额外建连开销)
func New(cli *clientv3.Client, key string, opts ...Option) (*Lock, error) {
	if cli == nil {
		return nil, ErrNilClient
	}
	l := &Lock{
		client: cli,
		key:    key,
		ttl:    defaultLockTTL,
	}
	for _, opt := range opts {
		opt(l)
	}
	return l, nil
}

// NewWithConfig 使用配置独立建立 etcd 客户端并构造分布式锁
func NewWithConfig(conf *Conf, key string, opts ...Option) (*Lock, error) {
	if conf == nil || len(conf.Hosts) == 0 {
		return nil, fmt.Errorf("etcd hosts cannot be empty")
	}

	timeout := time.Duration(conf.DialTimeout) * time.Second
	if timeout <= 0 {
		timeout = defaultDialTimeout
	}

	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   conf.Hosts,
		DialTimeout: timeout,
		Username:    conf.Username,
		Password:    conf.Password,
	})
	if err != nil {
		return nil, fmt.Errorf("connect to etcd failed: %w", err)
	}

	l, err := New(cli, key, opts...)
	if err != nil {
		_ = cli.Close()
		return nil, err
	}
	l.ownClient = true
	return l, nil
}

// NewLock 兼容旧版构造器签名 (向后兼容已有测试和业务代码)
func NewLock(conf *Conf, key string, timeout int64) *Lock {
	ttl := int(timeout)
	if ttl <= 0 {
		ttl = defaultLockTTL
	}
	l, err := NewWithConfig(conf, key, WithTTL(ttl))
	if err != nil {
		// 记录告警但构造容错空壳，避免由于连接失败引发不可控 panic
		return &Lock{
			key: key,
			ttl: ttl,
		}
	}
	return l
}

// TryLock 非阻塞尝试加锁 (抢锁失败立即返回 ErrLocked)
func (l *Lock) TryLock(ctx ...context.Context) error {
	callCtx, cancel := l.resolveContext(ctx)
	defer cancel()

	if l.client == nil {
		return ErrNilClient
	}

	// 创建独立 session 自动保持租约心跳 (基于指定 TTL 续租)
	session, err := concurrency.NewSession(l.client,
		concurrency.WithTTL(l.ttl),
	)
	if err != nil {
		return fmt.Errorf("create etcd session failed: %w", err)
	}

	m := concurrency.NewMutex(session, l.key)
	if err := m.TryLock(callCtx); err != nil {
		// 加锁失败立即关闭 session 释放续租协程与租约，杜绝连接及资源泄漏
		_ = session.Close()
		if errors.Is(err, concurrency.ErrLocked) {
			return ErrLocked
		}
		return err
	}

	l.mu.Lock()
	if l.session != nil {
		_ = l.session.Close()
	}
	l.session = session
	l.mutex = m
	l.mu.Unlock()

	return nil
}

// Lock 阻塞等待直到成功加锁或 context 超时/取消 (由 etcd 原生 Watch 排队唤醒，零自旋)
func (l *Lock) Lock(ctx ...context.Context) error {
	callCtx, cancel := l.resolveContext(ctx)
	defer cancel()

	if l.client == nil {
		return ErrNilClient
	}

	session, err := concurrency.NewSession(l.client,
		concurrency.WithTTL(l.ttl),
	)
	if err != nil {
		return fmt.Errorf("create etcd session failed: %w", err)
	}

	// 基于 etcd 原生 revision watch 排队机制等待加锁，网络等待期间不持有进程内互斥锁
	m := concurrency.NewMutex(session, l.key)
	if err := m.Lock(callCtx); err != nil {
		// 加锁失败或超时，释放 session
		_ = session.Close()
		if errors.Is(err, context.DeadlineExceeded) || errors.Is(callCtx.Err(), context.DeadlineExceeded) {
			return ErrLockTimeout
		}
		return err
	}

	l.mu.Lock()
	if l.session != nil {
		_ = l.session.Close()
	}
	l.session = session
	l.mutex = m
	l.mu.Unlock()

	return nil
}

// Unlock 释放锁 (优雅关闭 session 并撤销租约)
func (l *Lock) Unlock(ctx ...context.Context) error {
	callCtx, cancel := l.resolveContext(ctx)
	defer cancel()

	l.mu.Lock()
	m := l.mutex
	s := l.session
	l.mutex = nil
	l.session = nil
	l.mu.Unlock()

	if m == nil {
		return ErrNotLocked
	}

	var unlockErr error
	unlockErr = m.Unlock(callCtx)
	if s != nil {
		_ = s.Close()
	}

	return unlockErr
}


// Close 主动销毁锁对象（若为独立初始化的客户端则关闭连接）
func (l *Lock) Close() error {
	_ = l.Unlock()

	l.mu.Lock()
	defer l.mu.Unlock()
	if l.ownClient && l.client != nil {
		err := l.client.Close()
		l.client = nil
		return err
	}
	return nil
}

// Key 获取当前锁定的 key
func (l *Lock) Key() string {
	return l.key
}


// Do 安全执行闭包：自动获取锁并在函数执行结束（包括 panic）后安全释放锁
func (l *Lock) Do(ctx context.Context, fn func() error) error {
	if err := l.Lock(ctx); err != nil {
		return err
	}
	defer func() {
		_ = l.Unlock(context.Background())
	}()

	return fn()
}

// resolveContext 内部解析传入上下文或兜底构造带默认超时的上下文与取消函数
func (l *Lock) resolveContext(ctxs []context.Context) (context.Context, context.CancelFunc) {
	if len(ctxs) > 0 && ctxs[0] != nil {
		return ctxs[0], func() {}
	}
	timeout := time.Duration(l.ttl) * time.Second
	if timeout <= 0 {
		timeout = defaultDialTimeout
	}
	return context.WithTimeout(context.Background(), timeout)
}
