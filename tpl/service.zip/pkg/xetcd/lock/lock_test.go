package lock

import (
	"testing"
)

func TestEtcdLock_TryLock(t *testing.T) {
	lock := NewLock(&Conf{
		Hosts:       []string{"127.0.0.1:2379"},
		DialTimeout: 1,
	}, "/test/lock", 5)

	if err := lock.TryLock(); err != nil {
		t.Skipf("skipping test: etcd not reachable or locked: %v", err)
		return
	}
	defer func() {
		_ = lock.Unlock()
	}()

	// 重复 TryLock 应该失败 (ErrLocked)
	if err := lock.TryLock(); err == nil {
		t.Errorf("expected ErrLocked on concurrent TryLock, got nil")
	}
}
