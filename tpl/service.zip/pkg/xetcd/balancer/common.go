/**
 * @Author: spruce
 * @Date: 2026-09-30 10:00
 * @Desc: 负载均衡通用定义、属性提取与上下文路由辅助
 */

package balancer

import (
	"context"
	"fmt"
	"strings"

	"google.golang.org/grpc"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/resolver"
)

// 与 resolver.go 对齐的 Address Attributes Key
const (
	AttrKeyVersion = "alaya.version"
	AttrKeyWeight  = "alaya.weight"
)

// 负载均衡器注册名称常量
const (
	// ConsistentHash 一致性哈希负载均衡器名称
	ConsistentHash = "consistentHash"

	// LeastConnection 最小连接数/活跃请求数负载均衡器名称
	LeastConnection = "leastConnection"

	// Version 依据版本路由/灰度的负载均衡器名称
	Version = "version"

	// WeightedP2C 加权 P2C 负载均衡器名称 (与 go-zero p2c 算法一致)
	WeightedP2C = "weightedP2C"
)

// 上下文与 Metadata 键定义
type contextKey string

const (
	ctxKeyHashKey contextKey = "alaya.balancer.hash_key"
	ctxKeyVersion contextKey = "alaya.balancer.target_version"

	mdKeyHashKey = "x-hash-key"
	mdKeyVersion = "x-target-version"
)

// WithHashKey 将一致性哈希路由键注入 context，供 ConsistentHash 负载均衡器使用
func WithHashKey(ctx context.Context, key string) context.Context {
	return context.WithValue(ctx, ctxKeyHashKey, key)
}

// GetHashKey 从 context 或 gRPC metadata 中解析一致性哈希路由键
func GetHashKey(ctx context.Context) string {
	if ctx == nil {
		return ""
	}
	// 1. 优先从 context 本地 Value 读取
	if v, ok := ctx.Value(ctxKeyHashKey).(string); ok && v != "" {
		return v
	}
	// 2. 从 gRPC outgoing / incoming metadata 中读取
	if md, ok := metadata.FromOutgoingContext(ctx); ok {
		if vals := md.Get(mdKeyHashKey); len(vals) > 0 && vals[0] != "" {
			return vals[0]
		}
	}
	if md, ok := metadata.FromIncomingContext(ctx); ok {
		if vals := md.Get(mdKeyHashKey); len(vals) > 0 && vals[0] != "" {
			return vals[0]
		}
	}
	return ""
}

// WithTargetVersion 将期望的目标路由版本注入 context，供 Version 负载均衡器使用
func WithTargetVersion(ctx context.Context, version string) context.Context {
	return context.WithValue(ctx, ctxKeyVersion, version)
}

// GetTargetVersion 从 context 或 gRPC metadata 中解析目标版本
func GetTargetVersion(ctx context.Context) string {
	if ctx == nil {
		return ""
	}
	// 1. 优先从 context 本地 Value 读取
	if v, ok := ctx.Value(ctxKeyVersion).(string); ok && v != "" {
		return v
	}
	// 2. 兼容旧版用 "version" 作为 key
	if v, ok := ctx.Value(Version).(string); ok && v != "" {
		return v
	}
	// 3. 从 gRPC outgoing / incoming metadata 中读取
	if md, ok := metadata.FromOutgoingContext(ctx); ok {
		if vals := md.Get(mdKeyVersion); len(vals) > 0 && vals[0] != "" {
			return vals[0]
		}
	}
	if md, ok := metadata.FromIncomingContext(ctx); ok {
		if vals := md.Get(mdKeyVersion); len(vals) > 0 && vals[0] != "" {
			return vals[0]
		}
	}
	return ""
}

// ExtractWeight 从 resolver.Address.Attributes 中安全提取节点权重 (默认兜底为 1)
func ExtractWeight(addr resolver.Address) int64 {
	if addr.Attributes == nil {
		return 1
	}
	v := addr.Attributes.Value(AttrKeyWeight)
	if v == nil {
		return 1
	}
	switch w := v.(type) {
	case int64:
		if w > 0 {
			return w
		}
	case int:
		if w > 0 {
			return int64(w)
		}
	case float64:
		if w > 0 {
			return int64(w)
		}
	}
	return 1
}

// ExtractVersion 从 resolver.Address.Attributes 中安全提取节点版本号
func ExtractVersion(addr resolver.Address) string {
	if addr.Attributes == nil {
		return ""
	}
	v := addr.Attributes.Value(AttrKeyVersion)
	if v == nil {
		return ""
	}
	if str, ok := v.(string); ok {
		return strings.TrimSpace(str)
	}
	return ""
}

// ServiceConfig 生成对应负载均衡器的 gRPC DefaultServiceConfig JSON 字符串
func ServiceConfig(balancerName string) string {
	return fmt.Sprintf(`{"loadBalancingConfig": [{"%s": {}}]}`, balancerName)
}

// WithBalancer 返回配置了指定负载均衡器的 grpc.DialOption
func WithBalancer(balancerName string) grpc.DialOption {
	return grpc.WithDefaultServiceConfig(ServiceConfig(balancerName))
}
