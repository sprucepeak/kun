/**
 * @Author: spruce
 * @Date: 2026-09-30 10:00
 * @Desc: 一致性哈希负载均衡器 (Consistent Hash Balancer)
 */

package balancer

import (
	"fmt"
	"hash/fnv"
	"sort"
	"strconv"
	"sync"
	"sync/atomic"

	"google.golang.org/grpc/balancer"
	"google.golang.org/grpc/balancer/base"
)

func init() {
	RegisterConsistentHash()
}

// RegisterConsistentHash 注册一致性哈希负载均衡器到 gRPC balancer 注册表
func RegisterConsistentHash() {
	builder := base.NewBalancerBuilder(
		ConsistentHash,
		&consistentHashPickerBuilder{},
		base.Config{HealthCheck: true},
	)
	balancer.Register(builder)
}

type consistentHashPickerBuilder struct{}

func (b *consistentHashPickerBuilder) Build(info base.PickerBuildInfo) balancer.Picker {
	if len(info.ReadySCs) == 0 {
		return base.NewErrPicker(balancer.ErrNoSubConnAvailable)
	}

	picker := &consistentHashPicker{
		ring:     NewKetama(50, nil),
		subConns: make(map[string]balancer.SubConn),
		allSCs:   make([]balancer.SubConn, 0, len(info.ReadySCs)),
	}

	for sc, conInfo := range info.ReadySCs {
		addr := conInfo.Address.Addr
		weight := int(ExtractWeight(conInfo.Address))
		if weight <= 0 {
			weight = 1
		}

		// 根据权重成比例分配哈希虚拟节点
		for i := 0; i < weight; i++ {
			nodeTag := fmt.Sprintf("%s#%d", addr, i)
			picker.ring.Add(nodeTag)
			picker.subConns[nodeTag] = sc
		}
		picker.allSCs = append(picker.allSCs, sc)
	}

	return picker
}

type consistentHashPicker struct {
	ring     *Ketama
	subConns map[string]balancer.SubConn
	allSCs   []balancer.SubConn
	round    uint64
}

func (p *consistentHashPicker) Pick(info balancer.PickInfo) (balancer.PickResult, error) {
	if len(p.allSCs) == 0 {
		return balancer.PickResult{}, balancer.ErrNoSubConnAvailable
	}

	// 1. 获取请求路由 HashKey
	key := GetHashKey(info.Ctx)
	if key != "" {
		if nodeTag, ok := p.ring.Get(key); ok {
			if sc, exists := p.subConns[nodeTag]; exists {
				return balancer.PickResult{SubConn: sc}, nil
			}
		}
	}

	// 2. 未指定 HashKey 或哈希环异常时，平滑降级为轮询
	idx := atomic.AddUint64(&p.round, 1) % uint64(len(p.allSCs))
	return balancer.PickResult{SubConn: p.allSCs[idx]}, nil
}

// ============================================================================
// Ketama 一致性哈希环实现
// ============================================================================

type HashFunc func(data []byte) uint32

func DefaultHash(data []byte) uint32 {
	f := fnv.New32a()
	_, _ = f.Write(data)
	return f.Sum32()
}

type Ketama struct {
	sync.RWMutex
	hash     HashFunc
	replicas int
	keys     []int          // 升序排列的虚拟节点哈希值
	hashMap  map[int]string // 哈希值 -> 真实节点标识
}

func NewKetama(replicas int, fn HashFunc) *Ketama {
	if replicas <= 0 {
		replicas = 50
	}
	if fn == nil {
		fn = DefaultHash
	}
	return &Ketama{
		replicas: replicas,
		hash:     fn,
		hashMap:  make(map[int]string),
	}
}

func (h *Ketama) IsEmpty() bool {
	h.RLock()
	defer h.RUnlock()
	return len(h.keys) == 0
}

func (h *Ketama) Add(nodes ...string) {
	h.Lock()
	defer h.Unlock()

	for _, node := range nodes {
		for i := 0; i < h.replicas; i++ {
			virtualKey := strconv.Itoa(i) + ":" + node
			hash := int(h.hash([]byte(virtualKey)))
			if _, ok := h.hashMap[hash]; !ok {
				h.keys = append(h.keys, hash)
			}
			h.hashMap[hash] = node
		}
	}
	sort.Ints(h.keys)
}

func (h *Ketama) Remove(nodes ...string) {
	h.Lock()
	defer h.Unlock()

	for _, node := range nodes {
		for i := 0; i < h.replicas; i++ {
			virtualKey := strconv.Itoa(i) + ":" + node
			hash := int(h.hash([]byte(virtualKey)))
			delete(h.hashMap, hash)
		}
	}

	// 重建 keys 列表
	h.keys = make([]int, 0, len(h.hashMap))
	for k := range h.hashMap {
		h.keys = append(h.keys, k)
	}
	sort.Ints(h.keys)
}

func (h *Ketama) Get(key string) (string, bool) {
	h.RLock()
	defer h.RUnlock()

	if len(h.keys) == 0 {
		return "", false
	}

	hash := int(h.hash([]byte(key)))
	idx := sort.Search(len(h.keys), func(i int) bool {
		return h.keys[i] >= hash
	})

	if idx >= len(h.keys) {
		idx = 0 // 环形顺时针兜底返回第一个节点
	}

	node, ok := h.hashMap[h.keys[idx]]
	return node, ok
}
