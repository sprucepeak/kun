/**
 * @Author: spruce
 * @Date: 2026-09-30 10:00
 * @Desc: 基于版本/灰度标签的负载均衡器 (Version / Canary Balancer)
 */

package balancer

import (
	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	"google.golang.org/grpc/balancer"
	"google.golang.org/grpc/balancer/base"
)

func init() {
	RegisterVersion()
}

// RegisterVersion 注册版本负载均衡器到 gRPC balancer 注册表
func RegisterVersion() {
	builder := base.NewBalancerBuilder(
		Version,
		&versionPickerBuilder{},
		base.Config{HealthCheck: true},
	)
	balancer.Register(builder)
}

type versionPickerBuilder struct{}

func (b *versionPickerBuilder) Build(info base.PickerBuildInfo) balancer.Picker {
	if len(info.ReadySCs) == 0 {
		return base.NewErrPicker(balancer.ErrNoSubConnAvailable)
	}

	versionMap := make(map[string][]*versionNode)
	allNodes := make([]*versionNode, 0, len(info.ReadySCs))

	for sc, connInfo := range info.ReadySCs {
		ver := ExtractVersion(connInfo.Address)
		w := ExtractWeight(connInfo.Address)
		if w <= 0 {
			w = 1
		}

		node := &versionNode{
			subConn: sc,
			version: ver,
			weight:  w,
		}

		allNodes = append(allNodes, node)
		if ver != "" {
			versionMap[ver] = append(versionMap[ver], node)
		}
	}

	return &versionPicker{
		versionMap: versionMap,
		allNodes:   allNodes,
		rand:       rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

type versionNode struct {
	subConn balancer.SubConn
	version string
	weight  int64
}

type versionPicker struct {
	versionMap map[string][]*versionNode
	allNodes   []*versionNode
	mu         sync.Mutex
	rand       *rand.Rand
	round      uint64
}

func (p *versionPicker) Pick(info balancer.PickInfo) (balancer.PickResult, error) {
	if len(p.allNodes) == 0 {
		return balancer.PickResult{}, balancer.ErrNoSubConnAvailable
	}

	targetVer := GetTargetVersion(info.Ctx)

	// 1. 若指定了目标版本，且存在匹配该版本的实例组，则在该组内加权选择
	if targetVer != "" {
		if matchedNodes, ok := p.versionMap[targetVer]; ok && len(matchedNodes) > 0 {
			chosen := p.pickFromNodes(matchedNodes)
			return balancer.PickResult{SubConn: chosen.subConn}, nil
		}
	}

	// 2. 未指定版本或指定版本无实例可用时，安全降级到全体可用实例
	chosen := p.pickFromNodes(p.allNodes)
	return balancer.PickResult{SubConn: chosen.subConn}, nil
}

// pickFromNodes 根据权重进行平滑选择
func (p *versionPicker) pickFromNodes(nodes []*versionNode) *versionNode {
	if len(nodes) == 1 {
		return nodes[0]
	}

	// 计算权重总和
	var totalWeight int64
	for _, n := range nodes {
		totalWeight += n.weight
	}

	if totalWeight <= 0 {
		idx := atomic.AddUint64(&p.round, 1) % uint64(len(nodes))
		return nodes[idx]
	}

	p.mu.Lock()
	r := p.rand.Int63n(totalWeight)
	p.mu.Unlock()

	var runningSum int64
	for _, n := range nodes {
		runningSum += n.weight
		if r < runningSum {
			return n
		}
	}

	return nodes[0]
}
