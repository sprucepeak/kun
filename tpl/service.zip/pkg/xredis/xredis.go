/**
 * @Author:
 * @Date: 2024-03-28 13:45
 * @Desc: redis
 */

package xredis

import (
	"context"
	"fmt"
	"time"

	"github.com/redis/go-redis/extra/redisotel/v9"
	"github.com/redis/go-redis/v9"
)

const Nil = redis.Nil

// Script 导出 Redis Lua 脚本类型
type Script = redis.Script

// NewScript 创建预编译 Redis Lua 脚本实例 (底层自动走 EVALSHA，提升并发性能)
func NewScript(src string) *Script {
	return redis.NewScript(src)
}

type (
	// Config Redis 配置
	Config struct {
		Source       []string `json:"source" yaml:"source" mapstructure:"source"`
		Password     string   `json:"password" yaml:"password" mapstructure:"password"`
		DB           int      `json:"db" yaml:"db" mapstructure:"db"` // Redis 数据库索引(单机模式有效)
		Cluster      bool     `json:"cluster" yaml:"cluster" mapstructure:"cluster"`
		PoolSize     int      `json:"poolSize" yaml:"poolSize" mapstructure:"poolSize"`         // 连接池大小
		MinIdleConns int      `json:"minIdleConns" yaml:"minIdleConns" mapstructure:"minIdleConns"` // 最小空闲连接数
	}

	Client struct {
		redis.UniversalClient
	}
)

func New(conf Config) (*Client, error) {
	if len(conf.Source) == 0 {
		return nil, fmt.Errorf("redis 配置错误")
	}

	minIdleConns := conf.MinIdleConns
	if minIdleConns <= 0 && conf.PoolSize > 0 {
		minIdleConns = conf.PoolSize / 4
		if minIdleConns < 2 {
			minIdleConns = 2
		}
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	var client redis.UniversalClient
	if conf.Cluster {
		client = redis.NewClusterClient(&redis.ClusterOptions{
			Addrs:        conf.Source,
			Password:     conf.Password,
			PoolSize:     conf.PoolSize,
			MinIdleConns: minIdleConns,
		})
	} else {
		client = redis.NewClient(&redis.Options{
			Addr:         conf.Source[0],
			Password:     conf.Password, // no password set
			DB:           conf.DB,       // redis db 索引
			PoolSize:     conf.PoolSize, // 连接池大小
			MinIdleConns: minIdleConns,        // 最小空闲连接数
		})
	}

	// 使用官方的 OpenTelemetry 插件
	if err := redisotel.InstrumentTracing(client); err != nil {
		return nil, fmt.Errorf("InstrumentTracing redis[%v] failed: %w", conf.Source[0], err)
	}

	c := &Client{client}

	_, err := c.Ping(ctx).Result()
	if err != nil {
		return nil, fmt.Errorf("ping redis[%v]失败: %w", conf.Source[0], err)
	}
	return c, nil
}
