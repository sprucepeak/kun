package xconfig

import (
	"context"
	"fmt"
	"os"
	"strings"
	"sync"
	"sync/atomic"

	"service/pkg/xetcd"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

const (
	EnvDebug   = "debug"
	EnvTest    = "test"
	EnvStaging = "staging"
	EnvRelease = "release"
)

type (
	// EtcdConf 远程配置中心配置
	EtcdConf struct {
		Hosts    []string `mapstructure:"hosts"`    // etcd 节点列表，为空时自动降级走纯本地配置
		Username string   `mapstructure:"username"` // 可选认证账号
		Password string   `mapstructure:"password"` // 可选认证密码
	}

	// Manager 是通用泛型配置管理器。
	// 它封装了 Viper 本地加载、etcd 远端拉取/热监听、原子快照管理以及更新回调。
	// 运行期通过 m.Get() 获取原子快照指针，零竞态，低分配。
	Manager[T any] struct {
		Watcher *xetcd.Watcher `mapstructure:"-"`

		// current 原子持有"当前配置快照"指针,供运行期 Get() 读取,零竞态。
		current atomic.Pointer[T]

		// onUpdateHooks 保存所有已注册的配置热更新回调
		onUpdateHooks []func(newConf *T)
		hookMu        sync.Mutex
	}
)

// New 初始化泛型配置管理器并加载首份配置
func New[T any](path string) (*Manager[T], *T, error) {
	confPath := os.Getenv("CONF")
	if confPath == "" {
		confPath = path
	}
	v := viper.New()
	v.AutomaticEnv()                                   // 自动识别环境变量
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_")) // 将 . 替换为 _ SERVER_PORT=10088 覆盖文件中 server下面port值
	v.SetConfigFile(confPath)

	if e := v.ReadInConfig(); e != nil {
		return nil, nil, fmt.Errorf("fatal error config file: %w", e)
	}

	// 读取用于判断是否启用远程配置的基础元信息
	var meta struct {
		Project      string   `mapstructure:"project"`
		Env          string   `mapstructure:"env"`
		RemoteConfig EtcdConf `mapstructure:"remoteConfig"`
	}
	_ = v.Unmarshal(&meta)

	m := new(Manager[T])
	initial := new(T)

	// 本地与远程严格互斥，绝不合并覆盖。
	if len(meta.RemoteConfig.Hosts) > 0 {
		// 纯远程配置模式
		w, err := xetcd.NewWatcher(meta.RemoteConfig.Hosts, meta.RemoteConfig.Username, meta.RemoteConfig.Password)
		if err != nil {
			return nil, nil, fmt.Errorf("[remote-config] create watcher failed: %w", err)
		}
		project, env := meta.Project, meta.Env
		if project == "" {
			project = "default"
		}
		if env == "" {
			env = EnvDebug
		}
		if err := w.Watch(context.Background(), project, env); err != nil {
			return nil, nil, fmt.Errorf("[remote-config] watch failed: %w", err)
		}
		m.Watcher = w

		// 启动期：先反序列化本地基础配置（如元信息），再全量加载 etcd 远端配置
		_ = v.Unmarshal(initial)
		loadEtcdConfig(w, initial)

		// 运行期：监听 etcd 变更实现动态热重载，不受本地 yaml 影响
		w.SetOnChange(func() {
			newT := new(T)
			_ = v.Unmarshal(newT)
			loadEtcdConfig(w, newT)
			m.update(newT)
		})
	} else {
		// 完全随本地 yaml 变动而热更新，不连接 etcd，不受远程影响。
		if e := v.Unmarshal(initial); e != nil {
			return nil, nil, fmt.Errorf("fatal error config to T: %w", e)
		}
		v.OnConfigChange(func(event fsnotify.Event) {
			newT := new(T)
			if e := v.Unmarshal(newT); e != nil {
				_, _ = fmt.Fprintf(os.Stderr, "config hot reload unmarshal failed: %s\n", e)
				return
			}
			m.update(newT)
		})
		v.WatchConfig()
	}

	m.current.Store(initial)
	return m, initial, nil
}

// Get 返回当前配置的稳定快照指针,热重载后返回新快照。
// 运行期重复读取必须走 Get(),零分配、零竞态。
func (m *Manager[T]) Get() *T {
	return m.current.Load()
}

// OnUpdate 注册配置变更监听器 (无论是本地 yaml 还是 etcd 热重载, 均会触发)
func (m *Manager[T]) OnUpdate(fn func(newConf *T)) {
	m.hookMu.Lock()
	defer m.hookMu.Unlock()
	m.onUpdateHooks = append(m.onUpdateHooks, fn)
}

// update 原子替换快照指针，并广播热更新事件
func (m *Manager[T]) update(newT *T) {
	m.hookMu.Lock()
	hooks := make([]func(newConf *T), len(m.onUpdateHooks))
	copy(hooks, m.onUpdateHooks)
	m.hookMu.Unlock()

	m.current.Store(newT)

	for _, fn := range hooks {
		fn(newT)
	}
}

// loadEtcdConfig 将 etcd 中拉取的所有远端配置填充至 target 中 (仅用于 remoteConfig 模式)
func loadEtcdConfig[T any](w *xetcd.Watcher, target *T) {
	if w == nil {
		return
	}
	configs := w.All()
	if len(configs) == 0 {
		return
	}
	etcdV := viper.New()
	for _, cv := range configs {
		if cv == nil || cv.Content == "" {
			continue
		}
		subV := viper.New()
		subV.SetConfigType("yaml")
		if err := subV.ReadConfig(strings.NewReader(cv.Content)); err == nil {
			_ = etcdV.MergeConfigMap(subV.AllSettings())
		}
	}
	_ = etcdV.Unmarshal(target)
}

// Scan 从 etcd 配置中心反序列化指定 group/dataId 的配置到 target 结构体
func (m *Manager[T]) Scan(group, dataId string, target any) error {
	if m.Watcher == nil {
		return fmt.Errorf("etcd watcher not initialized")
	}
	return m.Watcher.Scan(group, dataId, target)
}

// GetRawConfig 获取 etcd 中指定的原始配置元信息
func (m *Manager[T]) GetRawConfig(group, dataId string) *xetcd.ConfigValue {
	if m.Watcher != nil {
		return m.Watcher.Get(group, dataId)
	}
	return nil
}
