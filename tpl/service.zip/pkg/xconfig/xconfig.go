package xconfig

import (
	"context"
	"fmt"
	"os"
	"strings"
	"sync"
	"sync/atomic"

	"service/pkg/xetcd"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

const (
	EnvDebug   = "debug"
	EnvTest    = "test"
	EnvStaging = "staging"
	EnvRelease = "release"
)

type (
	// EtcdConf 远程配置中心配置
	EtcdConf struct {
		Hosts    []string `mapstructure:"hosts"`    // etcd 节点列表，为空时自动降级走纯本地配置
		Username string   `mapstructure:"username"` // 可选认证账号
		Password string   `mapstructure:"password"` // 可选认证密码
	}

	// Manager 是通用泛型配置管理器。
	// 它封装了 Viper 本地加载、etcd 远端拉取/热监听、原子快照管理以及更新回调。
	// 运行期通过 m.Get() 获取原子快照指针，零竞态，低分配。
	Manager[T any] struct {
		Watcher *xetcd.Watcher `mapstructure:"-"`

		// current 原子持有"当前配置快照"指针,供运行期 Get() 读取,零竞态。
		current atomic.Pointer[T]

		// onUpdateHooks 保存所有已注册的配置热更新回调
		onUpdateHooks []func(newConf *T)
		hookMu        sync.Mutex

		localV *viper.Viper
	}
)

// New 初始化泛型配置管理器并加载首份配置
func New[T any](path string) (*Manager[T], *T, error) {
	confPath := os.Getenv("CONF")
	if confPath == "" {
		confPath = path
	}
	v := viper.New()
	v.AutomaticEnv()                                   // 自动识别环境变量
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_")) // 将 . 替换为 _ SERVER_PORT=10088 覆盖文件中 server下面port值
	v.SetConfigFile(confPath)

	if e := v.ReadInConfig(); e != nil {
		return nil, nil, fmt.Errorf("fatal error config file: %w", e)
	}

	// 读取用于判断是否启用远程配置的基础元信息
	var meta struct {
		Project      string   `mapstructure:"project"`
		Env          string   `mapstructure:"env"`
		Version      string   `mapstructure:"version"`
		RemoteConfig EtcdConf `mapstructure:"remoteConfig"`
	}
	_ = v.Unmarshal(&meta)

	m := new(Manager[T])
	m.localV = v
	initial := new(T)

	// 本地与远程严格互斥，绝不合并覆盖。
	if len(meta.RemoteConfig.Hosts) > 0 {
		if strings.TrimSpace(meta.Project) == "" {
			return nil, nil, fmt.Errorf("[remote-config] project cannot be empty when remoteConfig.hosts is configured")
		}
		if strings.TrimSpace(meta.Env) == "" {
			return nil, nil, fmt.Errorf("[remote-config] env cannot be empty when remoteConfig.hosts is configured")
		}

		// 纯远程配置模式
		w, err := xetcd.NewWatcher(meta.RemoteConfig.Hosts, meta.RemoteConfig.Username, meta.RemoteConfig.Password)
		if err != nil {
			return nil, nil, fmt.Errorf("[remote-config] create watcher failed: %w", err)
		}
		project, env := meta.Project, meta.Env
		if err := w.Watch(context.Background(), project, env); err != nil {
			return nil, nil, fmt.Errorf("[remote-config] watch failed: %w", err)
		}
		m.Watcher = w

		// 远程配置模式：仅反序列化基础元信息，业务配置全量由 etcd 提供，杜绝读取本地 yaml 业务配置
		metaV := viper.New()
		metaV.Set("project", meta.Project)
		metaV.Set("env", meta.Env)
		metaV.Set("version", meta.Version)
		metaV.Set("remoteConfig", meta.RemoteConfig)
		_ = metaV.Unmarshal(initial)

		if err := loadEtcdConfig(w, initial); err != nil {
			return nil, nil, fmt.Errorf("[remote-config] %w", err)
		}

		// 运行期：监听 etcd 变更实现动态热重载，不受本地 yaml 影响
		w.SetOnChange(func() {
			newT := new(T)
			_ = metaV.Unmarshal(newT)
			if err := loadEtcdConfig(w, newT); err != nil {
				_, _ = fmt.Fprintf(os.Stderr, "[remote-config] hot reload failed: %s\n", err)
				return
			}
			m.update(newT)
		})
	} else {
		// 完全随本地 yaml 变动而热更新，不连接 etcd，不受远程影响。
		if e := v.Unmarshal(initial); e != nil {
			return nil, nil, fmt.Errorf("fatal error config to T: %w", e)
		}
		v.OnConfigChange(func(event fsnotify.Event) {
			newT := new(T)
			if e := v.Unmarshal(newT); e != nil {
				_, _ = fmt.Fprintf(os.Stderr, "config hot reload unmarshal failed: %s\n", e)
				return
			}
			m.update(newT)
		})
		v.WatchConfig()
	}

	m.current.Store(initial)
	return m, initial, nil
}

// Get 返回当前配置的稳定快照指针,热重载后返回新快照。
// 运行期重复读取必须走 Get(),零分配、零竞态。
func (m *Manager[T]) Get() *T {
	return m.current.Load()
}

// OnUpdate 注册配置变更监听器 (无论是本地 yaml 还是 etcd 热重载, 均会触发)
func (m *Manager[T]) OnUpdate(fn func(newConf *T)) {
	m.hookMu.Lock()
	defer m.hookMu.Unlock()
	m.onUpdateHooks = append(m.onUpdateHooks, fn)
}

// update 原子替换快照指针，并广播热更新事件
func (m *Manager[T]) update(newT *T) {
	m.hookMu.Lock()
	hooks := make([]func(newConf *T), len(m.onUpdateHooks))
	copy(hooks, m.onUpdateHooks)
	m.hookMu.Unlock()

	m.current.Store(newT)

	for _, fn := range hooks {
		fn(newT)
	}
}

// loadEtcdConfig 将 etcd 中拉取的所有远端配置填充至 target 中 (仅用于 remoteConfig 模式)
func loadEtcdConfig[T any](w *xetcd.Watcher, target *T) error {
	if w == nil {
		return fmt.Errorf("etcd watcher is nil")
	}
	configs := w.All()
	if len(configs) == 0 {
		return fmt.Errorf("remote config items count is 0 in etcd")
	}
	etcdV := viper.New()
	for _, cv := range configs {
		if cv == nil || cv.Content == "" {
			continue
		}
		subV := viper.New()
		subV.SetConfigType("yaml")
		if err := subV.ReadConfig(strings.NewReader(cv.Content)); err != nil {
			return fmt.Errorf("parse remote yaml config failed: %w", err)
		}
		_ = etcdV.MergeConfigMap(subV.AllSettings())
	}
	if err := etcdV.Unmarshal(target); err != nil {
		return fmt.Errorf("unmarshal remote config failed: %w", err)
	}
	return nil
}

// Scan 从配置中心反序列化指定 group/dataId 的配置到 target 结构体。
// 远程模式下优先从 etcd 读取，纯本地模式下平滑降级从本地配置中读取。
func (m *Manager[T]) Scan(group, dataId string, target any) error {
	if m.Watcher != nil {
		return m.Watcher.Scan(group, dataId, target)
	}
	if m.localV != nil {
		key := group + "." + dataId
		if m.localV.IsSet(key) {
			return m.localV.UnmarshalKey(key, target)
		}
		if m.localV.IsSet(dataId) {
			return m.localV.UnmarshalKey(dataId, target)
		}
		return fmt.Errorf("config %s/%s not found in local config", group, dataId)
	}
	return fmt.Errorf("config manager not initialized")
}

// GetRawConfig 获取指定的原始配置元信息。
// 远程模式下优先从 etcd 读取，纯本地模式下平滑降级从本地配置中提取。
func (m *Manager[T]) GetRawConfig(group, dataId string) *xetcd.ConfigValue {
	if m.Watcher != nil {
		return m.Watcher.Get(group, dataId)
	}
	if m.localV != nil {
		key := group + "." + dataId
		val := m.localV.GetString(key)
		if val == "" {
			val = m.localV.GetString(dataId)
		}
		if val != "" {
			return &xetcd.ConfigValue{
				Content: val,
				Format:  "yaml",
			}
		}
	}
	return nil
}
