package xlog

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/segmentio/kafka-go"
	"google.golang.org/grpc"
	"gopkg.in/natefinch/lumberjack.v2"

	"go.opentelemetry.io/otel/trace"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

type (
	Logger    = zap.Logger
	Field     = zap.Field
	loggerKey struct{}

	// Config 日志配置
	Config struct {
		Level        string   `json:"level" yaml:"level" mapstructure:"level"`
		FilePath     string   `json:"filePath" yaml:"filePath" mapstructure:"filePath"`
		Stdout       bool     `json:"stdout" yaml:"stdout" mapstructure:"stdout"`
		KafkaTopic   string   `json:"kafkaTopic" yaml:"kafkaTopic" mapstructure:"kafkaTopic"`
		KafkaBrokers []string `json:"kafkaBrokers" yaml:"kafkaBrokers" mapstructure:"kafkaBrokers"`
	}

	ConfLog = Config
)

var (
	currentLogConf    Config
	confMu            sync.Mutex
	activeClosers     []func() error
	closersMu         sync.Mutex
	closersClosed     bool
	globalAtomicLevel = zap.NewAtomicLevelAt(zapcore.DebugLevel)
)

func slicesEqual(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// ParseLevel 将字符串日志等级解析为 zapcore.Level
func ParseLevel(levelStr string) zapcore.Level {
	switch strings.ToLower(strings.TrimSpace(levelStr)) {
	case "info":
		return zapcore.InfoLevel
	case "warn":
		return zapcore.WarnLevel
	case "error":
		return zapcore.ErrorLevel
	default:
		return zapcore.DebugLevel
	}
}

// SetLevel 动态修改当前运行期的全局日志等级 (线程安全, 零分配, 立即生效)
func SetLevel(levelStr string) {
	globalAtomicLevel.SetLevel(ParseLevel(levelStr))
}

// GetLevel 获取当前运行期日志等级
func GetLevel() zapcore.Level {
	return globalAtomicLevel.Level()
}

// buildLogger 根据 Config 构建完整的 Logger 及关联的资源关闭函数
func buildLogger(logConf Config) (*Logger, []func() error, error) {
	encoderConfig := zapcore.EncoderConfig{
		TimeKey:        "timestamp",
		LevelKey:       "level",
		NameKey:        "logger",
		CallerKey:      "caller",
		FunctionKey:    "func",
		MessageKey:     "content",
		StacktraceKey:  "stacktrace",
		LineEnding:     zapcore.DefaultLineEnding,
		EncodeLevel:    zapcore.LowercaseLevelEncoder,  // 小写编码器
		EncodeTime:     zapcore.ISO8601TimeEncoder,     // 使用ISO8601格式
		EncodeDuration: zapcore.SecondsDurationEncoder, // 使用Float64格式的持续时间
		EncodeCaller:   zapcore.ShortCallerEncoder,     // 包名:文件名
		EncodeName:     zapcore.FullNameEncoder,
	}

	var cores []zapcore.Core
	var closers []func() error

	// 1. 控制台日志
	if logConf.Stdout {
		consoleEncoderConfig := encoderConfig
		consoleEncoderConfig.EncodeLevel = zapcore.LowercaseColorLevelEncoder
		consoleEncoderConfig.EncodeCaller = zapcore.FullCallerEncoder // 全路径编码器
		consoleEncoder := zapcore.NewConsoleEncoder(consoleEncoderConfig)
		cores = append(cores, zapcore.NewCore(consoleEncoder, zapcore.AddSync(os.Stdout), globalAtomicLevel))
	}

	// 2. 文件日志
	if logConf.FilePath != "" {
		dir := filepath.Dir(logConf.FilePath)
		if err := os.MkdirAll(dir, 0755); err != nil {
			return nil, nil, fmt.Errorf("create log directory %q failed: %w", dir, err)
		}
		fileHook := &lumberjack.Logger{
			Filename:   logConf.FilePath,
			MaxSize:    128,
			MaxBackups: 100,
			MaxAge:     30,
			LocalTime:  true,
			Compress:   true,
		}
		fileEncoder := zapcore.NewJSONEncoder(encoderConfig)
		cores = append(cores, zapcore.NewCore(fileEncoder, zapcore.AddSync(fileHook), globalAtomicLevel))
		closers = append(closers, fileHook.Close)
	}

	// 3. Kafka 日志
	if logConf.KafkaTopic != "" && len(logConf.KafkaBrokers) > 0 {
		kw := &KafkaWriter{
			writer: &kafka.Writer{
				Addr:         kafka.TCP(logConf.KafkaBrokers...),
				Topic:        logConf.KafkaTopic,
				Async:        true,
				BatchTimeout: time.Millisecond * 100,
				BatchSize:    100,
				RequiredAcks: kafka.RequireOne,
			},
		}
		kafkaEncoderConfig := encoderConfig
		kafkaEncoder := zapcore.NewJSONEncoder(kafkaEncoderConfig)
		cores = append(cores, zapcore.NewCore(kafkaEncoder, zapcore.AddSync(kw), globalAtomicLevel))
		closers = append(closers, kw.Close)
	}

	// 保底：若所有目标均未开启，则输出到 NopCore 避免空 core panic
	if len(cores) == 0 {
		cores = append(cores, zapcore.NewNopCore())
	}

	logger := zap.New(
		zapcore.NewTee(cores...),
		zap.AddCaller(),                   // 显示打日志点的文件名和行数
		zap.AddStacktrace(zap.ErrorLevel), // 为错误添加堆栈跟踪
	)

	return logger, closers, nil
}

// Reload 完整热更新日志配置 (支持 Level、FilePath、Stdout、KafkaTopic、KafkaBrokers)
func Reload(newConf Config) error {
	confMu.Lock()
	defer confMu.Unlock()

	oldConf := currentLogConf
	oldLevel := globalAtomicLevel.Level()
	targetLevel := oldLevel
	if newConf.Level != "" {
		targetLevel = ParseLevel(newConf.Level)
	}

	levelChanged := (oldLevel != targetLevel)
	topologyChanged := (newConf.Stdout != oldConf.Stdout ||
		newConf.FilePath != oldConf.FilePath ||
		newConf.KafkaTopic != oldConf.KafkaTopic ||
		!slicesEqual(newConf.KafkaBrokers, oldConf.KafkaBrokers))

	// 无任何变动
	if !levelChanged && !topologyChanged {
		return nil
	}

	// 1. 仅日志等级发生改变：直接原子更新，零分配无缝生效
	if !topologyChanged {
		globalAtomicLevel.SetLevel(targetLevel)
		currentLogConf.Level = newConf.Level
		zap.L().Info(fmt.Sprintf("[xlog] 日志等级热更新生效: %s -> %s", oldLevel.String(), targetLevel.String()))
		return nil
	}

	// 2. 日志拓扑（输出目标、文件路径、Kafka 等）发生改变：重构 Logger 并原子替换全局指针
	globalAtomicLevel.SetLevel(targetLevel)
	newLogger, newClosers, err := buildLogger(newConf)
	if err != nil {
		return fmt.Errorf("rebuild logger failed: %w", err)
	}

	closersMu.Lock()
	oldClosers := activeClosers
	activeClosers = newClosers
	closersMu.Unlock()

	// 原子替换全局 zap Logger 实例
	zap.ReplaceGlobals(newLogger)
	currentLogConf = newConf

	// 异步延迟平滑关闭旧 Logger 底层资源（确保当前飞行中的日志全部刷写完毕）
	if len(oldClosers) > 0 {
		go func(closers []func() error) {
			time.Sleep(2 * time.Second)
			for _, c := range closers {
				_ = c()
			}
		}(oldClosers)
	}

	// 组装变更详情日志
	changes := make([]string, 0, 5)
	if levelChanged {
		changes = append(changes, fmt.Sprintf("Level: %s -> %s", oldLevel.String(), targetLevel.String()))
	}
	if oldConf.Stdout != newConf.Stdout {
		changes = append(changes, fmt.Sprintf("Stdout: %v -> %v", oldConf.Stdout, newConf.Stdout))
	}
	if oldConf.FilePath != newConf.FilePath {
		changes = append(changes, fmt.Sprintf("FilePath: %q -> %q", oldConf.FilePath, newConf.FilePath))
	}
	if oldConf.KafkaTopic != newConf.KafkaTopic {
		changes = append(changes, fmt.Sprintf("KafkaTopic: %q -> %q", oldConf.KafkaTopic, newConf.KafkaTopic))
	}
	if !slicesEqual(oldConf.KafkaBrokers, newConf.KafkaBrokers) {
		changes = append(changes, fmt.Sprintf("KafkaBrokers: %v -> %v", oldConf.KafkaBrokers, newConf.KafkaBrokers))
	}

	zap.L().Info(fmt.Sprintf("[xlog] 日志配置热更新生效: %s", strings.Join(changes, ", ")))
	return nil
}

// New 创建一个新的日志记录器
func New(conf Config) *Logger {
	confMu.Lock()
	currentLogConf = conf

	initLevel := ParseLevel(conf.Level)
	globalAtomicLevel.SetLevel(initLevel)

	logger, closers, err := buildLogger(conf)
	if err != nil {
		panic(fmt.Sprintf("init xlog failed: %v", err))
	}

	closersMu.Lock()
	activeClosers = append(activeClosers, closers...)
	closersMu.Unlock()
	confMu.Unlock()

	zap.ReplaceGlobals(logger)
	_ = logger.Sync()
	return logger
}

// Close 关闭日志组件持有的底层资源(如日志 Kafka Writer、文件句柄等),应在进程退出前调用。
// 受 closersMu 保护,Close 并发安全且只执行一次。
func Close() error {
	closersMu.Lock()
	if closersClosed {
		closersMu.Unlock()
		return nil
	}
	closersClosed = true
	closers := activeClosers
	activeClosers = nil
	closersMu.Unlock()

	var firstErr error
	for _, c := range closers {
		if err := c(); err != nil && firstErr == nil {
			firstErr = err
		}
	}
	return firstErr
}

// L 返回全局默认的 Logger 实例 (别名访问 zap.L()，外部模块无需直接 import zap)
func L() *Logger {
	return zap.L()
}

func KVStr(key string, val string) Field {
	return zap.Field{Key: key, Type: zapcore.StringType, String: val}
}

func KVInt(key string, val int) Field {
	return zap.Int(key, val)
}

func KVInt64(key string, val int64) Field {
	return zap.Int64(key, val)
}

func KVFloat64(key string, val float64) Field {
	return zap.Float64(key, val)
}

func KVBool(key string, val bool) Field {
	return zap.Bool(key, val)
}

func KVAny(key string, val any) Field {
	return zap.Any(key, val)
}

func KVErr(err error) Field {
	return zap.NamedError("error", err)
}

// WithCallerSkip 在 logger 基础上调整调用栈跳层偏移 (skip > 0 向上跳更多层，skip < 0 向下少跳)
func WithCallerSkip(logger *Logger, skip int) *Logger {
	if logger == nil {
		logger = zap.L()
	}
	return logger.WithOptions(zap.AddCallerSkip(skip))
}

// splitFieldsAndParams 分离出 zap.Field(作为顶层结构化日志字段)与其它通用参数
func splitFieldsAndParams(params ...any) ([]zap.Field, []any) {
	var fields []zap.Field
	var rest []any
	for _, p := range params {
		if f, ok := p.(zap.Field); ok {
			fields = append(fields, f)
		} else {
			rest = append(rest, p)
		}
	}
	return fields, rest
}

// logAt 所有级别日志的统一内核。skip!=0 时额外跳过调用栈层数，err!=nil 时写入结构化 error 字段。
func logAt(ctx context.Context, level zapcore.Level, skip int, message string, err error, params ...any) {
	// 基础跳过 2 层(当前 logAt + 上层 xlog.Info/Warn/Error 等封装函数), 并叠加用户指定的额外 skip
	logger := fromContext(ctx).WithOptions(zap.AddCallerSkip(2 + skip))
	fields, rest := splitFieldsAndParams(params...)
	if err != nil {
		fields = append(fields, zap.NamedError("error", err))
	}
	if len(rest) > 0 {
		fields = append(fields, zap.Any("params", rest))
	}
	logger.Log(level, message, fields...)
}

// logAtf 格式化消息版日志内核（对应 Infof/Warnf/Errorf/Debugf）。
func logAtf(ctx context.Context, level zapcore.Level, message string, params ...any) {
	// 基础跳过 2 层(当前 logAtf + 上层 xlog.Infof/Warnf 等封装函数)
	fromContext(ctx).WithOptions(zap.AddCallerSkip(2)).Log(level, fmt.Sprintf(message, params...))
}

// Info 统一的 Info 级别日志记录。支持传 zap.Field(如 KVStr/KVInt/KVErr)作为顶层结构化字段,
// 非 zap.Field 类型的参数存入 content.params 数组。
func Info(ctx context.Context, message string, params ...any) {
	logAt(ctx, zapcore.InfoLevel, 0, message, nil, params...)
}

// InfoWithSkip 支持指定额外调用栈跳过层数的 Info 日志记录。
// skip 为 0 时直接定位到调用该函数的代码行；skip > 0 向上回溯更多层调用栈。
// 常用于中间封装层（如 ORM 日志拦截器、通用中间件）精准穿透回溯到真实的业务调用点。
func InfoWithSkip(ctx context.Context, skip int, message string, params ...any) {
	logAt(ctx, zapcore.InfoLevel, skip, message, nil, params...)
}

func Infof(ctx context.Context, message string, params ...any) {
	logAtf(ctx, zapcore.InfoLevel, message, params...)
}

// Error 统一的 Error 级别日志记录。支持传 zap.Field 作为顶层结构化字段。
func Error(ctx context.Context, message string, err error, params ...any) {
	logAt(ctx, zapcore.ErrorLevel, 0, message, err, params...)
}

// ErrorWithSkip 支持指定额外调用栈跳过层数的 Error 日志记录。
func ErrorWithSkip(ctx context.Context, skip int, message string, err error, params ...any) {
	logAt(ctx, zapcore.ErrorLevel, skip, message, err, params...)
}

func Errorf(ctx context.Context, message string, params ...any) {
	logAtf(ctx, zapcore.ErrorLevel, message, params...)
}

// Warn 统一的 Warn 级别日志记录。支持传 zap.Field 作为顶层结构化字段。
func Warn(ctx context.Context, message string, params ...any) {
	logAt(ctx, zapcore.WarnLevel, 0, message, nil, params...)
}

// WarnWithSkip 支持指定额外调用栈跳过层数的 Warn 日志记录。
func WarnWithSkip(ctx context.Context, skip int, message string, params ...any) {
	logAt(ctx, zapcore.WarnLevel, skip, message, nil, params...)
}

func Warnf(ctx context.Context, message string, params ...any) {
	logAtf(ctx, zapcore.WarnLevel, message, params...)
}

// Debug 统一的 Debug 级别日志记录。支持传 zap.Field 作为顶层结构化字段。
func Debug(ctx context.Context, message string, params ...any) {
	logAt(ctx, zapcore.DebugLevel, 0, message, nil, params...)
}

// DebugWithSkip 支持指定额外调用栈跳过层数的 Debug 日志记录。
func DebugWithSkip(ctx context.Context, skip int, message string, params ...any) {
	logAt(ctx, zapcore.DebugLevel, skip, message, nil, params...)
}

func Debugf(ctx context.Context, message string, params ...any) {
	logAtf(ctx, zapcore.DebugLevel, message, params...)
}

// 将 logger 添加到 context 中
func WithLogger(ctx context.Context, logger *zap.Logger) context.Context {
	return context.WithValue(ctx, loggerKey{}, logger)
}

// 从 context 中获取 logger
func fromContext(ctx context.Context) *zap.Logger {
	if ctx == nil {
		return zap.L()
	}
	if logger, ok := ctx.Value(loggerKey{}).(*zap.Logger); ok {
		return logger
	}
	// 兜底：若 ctx 含有 trace 信息，自动附带 trace_id 与 span_id
	return WithTraceID(ctx, zap.L())
}

// 添加追踪信息到 logger
func WithTraceID(ctx context.Context, logger *zap.Logger) *zap.Logger {
	spanContext := trace.SpanContextFromContext(ctx)
	if !spanContext.IsValid() {
		return logger
	}

	return logger.With(
		zap.String("trace_id", spanContext.TraceID().String()),
		zap.String("span_id", spanContext.SpanID().String()),
	)
}

// GRPC 添加追踪信息到 logger
func WithTraceIDGRPC(ctx context.Context, logger *zap.Logger, info *grpc.UnaryServerInfo) *zap.Logger {
	spanContext := trace.SpanContextFromContext(ctx)
	if !spanContext.IsValid() {
		return logger
	}

	return logger.With(
		zap.String("trace_id", spanContext.TraceID().String()),
		zap.String("span_id", spanContext.SpanID().String()),
		zap.String("method", info.FullMethod),
	)
}
