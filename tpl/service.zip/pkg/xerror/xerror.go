/**
 * @Author:
 * @Date: 2024-03-28 15:06
 * @Desc: 统一错误接口与通用定义
 */

package xerror

// 通用系统级状态码定义
const (
	Success int = 0 // 成功
	Unknown int = 1 // 未知错误,服务不可用
)

type (
	// Error 统一业务/系统错误接口
	Error interface {
		error
		Code() int
		Error() string
	}

	defaultError struct {
		code    int
		message string
		err     error
	}
)

// 编译期确保 defaultError 满足 Error 接口
var _ Error = (*defaultError)(nil)

// NewError 创建结构化错误
func NewError(code int, message string, err error) Error {
	return &defaultError{
		code:    code,
		message: message,
		err:     err,
	}
}

// New 创建无底层 error 的结构化错误
func New(code int, message string) Error {
	return &defaultError{
		code:    code,
		message: message,
	}
}

// Wrap 包装现有错误并附加 code 与 message
func Wrap(err error, code int, message string) Error {
	return &defaultError{
		code:    code,
		message: message,
		err:     err,
	}
}

func (e *defaultError) Code() int {
	return e.code
}

func (e *defaultError) Error() string {
	return e.message
}

// Unwrap 支持 errors.Is / errors.As 穿透错误链
func (e *defaultError) Unwrap() error {
	return e.err
}
