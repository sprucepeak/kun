package service

import (
	"service/internal/event"
	"service/internal/service/svc"
	"service/pkg/token"
	// ==== Add Svc import before this line, don't edit this line.====

	"github.com/google/wire"
)

// 服务层
var WireServerSet = wire.NewSet(
	// 基础ctx
	wire.Struct(new(svc.Ctx), "*"),

	//  event
	event.NewPub,
	// ==== Add Event before this line, don't edit this line.====

	//  token (单例,与 http 层共用同一个 Jwt 实例)
	token.NewJwt,

	//  service
	wire.Struct(new(svc.DemoCtx), "*"),
	svc.NewDemoSvc,

	// ==== Add Svc before this line, don't edit this line.====
)
