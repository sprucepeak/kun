package handler

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

// MCP (Model Context Protocol) JSON-RPC 2.0 数据结构定义

type MCPRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      any             `json:"id,omitempty"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
}

type MCPResponse struct {
	JSONRPC string    `json:"jsonrpc"`
	ID      any       `json:"id"`
	Result  any       `json:"result,omitempty"`
	Error   *MCPError `json:"error,omitempty"`
}

type MCPError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    any    `json:"data,omitempty"`
}

type MCPTool struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	InputSchema map[string]any `json:"inputSchema"`
}

type MCPToolContent struct {
	Type string `json:"type"`
	Text string `json:"text"`
}

type MCPToolCallResult struct {
	Content []MCPToolContent `json:"content"`
	IsError bool             `json:"isError,omitempty"`
}

// MCP Demo 处理器: 支持标准 JSON-RPC 2.0 协议调用, 也支持直接 GET 查看固定演示值
// @Summary MCP Demo
// @Description 模型上下文协议(MCP)端点，直接返回固定数据 (支持 GET 查看元信息, POST 执行 JSON-RPC 2.0)
// @Tags api
// @Accept json
// @Produce json
// @Router /api/demo/mcp [post]
// @Router /api/demo/mcp [get]
// @Router /mcp [post]
// @Router /mcp [get]
func (d *DemoHandler) MCP(ctx *gin.Context) {
	// 1. GET 请求直接返回固定信息与说明文档
	if ctx.Request.Method == http.MethodGet {
		ctx.JSON(http.StatusOK, gin.H{
			"status":   "ok",
			"server":   "kun-service-mcp-demo",
			"version":  "1.0.0",
			"protocol": "Model Context Protocol (JSON-RPC 2.0)",
			"tools": []string{
				"get_fixed_data",
			},
			"fixed_response": gin.H{
				"id":          1001,
				"name":        "MCP Fixed Demo",
				"description": "This is a direct fixed demo value from kun-service.",
				"tags":        []string{"mcp", "agent", "kun"},
			},
		})
		return
	}

	// 2. POST 处理 JSON-RPC 2.0 请求
	var req MCPRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusOK, MCPResponse{
			JSONRPC: "2.0",
			ID:      nil,
			Error: &MCPError{
				Code:    -32700,
				Message: "Parse error: " + err.Error(),
			},
		})
		return
	}

	// 协议规范: JSON-RPC 2.0 协议版本必须为 2.0
	if req.JSONRPC != "2.0" {
		ctx.JSON(http.StatusOK, MCPResponse{
			JSONRPC: "2.0",
			ID:      req.ID,
			Error: &MCPError{
				Code:    -32600,
				Message: "Invalid Request: jsonrpc version must be '2.0'",
			},
		})
		return
	}

	// 协议规范: notifications/* 或无 ID 请求属于通知 (Notification), 客户端不期待响应实体
	if req.ID == nil || strings.HasPrefix(req.Method, "notifications/") {
		ctx.Status(http.StatusNoContent)
		return
	}

	resp := MCPResponse{
		JSONRPC: "2.0",
		ID:      req.ID,
	}

	switch req.Method {
	case "initialize":
		// 握手初始化，返回服务元信息与能力
		resp.Result = gin.H{
			"protocolVersion": "2024-11-05",
			"capabilities": gin.H{
				"tools": gin.H{},
			},
			"serverInfo": gin.H{
				"name":    "kun-service-mcp-demo",
				"version": "1.0.0",
			},
		}

	case "ping":
		// 心跳探活
		resp.Result = gin.H{}

	case "tools/list":
		// 列出可用工具
		resp.Result = gin.H{
			"tools": []MCPTool{
				{
					Name:        "get_fixed_data",
					Description: "获取 MCP 固定演示数据",
					InputSchema: map[string]any{
						"type": "object",
						"properties": map[string]any{
							"query": map[string]any{
								"type":        "string",
								"description": "可选查询参数",
							},
						},
					},
				},
			},
		}

	case "tools/call":
		var callParams struct {
			Name      string         `json:"name"`
			Arguments map[string]any `json:"arguments,omitempty"`
		}
		if len(req.Params) > 0 {
			_ = json.Unmarshal(req.Params, &callParams)
		}
		if callParams.Name != "" && callParams.Name != "get_fixed_data" {
			resp.Error = &MCPError{
				Code:    -32602,
				Message: fmt.Sprintf("Unknown tool: %s", callParams.Name),
			}
			break
		}

		// 工具调用：直接返回固定值
		fixedJSON := `{"code":0,"message":"success","data":{"id":1001,"title":"kun-mcp-demo","fixed_value":"Hello! This is a fixed value returned by Kun MCP Demo.","author":"spruce"}}`
		resp.Result = MCPToolCallResult{
			Content: []MCPToolContent{
				{
					Type: "text",
					Text: fixedJSON,
				},
			},
			IsError: false,
		}

	default:
		// 未知方法统一返回标准错误
		resp.Error = &MCPError{
			Code:    -32601,
			Message: "Method not found: " + req.Method,
		}
	}

	ctx.JSON(http.StatusOK, resp)
}
