//go:build wireinject
// +build wireinject

package wire

import (
	"service/internal/conf"
	"service/internal/handler"
	"service/internal/repository"
	"service/internal/repository/db"
	"service/internal/router"
	"service/internal/service"
	"service/pkg/xdb"
	"service/pkg/xlog"
	"service/pkg/xredis"
	"service/pkg/xserver"
	xhttp "service/pkg/xserver/http"

	"github.com/google/wire"
	"github.com/redis/go-redis/v9"
)

// 依赖注入构造 Web 应用声明函数
func WireApp(env string) (*xserver.Server, error) {
	panic(wire.Build(
		// ====配置,日志,数据库链接等====
		conf.ProviderSet,
		xlog.New,

		xdb.New,
		xredis.New,
		wire.Bind(new(redis.UniversalClient), new(*xredis.Client)),

		db.NewConn,

		// app 装配 gin 引擎 + 资源 closer;jwt 仍由 service 层的 token.NewJwt 单例注入,
		// NewHttp 与 service 共用同一实例。
		NewHttp,
		wire.FieldsOf(new(*Assembly), "Engine", "Closer"),

		xhttp.New,

		repository.WireServerSet,
		service.WireServerSet,
		handler.WireServerSet,
		router.WireServerSet,

		xserver.New,
	))
}
