/**
 * @Author: spruce
 * @Date: 2024-08-15
 * @Desc: Broker 应用装配层
 *
 * 作为 Composition Root，在 cmd/broker/wire 中组装 broker 父进程的健康探针 server(gin 模式/中间件/路由)
 * 以及构建子进程消费执行入口(kafka/asynq 消费者与生命周期信号管理)。
 */

package wire

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"service/internal/conf"
	"service/internal/event"
	"service/internal/middleware"
	"service/internal/router"
	"service/pkg/xconfig"
	"service/pkg/xdb"
	"service/pkg/xlog"
	"service/pkg/xredis"
	"service/pkg/xserver"
	"service/pkg/xserver/broker"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
)

// BrokerAssembly 装配产物。
type BrokerAssembly struct {
	Engine *gin.Engine
	Closer *xserver.Closer
}

// NewBrokerHealth 装配 broker 父进程的健康探针 gin 引擎与统一资源关闭器。
// 由 broker.Server 负责创建 http.Server 并启动。子进程无需承载 HTTP 探针，直接跳过构建以节约资源并避免重复打印日志。
func NewBrokerHealth(
	c *conf.Container,
	log *xlog.Logger,
	db *xdb.Client,
	redis *xredis.Client,
) *BrokerAssembly {
	// 资源关闭器(LIFO):xlog 先注册(最后关),redis 次之,db 注册(先关),etcd 最后注册(最先关)
	closer := xserver.NewCloser()
	closer.Add(func() error { return xlog.Close() }, "xlog")
	if redis != nil {
		closer.Add(func() error { return redis.Close() }, "redis")
	}
	if db != nil {
		closer.Add(func() error {
			sqlDB, err := db.DB()
			if err != nil {
				return err
			}
			return sqlDB.Close()
		}, "db")
	}
	if c.Watcher != nil {
		closer.Add(func() error { return c.Watcher.Close() }, "etcd-watcher")
	}

	if broker.IsChild() {
		return &BrokerAssembly{Engine: nil, Closer: closer}
	}

	c.OnUpdate(func(newConf *conf.Conf) {
		_ = xlog.Reload(newConf.Log)
	})

	// 统一设置 gin 全局模式与输出,与 http server 保持一致,避免多实例重复覆盖全局状态。
	xserver.InitGinMode(c.Env)
	engine := gin.New()
	_ = engine.SetTrustedProxies(nil)
	// 生产环境前面挂了 Nginx / K8s Ingress 网关,仅信任指定内网网关转发的 X-Forwarded-For，安全获取用户的真实公网 IP
	// _ = engine.SetTrustedProxies([]string{"127.0.0.1", "10.0.0.0/8"})

	// 性能分析 - 正式环境不要使用！！！
	if c.Env == xconfig.EnvDebug {
		pprof.Register(engine)
	}

	serviceName := c.Broker.Name
	if serviceName == "" {
		serviceName = c.Project + " Broker"
	}

	// 接管gin框架默认的日志和捕获异常。
	// Recovery 必须最先注册(位于中间件链最外层),否则 Tracing 自身 panic 时无人兜住。
	engine.Use(
		middleware.Recovery(c.Env == xconfig.EnvDebug || c.Env == xconfig.EnvTest), // 测试或开发环境
		xlog.TracingWithLogger(log, serviceName),
	)

	// 探针路由: 注册 DB 与 Redis 等核心依赖探活并支持优雅下线排空
	var checkers []router.NamedChecker
	if db != nil {
		checkers = append(checkers, router.NamedChecker{
			Name: "database",
			Check: func(ctx context.Context) error {
				sqlDB, err := db.DB()
				if err != nil {
					return err
				}
				return sqlDB.PingContext(ctx)
			},
		})
	}
	if redis != nil {
		checkers = append(checkers, router.NamedChecker{
			Name: "redis",
			Check: func(ctx context.Context) error {
				return redis.Ping(ctx).Err()
			},
		})
	}
	router.HealthChecks(engine, checkers...)

	return &BrokerAssembly{Engine: engine, Closer: closer}
}

// NewBrokerChildRun 构建 broker 子进程入口(由 broker.Server 在子进程内调用)。
// 职责:初始化 tracer、创建订阅器、启动 kafka/asynq 消费者并阻塞等待退出信号。
func NewBrokerChildRun(c *conf.Container, log *xlog.Logger, task *event.Task, closer *xserver.Closer) func() {
	return func() {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()

		if closer != nil {
			defer func() {
				_ = log.Sync()
				for _, err := range closer.Close() {
					fmt.Fprintf(os.Stderr, "child close resource err: %v\n", err)
				}
			}()
		}

		// 子进程独立初始化 TracerProvider,使 kafka/asynq 消费者产生的 span 能上报。
		// 父进程通过 fork exec 启动子进程,全局 TracerProvider 不会继承,必须重新初始化。
		serviceName := c.Broker.Name
		if serviceName == "" {
			serviceName = c.Project + " Broker"
		}
		tp := xlog.InitTracer(xlog.TracingConfig{
			ServiceName:    serviceName,
			ServiceVersion: c.Version,
			Endpoint:       c.Jaeger.Endpoint,
			SampleRate:     c.Jaeger.SampleRate,
		})
		if tp != nil {
			defer func() {
				shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 5*time.Second)
				defer shutdownCancel()
				_ = tp.Shutdown(shutdownCtx)
			}()
		}

		// 子进程统一监听退出信号:取消 ctx,驱动各消费者(kafka/asynq)优雅退出。
		go func() {
			signals := make(chan os.Signal, 1)
			signal.Notify(signals, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
			<-signals
			cancel()
		}()

		var wg sync.WaitGroup
		sub := event.NewSub(&wg, c, task, ctx, log)

		// kafka subscriber
		sub.Kafka()
		// asynq subscriber
		if err := sub.Asynq(); err != nil {
			// 启动失败:cancel ctx 触发已启动的消费者退出,等待收尾后退出进程。
			log.Error(fmt.Sprintf("asynq subscriber start failed: %v", err))
			cancel()
			wg.Wait()
			sub.Close()
			return
		}
		// asynq CronPush(cron 启动失败不致命,记录后继续运行主消费)
		if err := sub.AsynqCron(); err != nil {
			log.Error(fmt.Sprintf("asynq cron start failed: %v", err))
		}

		wg.Wait()
		sub.Close()
	}
}
