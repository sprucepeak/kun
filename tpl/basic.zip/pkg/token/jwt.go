/**
* @Author: spruce
 * @Date: 2024-03-28 10:34
 * @Desc: jwt 签名,验签
*/

package token

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"basic/pkg/encrypt"
	"basic/pkg/utils"
	"basic/pkg/xconfig"
	"basic/pkg/xlog"
	"basic/pkg/xredis"

	v5 "github.com/golang-jwt/jwt/v5"
)

const (
	ErrorMissingSecret uint32 = 1 << iota
	ErrorExpiredToken
	ErrorAuthorizeElsewhere
	ErrorUserBanned
	ErrorEmptyAuthHeader
	ErrorMissingIatField
	ErrorMissingExpField
	ErrorInvalidPublicKey
	ErrorInvalidPrivateKey
	ErrorNoPublicKeyFile
	ErrorNoPrivateKeyFile
	ErrorInvalidSigningAlgorithm
	ErrorEmptyToken
	ErrorFailedTokenCreation
	ErrorInvalidToken
	ErrorTokenEmpty // 无效的token

	DefaultQuery       = "Authorization"
	DefaultGracePeriod = 30 * time.Second
	DefaultMaxRefresh  = 30 * 24 * time.Hour // 绝对最大有效期30天

	TokenTypeAccess  = "somebody"
	TokenTypeRefresh = "refresh"

	DisuseReasonLogout      = "logout"      // 主动登出
	DisuseReasonKicked      = "kicked"      // 被后登录设备顶下线
	DisuseReasonCompromised = "compromised" // 凭证泄露/检测到重放攻击强制吊销整个会话族

	// Redis Key 统一模式定义 (完整占位符定义，清晰直观，统一维护)
	// 统一定义于此处，统一带有 {u:%s} Hash Tag，确保同一用户的所有 Key 在 Redis Cluster 集群分片下 100% 路由至同一 Slot，彻底杜绝 CROSSSLOT 风险
	KeyPatternTokenDisuse = "td:{u:%s}:t:%s"   // 单 Token 作废/黑名单键 (占位符: %s=userId, %s=tokenMd5)
	KeyPatternSession     = "td:{u:%s}:s:%s"   // 会话 SID 状态/黑名单键 (占位符: %s=userId, %s=sid)
	KeyPatternBan         = "td:{u:%s}:b"      // 用户全局封号状态键 (占位符: %s=userId)
	KeyPatternMinAuth     = "td:{u:%s}:m"      // 强制全端下线时间戳键 (占位符: %s=userId)
	KeyPatternCurrentSid  = "td:{u:%s}:cs"     // 单端登录活跃会话记录键 (占位符: %s=userId)
	KeyPatternRotated     = "td:{u:%s}:rot:%s" // 刷新轮换宽限期缓存键 (占位符: %s=userId, %s=tokenMd5)

	// SigningAlgorithm 固定的签名算法,Parse 时仅允许该算法,防止算法降级
	SigningAlgorithm = "HS384"

	// minSecretLen HS384 签名可接受的最小密钥长度(字节,即 256bit)。
	minSecretLen = 32

	// checkTokenLua 用于在 Redis 内部原子执行全量鉴权检查(单Token黑名单、用户封号、全端下线时间戳、会话SID状态)
	// 配合 {u:userId} Hash Tag 使用，保证在 Redis Cluster 集群分片下 100% 落在同一 Slot，杜绝 CROSSSLOT 错误
	// 返回值: 0: 正常放行, 1: ErrInvalidToken, 2: ErrUserBanned, 3: ErrAuthorizeElsewhere
	checkTokenLua = `
local tokenKey = KEYS[1]
local sidKey = KEYS[2]
local banKey = KEYS[3]
local minAuthKey = KEYS[4]
local authTime = tonumber(ARGV[1])

-- 1. 单 Token 作废检查 (如轮换后的旧 accessToken)
if tokenKey ~= '' and redis.call('EXISTS', tokenKey) == 1 then
    return 1
end

-- 2. 用户封号检查 (管理员封禁)
if banKey ~= '' and redis.call('EXISTS', banKey) == 1 then
    return 2
end

-- 3. 强制全端下线时间戳检查 (管理员强制下线)
if minAuthKey ~= '' then
    local minAuth = redis.call('GET', minAuthKey)
    if minAuth and authTime and authTime <= tonumber(minAuth) then
        return 3
    end
end

-- 4. 会话 SID 黑名单检查 (单端被顶下线 或 主动登出 或 凭据泄露重放吊销)
-- 若 sidKey 仅为占位键(:s:_结尾)，跳过 GET 查询，节约一次 Redis 内存指令
if sidKey ~= '' and not string.find(sidKey, ':s:_$') then
    local sidVal = redis.call('GET', sidKey)
    if sidVal then
        if sidVal == 'kicked' then
            return 3
        else
            return 1
        end
    end
end

return 0
`
)

var (
	// checkTokenScript 预编译校验脚本 (底层由 xredis 自动执行 EVALSHA，高并发下节约 95% 网络流量与带宽)
	checkTokenScript = xredis.NewScript(checkTokenLua)

	// clearSessionScript 预编译原子清理会话脚本
	clearSessionScript = xredis.NewScript(`
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
else
    return 0
end
`)

	// switchSessionScript 预编译原子置换会话并设置 TTL 脚本
	// 在 Lua 原子执行上下文中，连续调用 GET 与 SETEX 兼具绝对原子性与 100% 全版本兼容性(兼容 Redis 2.6+ / 5.x / 6.x / 7.x+ 及各类云原生代理)
	// 彻底消除对 Redis 6.2+ "SET ... GET" 特有语法的版本依赖
	switchSessionScript = xredis.NewScript(`
local old = redis.call('GET', KEYS[1])
redis.call('SETEX', KEYS[1], tonumber(ARGV[2]), ARGV[1])
return old
`)

	bindPrefix = []byte("bind:")
)

// maxTokenLen 允许的最大 Token 字符串长度 (4KB 足够容纳任何包含扩展声明的标准 JWT，防范恶意超大包造成内存/CPU耗尽攻击)
const maxTokenLen = 4096

// CleanToken 清洗 Token 字符串，去除首尾空白并剥离 "Bearer " 前缀（忽略大小写）
func CleanToken(tokenStr string) string {
	if len(tokenStr) > maxTokenLen {
		return ""
	}
	tokenStr = strings.TrimSpace(tokenStr)
	if len(tokenStr) >= 7 && strings.EqualFold(tokenStr[:7], "bearer ") {
		tokenStr = strings.TrimSpace(tokenStr[7:])
	}
	return tokenStr
}

// ================= Redis Key 统一生成器 (严格注入 {u:userId} Hash Tag 保证 100% 同槽，原生拼接消除 fmt.Sprintf 反射与堆分配开销) =================

// tokenKey 单 Token 作废键 (对应 KeyPatternTokenDisuse: td:{u:userId}:t:<tokenMd5>)
func (j *Jwt) tokenKey(userId, tokenStr string) string {
	tokenStr = CleanToken(tokenStr)
	if userId == "" {
		userId = j.extractUserIdFromToken(tokenStr)
	}
	return "td:{u:" + userId + "}:t:" + encrypt.MD5(tokenStr)
}

// sidKey 会话 SID 黑名单键 (对应 KeyPatternSession: td:{u:userId}:s:<sid>)
func (j *Jwt) sidKey(userId, sid string) string {
	if userId == "" {
		userId = extractUserIdFromSid(sid)
	}
	return "td:{u:" + userId + "}:s:" + sid
}

// banKey 用户封号状态键 (对应 KeyPatternBan: td:{u:userId}:b)
func (j *Jwt) banKey(userId string) string {
	return "td:{u:" + userId + "}:b"
}

// minAuthKey 强制全端下线时间戳键 (对应 KeyPatternMinAuth: td:{u:userId}:m)
func (j *Jwt) minAuthKey(userId string) string {
	return "td:{u:" + userId + "}:m"
}

// currentSidKey 单端登录活跃会话记录键 (对应 KeyPatternCurrentSid: td:{u:userId}:cs)
func (j *Jwt) currentSidKey(userId string) string {
	return "td:{u:" + userId + "}:cs"
}

// rotatedKey 刷新轮换宽限期缓存键 (对应 KeyPatternRotated: td:{u:userId}:rot:<tokenMd5>)
func (j *Jwt) rotatedKey(userId, refreshToken string) string {
	refreshToken = CleanToken(refreshToken)
	if userId == "" {
		userId = j.extractUserIdFromToken(refreshToken)
	}
	return "td:{u:" + userId + "}:rot:" + encrypt.MD5(refreshToken)
}

func extractUserIdFromSid(sid string) string {
	if idx := strings.IndexByte(sid, '_'); idx > 0 {
		return sid[:idx]
	}
	return ""
}

func (j *Jwt) extractUserIdFromToken(tokenStr string) string {
	tokenStr = CleanToken(tokenStr)
	if tokenStr == "" {
		return ""
	}
	// 优先快速通过非验签方式提取 Subject (零密码学哈希计算，复用常驻 parser 实例，避免重复堆分配与无谓的 HMAC 计算)
	payload := &Claims{}
	if _, _, err := j.parser.ParseUnverified(tokenStr, payload); err == nil && payload.Subject != "" {
		return payload.Subject
	}
	return ""
}

// cryptoRandomHex 生成指定字节数的密码学安全随机十六进制字符串 (CSPRNG, 彻底杜绝伪随机数被预测风险)
func cryptoRandomHex(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		// 极端情况下系统熵池异常，降级兜底但不中断服务
		return utils.GenUUid()
	}
	return hex.EncodeToString(b)
}

var (
	ErrInvalidSigningAlgorithm = newError("invalid signing algorithm", ErrorInvalidSigningAlgorithm)
	ErrInvalidToken            = newError("token is invalid", ErrorInvalidToken)
	ErrRevokedToken            = newError("token has been revoked", ErrorInvalidToken) // Token 已被主动作废/列入黑名单
	ErrEmptyToken              = newError("token is empty", ErrorEmptyToken)
	ErrMissingIatField         = newError("missing iat field", ErrorMissingIatField)
	ErrMissingExpField         = newError("missing exp field", ErrorMissingExpField)
	ErrExpiredToken            = newError("token is expired", ErrorExpiredToken)
	ErrAuthorizeElsewhere      = newError("account logged in on another device", ErrorAuthorizeElsewhere)
	ErrUserBanned              = newError("user is banned", ErrorUserBanned)
)

type (
	Claims struct {
		v5.RegisteredClaims
		SID      string `json:"sid,omitempty"`       // 会话/双Token族唯一标识(用于单会话安全注销)
		AuthTime int64  `json:"auth_time,omitempty"` // 首次登录认证时间戳(秒)
	}

	Jwt struct {
		mu                 sync.RWMutex   // 保护运行时动态热重载的配置字段
		Cache              *xredis.Client // 缓存
		ExpireTime         time.Duration  // 访问token过期时间
		RefreshTime        time.Duration  // 刷新token单次有效期
		MaxRefreshTime     time.Duration  // 刷新token绝对最大有效期(防无限续签)
		GracePeriod        time.Duration  // 轮换宽限期(防并发请求误杀)
		MultiLogin         bool           // 是否允许多端登录(false时后登录顶掉先登录)
		Secret             string         // 加密密钥
		RefreshSecret      string         // 刷新密钥
		CSRFKey            string         // CSRF 密钥
		QueryKey           string         // Token查找key
		secretBytes        []byte         // 预转化的密钥字节，避免高频加解签堆内存重复分配
		refreshSecretBytes []byte         // 预转化的刷新密钥字节
		keyFuncAccess      v5.Keyfunc     // 预绑定的 AccessToken 验签回调
		keyFuncRefresh     v5.Keyfunc     // 预绑定的 RefreshToken 验签回调
		parser             *v5.Parser     // 复用 Parser 实例，消除高频验签堆内存分配
	}

	JwtToken struct {
		AccessToken     string `json:"accessToken"`     // 访问token
		AccessExpireAt  int64  `json:"accessExpireAt"`  // 访问token过期时间戳
		RefreshToken    string `json:"refreshToken"`    // 刷新token
		RefreshExpireAt int64  `json:"refreshExpireAt"` // 刷新token过期时间戳
	}
)

// Reload 动态重载 Token 配置（包括密钥、有效期、多端策略等）
// 无论是 etcd 变更还是本地 yaml 变更，均可由 xconfig.OnUpdate 触发
func (j *Jwt) Reload(conf xconfig.TokenConf) error {
	if conf.Secret == "" || conf.RefreshSecret == "" {
		return fmt.Errorf("token secret 和 refreshSecret 不能为空")
	}
	if conf.Secret == conf.RefreshSecret {
		return fmt.Errorf("token secret 与 refreshSecret 禁止相同，双 Token 架构必须使用独立密钥以实现权限域强隔离")
	}
	if len(conf.Secret) < minSecretLen || len(conf.RefreshSecret) < minSecretLen {
		return fmt.Errorf("token secret/refreshSecret 长度不足:至少 %d 字节(推荐 48 字节,即 HS384 的 384bit)", minSecretLen)
	}
	if conf.CSRFKey != "" && len(conf.CSRFKey) != 32 {
		return fmt.Errorf("token csrfKey 长度必须为 32 字节(当前为 %d 字节),请检查配置", len(conf.CSRFKey))
	}

	expireTime := 2 * time.Hour
	if conf.Expire > 0 {
		expireTime = time.Duration(conf.Expire) * time.Second
	}
	refreshTime := 24 * 7 * time.Hour
	if conf.Refresh > 0 {
		refreshTime = time.Duration(conf.Refresh) * time.Second
	}
	if refreshTime <= expireTime {
		return fmt.Errorf("刷新时间必须大于 token 的过期时间")
	}

	maxRefreshTime := DefaultMaxRefresh
	if conf.MaxRefresh > 0 {
		maxRefreshTime = time.Duration(conf.MaxRefresh) * time.Second
	} else if conf.MaxRefresh < 0 {
		maxRefreshTime = 0
	}
	if maxRefreshTime > 0 && maxRefreshTime < refreshTime {
		return fmt.Errorf("MaxRefresh (%v) 绝对最大有效期不能小于单次刷新有效期 Refresh (%v)", maxRefreshTime, refreshTime)
	}

	gracePeriod := DefaultGracePeriod
	if conf.GracePeriod > 0 {
		gracePeriod = time.Duration(conf.GracePeriod) * time.Second
	}

	queryKey := DefaultQuery
	if conf.QueryKey != "" {
		queryKey = conf.QueryKey
	}

	secretBytes := []byte(conf.Secret)
	refreshSecretBytes := []byte(conf.RefreshSecret)

	j.mu.Lock()
	defer j.mu.Unlock()

	j.Secret = conf.Secret
	j.RefreshSecret = conf.RefreshSecret
	j.CSRFKey = conf.CSRFKey
	j.QueryKey = queryKey
	j.secretBytes = secretBytes
	j.refreshSecretBytes = refreshSecretBytes
	j.ExpireTime = expireTime
	j.RefreshTime = refreshTime
	j.MaxRefreshTime = maxRefreshTime
	j.GracePeriod = gracePeriod
	j.MultiLogin = conf.MultiLogin

	return nil
}

// NewJwt 创建
func NewJwt(conf *xconfig.Conf, redisCli *xredis.Client) (*Jwt, error) {
	if redisCli == nil {
		return nil, fmt.Errorf("token 需要redis的支持,请检查redis的配置")
	}

	j := &Jwt{
		Cache: redisCli,
		parser: v5.NewParser(
			v5.WithValidMethods([]string{SigningAlgorithm}),
			v5.WithExpirationRequired(),
			v5.WithLeeway(2*time.Second), // 2秒时钟容错，平抑微服务/K8s多节点集群间 NTP 微小时钟漂移
		),
	}

	// 绑定动态验签回调，实时从读锁读取最新密钥字节
	j.keyFuncAccess = func(token *v5.Token) (any, error) {
		j.mu.RLock()
		defer j.mu.RUnlock()
		return j.secretBytes, nil
	}
	j.keyFuncRefresh = func(token *v5.Token) (any, error) {
		j.mu.RLock()
		defer j.mu.RUnlock()
		return j.refreshSecretBytes, nil
	}

	// 初次加载配置
	if err := j.Reload(conf.Token); err != nil {
		return nil, err
	}

	// 注册配置监听器：无论是 etcd 修改还是本地 yaml 修改，Token 配置实时热更新生效
	conf.OnUpdate(func(newConf *xconfig.Conf) {
		if err := j.Reload(newConf.Token); err != nil {
			xlog.Error(context.Background(), "[jwt] Token配置热更新校验失败", err)
		} else {
			xlog.Info(context.Background(), "[jwt] Token配置热更新成功生效")
		}
	})

	return j, nil
}

// Gen 生成 token AccessToken和RefreshToken,携带 userId 和 roleId (新登录签发全新 SID 会话标识)
func (j *Jwt) Gen(userId, roleId int64) (*JwtToken, error) {
	return j.GenWithSession(context.Background(), userId, roleId, "", time.Now().Unix())
}

// GenWithSession 生成 token (支持透传请求级 Context)
func (j *Jwt) GenWithSession(ctx context.Context, userId, roleId int64, sid string, authTime int64) (*JwtToken, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	cTime := time.Now()
	// isNewLogin: sid=="" 表示全新登录(Gen 路径)，sid!="" 表示续签轮换(Refresh 路径)
	// 不能用 authTime<=0 判断，Gen 传入 time.Now().Unix()（正整数），authTime<=0 永远不成立
	isNewLogin := sid == ""
	if authTime <= 0 {
		authTime = cTime.Unix()
	}
	// uidStr 提前声明，isNewLogin 保护、单端踢人、Subject 三处共享，消除重复 strconv.FormatInt 开销
	uidStr := strconv.FormatInt(userId, 10)
	// 仅对全新登录签发(isNewLogin)做防同秒误杀保护:
	// 若当前存在全端下线时间戳 min_auth_time 且 authTime <= minAuth, 自动上浮为 minAuth + 1
	// 续签刷新流程(isNewLogin==false)绝不能上浮，必须严格保留原始认证时间以接受 min_auth 踢出检查！
	if isNewLogin && j.Cache != nil && userId > 0 {
		if minAuthStr, err := j.Cache.Get(ctx, j.minAuthKey(uidStr)).Result(); err == nil && minAuthStr != "" {
			if minAuthVal, _ := strconv.ParseInt(minAuthStr, 10, 64); minAuthVal >= authTime {
				authTime = minAuthVal + 1
			}
		}
	}
	// 确保 SID 始终带有 userId 前缀 (<userId>_<uuid>)，保证 extractUserIdFromSid 能稳定提取 userId 生成 Hash Tag
	if sid == "" {
		sid = fmt.Sprintf("%d_%s", userId, utils.GenUUid())
	} else if !strings.Contains(sid, "_") {
		sid = fmt.Sprintf("%d_%s", userId, sid)
	}

	j.mu.RLock()
	expireTime := j.ExpireTime
	refreshTime := j.RefreshTime
	maxRefreshTime := j.MaxRefreshTime
	multiLogin := j.MultiLogin
	secretBytes := j.secretBytes
	refreshSecretBytes := j.refreshSecretBytes
	j.mu.RUnlock()

	// 单端登录控制: 若禁止多端登录(!multiLogin)，后登录顶掉先登录 (使用原子 Lua 脚本置换会话并同步更新 TTL，杜绝并发覆盖与 TTL 丢失隐患)
	if !multiLogin && j.Cache != nil && userId > 0 {
		userKey := j.currentSidKey(uidStr)
		sessionTTL := refreshTime
		if maxRefreshTime > 0 && maxRefreshTime > sessionTTL {
			sessionTTL = maxRefreshTime
		}

		oldSid, err := switchSessionScript.Run(ctx, j.Cache, []string{userKey}, sid, int(sessionTTL.Seconds())).Text()
		if err == nil && oldSid != "" && oldSid != sid {
			// 存在先登录会话且不是当前会话(刷新流程中 oldSid == sid)，将旧会话标记为 kicked
			if disErr := j.DisuseSessionWithReason(ctx, oldSid, int64(sessionTTL.Seconds()), DisuseReasonKicked); disErr != nil {
				// 遭遇网络波动等异常时原地轻量重试一次，确保旧会话被坚决踢出
				_ = j.DisuseSessionWithReason(ctx, oldSid, int64(sessionTTL.Seconds()), DisuseReasonKicked)
			}
		}
	}

	claims := Claims{
		RegisteredClaims: v5.RegisteredClaims{
			Subject:   uidStr,                                         // 主题,用户id
			Issuer:    strconv.FormatInt(roleId, 10),                  // 签发人,角色id
			IssuedAt:  v5.NewNumericDate(cTime),                       // 颁发时间
			NotBefore: v5.NewNumericDate(cTime.Add(-1 * time.Second)), // 生效时间
			ExpiresAt: v5.NewNumericDate(cTime.Add(expireTime)),       // 过期时间
			Audience:  []string{TokenTypeAccess},                      // 观众,[类型]
			ID:        cryptoRandomHex(16),                            // 密码学安全随机 JTI (CSPRNG, 彻底杜绝伪随机序列被预测风险)
		},
		SID:      sid,
		AuthTime: authTime,
	}
	accessExpireAt := claims.ExpiresAt.Unix()
	accessToken, err := v5.NewWithClaims(v5.SigningMethodHS384, claims).SignedString(secretBytes)
	if err != nil {
		return nil, err
	}

	refreshExpire := cTime.Add(refreshTime)
	if maxRefreshTime > 0 {
		maxExpire := time.Unix(authTime, 0).Add(maxRefreshTime)
		if refreshExpire.After(maxExpire) {
			refreshExpire = maxExpire
		}
	}

	refreshClaims := Claims{
		RegisteredClaims: v5.RegisteredClaims{
			Subject:   claims.Subject,                   // 主题,用户id(便于按用户封禁)
			Issuer:    claims.Issuer,                    // 签发人,角色id
			IssuedAt:  claims.IssuedAt,                  // 颁发时间
			NotBefore: claims.NotBefore,                 // 生效时间
			ExpiresAt: v5.NewNumericDate(refreshExpire), // 过期时间(受绝对上限保护)
			Audience:  []string{TokenTypeRefresh},       // 观众,[类型]
			ID:        j.deriveRefreshIDWithSecret(claims.ID, secretBytes), // 基于 access.ID 密码学派生绑定 (HMAC-SHA256)
		},
		SID:      sid,
		AuthTime: authTime,
	}
	refreshExpireAt := refreshClaims.ExpiresAt.Unix()
	refreshToken, err := v5.NewWithClaims(v5.SigningMethodHS384, refreshClaims).SignedString(refreshSecretBytes)
	if err != nil {
		return nil, err
	}

	return &JwtToken{
		AccessToken:     accessToken,     // 访问token
		AccessExpireAt:  accessExpireAt,  // 访问token过期时间戳
		RefreshToken:    refreshToken,    // 刷新token
		RefreshExpireAt: refreshExpireAt, // 刷新token过期时间戳
	}, nil
}

// deriveRefreshID 使用 HMAC-SHA256 基于 accessID 单向派生配对的 refreshID (密码学防伪且精炼)
// 用两次 Write 代替字符串拼接，消除 "bind:"+accessID 产生的临时堆分配
func (j *Jwt) deriveRefreshID(accessID string) string {
	j.mu.RLock()
	secret := j.secretBytes
	j.mu.RUnlock()
	return j.deriveRefreshIDWithSecret(accessID, secret)
}

func (j *Jwt) deriveRefreshIDWithSecret(accessID string, secret []byte) string {
	mac := hmac.New(sha256.New, secret)
	mac.Write(bindPrefix)
	mac.Write([]byte(accessID))
	return hex.EncodeToString(mac.Sum(nil)[:16]) // 16 字节 -> 32 位 hex
}

// waitRotatedToken 轮询等待并发抢占请求写入宽限期缓存 (递增微退避，快速响应同时防止 Redis 击穿)
func (j *Jwt) waitRotatedToken(ctx context.Context, rotatedKey string) (*JwtToken, error) {
	delays := []time.Duration{10 * time.Millisecond, 15 * time.Millisecond, 20 * time.Millisecond, 25 * time.Millisecond}
	totalWait := time.Duration(0)
	const maxWait = 500 * time.Millisecond

	for i := 0; totalWait < maxWait; i++ {
		delay := delays[len(delays)-1]
		if i < len(delays) {
			delay = delays[i]
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-time.After(delay):
			totalWait += delay
		}
		if val, err := j.Cache.Get(ctx, rotatedKey).Result(); err == nil && val != "" {
			var cachedToken JwtToken
			if err := json.Unmarshal([]byte(val), &cachedToken); err == nil {
				return &cachedToken, nil
			}
		}
	}
	return nil, nil
}

// Refresh 刷新token (支持请求级 Context，透传 trace/超时/取消)
func (j *Jwt) Refresh(ctx context.Context, accessToken, refreshToken string) (*JwtToken, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	accessToken = CleanToken(accessToken)
	refreshToken = CleanToken(refreshToken)
	if accessToken == "" || refreshToken == "" {
		return nil, ErrEmptyToken
	}

	userIdStr := j.extractUserIdFromToken(refreshToken)
	rotatedKey := j.rotatedKey(userIdStr, refreshToken)

	// 1. 先检查轮换宽限期缓存(Grace Period):
	// 若并发或重试请求在宽限期内到达，直接返回已签发的新 Token，避免重复轮换或误判重放拉黑正常用户
	if val, err := j.Cache.Get(ctx, rotatedKey).Result(); err == nil && val != "" {
		var cachedToken JwtToken
		if err := json.Unmarshal([]byte(val), &cachedToken); err == nil {
			return &cachedToken, nil
		}
	}

	keepOld := true
	// 先判断 refresh token 是否有效
	refreshClaims, err := j.Parse(ctx, refreshToken, TokenTypeRefresh)
	if err != nil {
		// 仅当 refreshToken 结构与签名合法但被列入黑名单时(ErrRevokedToken)，才可能是并发请求刚刚抢占轮换，
		// 此时进入短时微退避等待读取宽限期缓存(快速释放资源，防并发误杀)。
		// 若为伪造/篡改的非法 Token(ErrInvalidToken)，0 毫秒立即打回拒绝，彻底杜绝 DoS 放大与死等漏洞！
		if errors.Is(err, ErrRevokedToken) {
			if cachedToken, waitErr := j.waitRotatedToken(ctx, rotatedKey); waitErr != nil {
				return nil, waitErr
			} else if cachedToken != nil {
				return cachedToken, nil
			}
			// 重试后仍未找到轮换缓存，说明已被轮换且超过宽限期 => 确认属于重放攻击(Replay Attack), 吊销该会话族并明确记录 Compromised 原因
			if unverifiedClaims, parseErr := j.ParseWithoutBlacklist(refreshToken, TokenTypeRefresh); parseErr == nil && unverifiedClaims.SID != "" {
				_ = j.DisuseSessionWithReason(ctx, unverifiedClaims.SID, int64(j.RefreshTime.Seconds()), DisuseReasonCompromised)
			}
		}
		return nil, err
	}

	// 绝对超时检查: 如果已经超过绝对最大有效期，直接拒绝刷新，强制重新登录
	now := time.Now()
	authTime := refreshClaims.AuthTime
	if authTime <= 0 {
		authTime = refreshClaims.IssuedAt.Unix()
	}
	if j.MaxRefreshTime > 0 && now.Unix()-authTime >= int64(j.MaxRefreshTime.Seconds()) {
		return nil, ErrExpiredToken
	}

	// 3min前的token生成新的token,3min内不变
	if refreshClaims.IssuedAt.Unix() < now.Unix()-180 {
		keepOld = false
	}

	// 解析原的AccessToken,允许已过期(过期时claims仍会返回)
	accessClaims, err := j.Parse(ctx, accessToken, TokenTypeAccess)
	if err != nil && errors.Is(err, ErrExpiredToken) {
		keepOld = false
	} else if err != nil {
		return nil, err
	}

	// 纵深防御 1: 校验双 Token 的 Subject (用户ID) 必须完全一致
	if accessClaims.Subject != refreshClaims.Subject {
		return nil, ErrInvalidToken
	}
	// 纵深防御 2: 若两者均携带 SID，必须归属于同一会话
	if accessClaims.SID != "" && refreshClaims.SID != "" && accessClaims.SID != refreshClaims.SID {
		return nil, ErrInvalidToken
	}

	// 绑定校验: 校验 refreshToken 是否由该 accessToken 派生绑定 (HMAC-SHA256，常量时间比较杜绝时序侧信道攻击)
	expectedRefreshID := j.deriveRefreshID(accessClaims.ID)
	if subtle.ConstantTimeCompare([]byte(expectedRefreshID), []byte(refreshClaims.ID)) != 1 {
		return nil, ErrInvalidToken
	}

	if keepOld {
		return &JwtToken{
			AccessToken:     accessToken,                    // 访问token
			AccessExpireAt:  accessClaims.ExpiresAt.Unix(),  // 访问token过期时间戳
			RefreshToken:    refreshToken,                   // 刷新token
			RefreshExpireAt: refreshClaims.ExpiresAt.Unix(), // 刷新token过期时间戳
		}, nil
	}

	j.mu.RLock()
	refreshTime := j.RefreshTime
	gracePeriod := j.GracePeriod
	j.mu.RUnlock()

	refreshRemain := refreshClaims.ExpiresAt.Unix() - now.Unix()
	if refreshRemain <= 0 {
		refreshRemain = int64(refreshTime.Seconds())
	}

	// 原子抢占旧 refreshToken:失败说明已被其它并发请求抢先轮换 (直接传入已知 userId，避免无谓的重复 JWT 反序列化)
	claimed, claimErr := j.disuseTokenIfAbsent(ctx, refreshClaims.Subject, refreshToken, refreshRemain)
	if claimErr != nil {
		return nil, fmt.Errorf("刷新token失败: %w", claimErr)
	}
	if !claimed {
		// 并发竞争：可能并发请求刚刚抢占并正在写入宽限期缓存，短时间微退避重试读取
		if cachedToken, waitErr := j.waitRotatedToken(ctx, rotatedKey); waitErr != nil {
			return nil, waitErr
		} else if cachedToken != nil {
			return cachedToken, nil
		}
		// 重试后仍未找到轮换缓存，说明已被轮换且超过宽限期 => 视为复用(泄露信号), 吊销该会话族并明确归因为 Compromised
		if refreshClaims.SID != "" {
			_ = j.DisuseSessionWithReason(ctx, refreshClaims.SID, refreshRemain, DisuseReasonCompromised)
		}
		return nil, ErrRevokedToken
	}

	userId, err := strconv.ParseInt(accessClaims.Subject, 10, 64)
	if err != nil || userId <= 0 {
		return nil, ErrInvalidToken
	}
	roleId, _ := strconv.ParseInt(accessClaims.Issuer, 10, 64)
	sid := refreshClaims.SID
	if sid == "" {
		sid = accessClaims.SID
	}
	if sid == "" {
		sid = utils.GenUUid()
	}
	token, tokenErr := j.GenWithSession(ctx, userId, roleId, sid, authTime)
	if tokenErr != nil {
		// 若生成失败，尝试恢复抢占以便重试
		_ = j.rollbackTokenDisuse(ctx, refreshClaims.Subject, refreshToken)
		return nil, tokenErr
	}

	// 记录到轮换宽限期缓存(TTL 为 GracePeriod，例如 30s)
	if tokenBytes, err := json.Marshal(token); err == nil {
		_ = j.Cache.Set(ctx, rotatedKey, string(tokenBytes), gracePeriod).Err()
	}

	// 旧 accessToken 延迟废弃(给予 10s 飞行中请求缓冲期, 避免并发 in-flight 请求因网络毫秒差被误杀)
	// 安全防御：黑名单 TTL 必须严格覆盖该 Token 的剩余有效时长(accessRemain)，杜绝提前过期导致旧 Token"起死回生"重放
	if accessRemain := accessClaims.ExpiresAt.Unix() - now.Unix(); accessRemain > 0 {
		const inFlightBuffer = 10 * time.Second
		if time.Duration(accessRemain)*time.Second > inFlightBuffer {
			disuseTTL := accessRemain - int64(inFlightBuffer.Seconds())
			time.AfterFunc(inFlightBuffer, func() {
				defer func() {
					_ = recover() // 隔离后台异步协程的极端 panic，保证服务进程绝对安全
				}()
				if j.Cache == nil {
					return
				}
				bgCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				defer cancel()
				_ = j.DisuseUserToken(bgCtx, accessClaims.Subject, accessToken, disuseTTL)
			})
		}
	}
	return token, nil
}

// Find 从 HTTP 请求中查找并清洗 Token（依次从 Header -> Cookie -> URL Query 查找，自动去除空白及 Bearer 前缀）
func (j *Jwt) Find(r *http.Request) string {
	j.mu.RLock()
	queryKey := j.QueryKey
	j.mu.RUnlock()

	var tokenStr string
	// 1. 从 HEADER 中获取 TOKEN (推荐,不会泄漏到日志/Referer)
	if s := r.Header.Get(queryKey); s != "" {
		tokenStr = s
	} else if cookie, _ := r.Cookie(queryKey); cookie != nil && cookie.Value != "" {
		// 2. 从 COOKIE 中获取 TOKEN
		tokenStr = cookie.Value
	} else {
		// 3. 从 URL QUERY 中获取 TOKEN (支持原生 WebSocket 握手或流式 GET 接口)
		// 容错兼容 URL Query 大小写敏感特性
		q := r.URL.Query()
		if s := q.Get(queryKey); s != "" {
			tokenStr = s
		} else if lowerKey := strings.ToLower(queryKey); lowerKey != queryKey && q.Get(lowerKey) != "" {
			tokenStr = q.Get(lowerKey)
		}
	}

	return CleanToken(tokenStr)
}

// Parse 解析
// ctx 用于传递 trace/request 信息给 Redis 查询;传 nil 时回退到 background context
func (j *Jwt) Parse(ctx context.Context, tokenStr string, optType ...string) (*Claims, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	tokenStr = CleanToken(tokenStr)
	if tokenStr == "" {
		return nil, ErrEmptyToken
	}
	tokenType := TokenTypeAccess
	keyFunc := j.keyFuncAccess
	if len(optType) > 0 && optType[0] == TokenTypeRefresh {
		tokenType = TokenTypeRefresh
		keyFunc = j.keyFuncRefresh
	}

	// 1. 签名与 Claims 解析: 验签失败或格式错误立即返回，零 Redis 开销防 DoS (复用 parser 与预绑定 keyFunc)
	payload := &Claims{}
	claim, err := j.parser.ParseWithClaims(tokenStr, payload, keyFunc)
	if err != nil && !errors.Is(err, v5.ErrTokenExpired) {
		return nil, ErrInvalidToken
	}
	if claim == nil {
		return nil, ErrInvalidToken
	}

	// 判断token类型与基础字段
	if len(payload.Audience) != 1 || payload.Audience[0] != tokenType {
		return nil, ErrInvalidToken
	}
	if payload.Subject == "" || payload.Issuer == "" || payload.ID == "" {
		return nil, ErrInvalidToken
	}

	cTime := time.Now()
	// 生效时间检查 (NotBefore 可选,缺失时视作"已生效",跳过校验,避免对 nil *NumericDate 解引用 panic)
	if payload.NotBefore != nil && payload.NotBefore.After(cTime) {
		return nil, ErrInvalidToken
	}
	// 过期检查 (核心优化: 优先在应用进程内存中纳秒级短路返回, 零 Redis 开销彻底杜绝过期 Token 对 Redis 的 DoS 冲击)
	// 同时将 payload 返回, 供 Refresh 读取 claims 续签, 且令 /refresh 流程节约一次多余的 Redis 脚本调用 (RFC 7519 精准时间边界)
	if payload.ExpiresAt != nil && !payload.ExpiresAt.After(cTime) {
		return payload, ErrExpiredToken
	}

	// 2. Redis Lua 脚本原子批量检查 (仅针对当前尚未过期的有效 Token 执行, 带 {u:userId} Hash Tag 保证单槽同驻)
	// 采用预编译 checkTokenScript (EVALSHA), 极大降低高并发下的网络带宽与解析 CPU 开销
	tokenKey := j.tokenKey(payload.Subject, tokenStr)
	banKey := j.banKey(payload.Subject)
	minAuthKey := j.minAuthKey(payload.Subject)
	// 当 payload.SID 为空时使用同槽占位 key，保证传入 Lua 的所有 4 个 KEYS 100% 带有 {u:userId} Hash Tag，彻底杜绝 Redis Cluster 下的 CROSSSLOT 风险
	sidKey := j.sidKey(payload.Subject, "_")
	if payload.SID != "" {
		sidKey = j.sidKey(payload.Subject, payload.SID)
	}

	authTime := payload.AuthTime
	if authTime <= 0 && payload.IssuedAt != nil {
		authTime = payload.IssuedAt.Unix()
	}

	status, evalErr := checkTokenScript.Run(ctx, j.Cache, []string{tokenKey, sidKey, banKey, minAuthKey}, authTime).Int()
	if evalErr != nil {
		return nil, fmt.Errorf("校验token状态失败: %w", evalErr)
	}

	switch status {
	case 1:
		return nil, ErrRevokedToken
	case 2:
		return nil, ErrUserBanned
	case 3:
		return nil, ErrAuthorizeElsewhere
	}

	return payload, nil
}

// ParseWithoutBlacklist 校验 HMAC 签名与 Claims 结构，但不校验黑名单与过期状态（支持可选指定 TokenTypeRefresh，默认解析 AccessToken）
// 用于安全登出、并发重放检测等场景，确保仅处理本服务合法签发的真实 Token。
// 密码学安全保证：只有经过本服务对应密钥合法签名的 Token 才能解析成功，任何伪造/篡改的 Token 会在密码学验签层被 100% 拒绝，彻底防范伪造攻击。
func (j *Jwt) ParseWithoutBlacklist(tokenStr string, optType ...string) (*Claims, error) {
	tokenStr = CleanToken(tokenStr)
	if tokenStr == "" {
		return nil, ErrEmptyToken
	}
	j.mu.RLock()
	secret := j.secretBytes
	if len(optType) > 0 && optType[0] == TokenTypeRefresh {
		secret = j.refreshSecretBytes
	}
	j.mu.RUnlock()

	payload := &Claims{}
	_, err := j.parser.ParseWithClaims(tokenStr, payload, func(token *v5.Token) (any, error) {
		return secret, nil
	})
	if err != nil && !errors.Is(err, v5.ErrTokenExpired) {
		return nil, err
	}
	return payload, nil
}

// Disuse 废弃 Token (自动提取 Token 中的 userId 并打上 Hash Tag 保证集群分片一致性)
func (j *Jwt) Disuse(ctx context.Context, value string, expiration int64) error {
	return j.DisuseUserToken(ctx, "", value, expiration)
}

// DisuseUserToken 废弃指定用户的 Token (优先使用已解析的 userId，避免重复解析 Token)
func (j *Jwt) DisuseUserToken(ctx context.Context, userId string, value string, expiration int64) error {
	value = CleanToken(value)
	if value == "" || expiration <= 0 {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	cacheKey := j.tokenKey(userId, value)
	_, err := j.Cache.SetNX(ctx, cacheKey, 1, time.Duration(expiration)*time.Second).Result()
	return err
}

// DisuseSession 废弃会话 SID, 使该会话下成对的 AccessToken 和 RefreshToken 同时失效(默认原因: 主动登出)
func (j *Jwt) DisuseSession(ctx context.Context, sid string, expiration int64) error {
	return j.DisuseSessionWithReason(ctx, sid, expiration, DisuseReasonLogout)
}

// DisuseSessionWithReason 废弃会话 SID 并记录废弃原因(logout:主动登出, kicked:被顶下线等)
// 内部自动从 sid 提取 userId，确保 Redis 集群下 100% 携带 Hash Tag 并原子清理单端活跃会话
func (j *Jwt) DisuseSessionWithReason(ctx context.Context, sid string, expiration int64, reason string) error {
	if sid == "" || expiration <= 0 {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if reason == "" {
		reason = DisuseReasonLogout
	}
	userId := extractUserIdFromSid(sid)
	cacheKey := j.sidKey(userId, sid)
	_, err := j.Cache.Set(ctx, cacheKey, reason, time.Duration(expiration)*time.Second).Result()

	j.mu.RLock()
	multiLogin := j.MultiLogin
	j.mu.RUnlock()

	// 若为主动登出(logout)且处于单端模式，同步原子清理单端活跃会话记录，杜绝 Redis 残留死会话
	if reason == DisuseReasonLogout && userId != "" && !multiLogin && j.Cache != nil {
		_ = clearSessionScript.Run(ctx, j.Cache, []string{j.currentSidKey(userId)}, sid).Err()
	}
	return err
}

// ClearUserSession 清理用户当前记录的活跃会话(仅在当前记录的活跃 sid 与传入 sid 一致时删除, 原子执行)
func (j *Jwt) ClearUserSession(ctx context.Context, userId int64, sid string) error {
	if userId <= 0 || sid == "" || j.Cache == nil {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	userKey := j.currentSidKey(strconv.FormatInt(userId, 10))
	return clearSessionScript.Run(ctx, j.Cache, []string{userKey}, sid).Err()
}

// BanUser 管理员封禁用户 (支持指定封禁时长，duration <= 0 表示永久封禁100年，并记录原因)
func (j *Jwt) BanUser(ctx context.Context, userId int64, duration time.Duration, reason string) error {
	if userId <= 0 || j.Cache == nil {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if duration <= 0 {
		duration = 100 * 365 * 24 * time.Hour // 默认永久封禁
	}
	if reason == "" {
		reason = "banned by administrator"
	}
	uidStr := strconv.FormatInt(userId, 10)
	banKey := j.banKey(uidStr)
	if err := j.Cache.Set(ctx, banKey, reason, duration).Err(); err != nil {
		return err
	}
	// 关键安全闭环：封禁时同步全端强制踢下线，确保被封禁前流通的所有旧 Token 彻底作废
	// 杜绝日后解封(Unban)时历史盗用/泄露 Token 起死回生潜伏攻击，解封后必须凭密码重新认证
	_ = j.KickAllDevices(ctx, userId)
	return nil
}

// UnbanUser 管理员解封用户
func (j *Jwt) UnbanUser(ctx context.Context, userId int64) error {
	if userId <= 0 || j.Cache == nil {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	banKey := j.banKey(strconv.FormatInt(userId, 10))
	_, err := j.Cache.Del(ctx, banKey).Result()
	return err
}

// IsUserBanned 检查用户是否处于封禁状态
func (j *Jwt) IsUserBanned(ctx context.Context, userId int64) (bool, string, error) {
	if userId <= 0 || j.Cache == nil {
		return false, "", nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	banKey := j.banKey(strconv.FormatInt(userId, 10))
	reason, err := j.Cache.Get(ctx, banKey).Result()
	if err != nil {
		if errors.Is(err, xredis.Nil) {
			return false, "", nil
		}
		return false, "", err
	}
	return true, reason, nil
}

// KickAllDevices 管理员强制用户所有设备下线 (基于 min_auth_time 时间戳阈值，已发 Token 立即失效，重登立即可用)
func (j *Jwt) KickAllDevices(ctx context.Context, userId int64) error {
	if userId <= 0 || j.Cache == nil {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	now := time.Now().Unix()
	uidStr := strconv.FormatInt(userId, 10)
	minAuthKey := j.minAuthKey(uidStr)

	j.mu.RLock()
	ttl := j.RefreshTime
	if j.MaxRefreshTime > 0 && j.MaxRefreshTime > ttl {
		ttl = j.MaxRefreshTime
	}
	j.mu.RUnlock()

	// 设置时间戳阈值为当前时间
	if err := j.Cache.Set(ctx, minAuthKey, strconv.FormatInt(now, 10), ttl).Err(); err != nil {
		return err
	}
	// 顺带清理单端活跃会话记录
	userSidKey := j.currentSidKey(uidStr)
	_, _ = j.Cache.Del(ctx, userSidKey).Result()
	return nil
}

// disuseTokenIfAbsent 仅在尚未废弃时废弃指定用户的 Token (用于 Refresh 轮换时的内部原子抢占)
func (j *Jwt) disuseTokenIfAbsent(ctx context.Context, userId string, value string, expiration int64) (bool, error) {
	value = CleanToken(value)
	if value == "" || expiration <= 0 {
		return false, nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	cacheKey := j.tokenKey(userId, value)
	result, err := j.Cache.SetNX(ctx, cacheKey, 1, time.Duration(expiration)*time.Second).Result()
	return result, err
}

// rollbackTokenDisuse 回滚指定用户 Token 的废弃状态 (仅用于 Refresh 新 Token 签发失败时的补偿恢复)
func (j *Jwt) rollbackTokenDisuse(ctx context.Context, userId string, value string) error {
	value = CleanToken(value)
	if value == "" {
		return nil
	}
	if ctx == nil {
		ctx = context.Background()
	}
	cacheKey := j.tokenKey(userId, value)
	_, err := j.Cache.Del(ctx, cacheKey).Result()
	return err
}

// ================= JWT 错误类型定义 =================

type Error struct {
	Inner  error
	Errors uint32
	text   string
}

func newError(errorText string, errorFlags uint32) *Error {
	return &Error{
		text:   errorText,
		Errors: errorFlags,
	}
}

// Error 实现 error 接口
func (o *Error) Error() string {
	if o.Inner != nil {
		return o.Inner.Error()
	}
	return o.text
}

// Unwrap 实现 errors.Unwrap 接口,支持 errors.Is()/errors.As() 链式遍历
func (o *Error) Unwrap() error {
	return o.Inner
}
