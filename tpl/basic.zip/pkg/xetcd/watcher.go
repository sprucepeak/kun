package xetcd

import (
	"context"
	"fmt"
	"sync"
	"time"

	"go.etcd.io/etcd/api/v3/mvccpb"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.uber.org/zap"
)

// Watcher 通过 etcd Watch 实时同步配置变更。
// 一次 Watch 监听整个环境前缀，业务侧按 (group, dataId) 取值。
// 打印日志与 xlog 统一直接使用全局 zap.L()。
// goroutine-safe。
type Watcher struct {
	cli      *clientv3.Client
	mu       sync.RWMutex
	data     map[string]*ConfigValue // key: "{group}/{dataId}"
	onChange func()
}

// SetOnChange 注册配置变更时的回调函数（热重载触发）。
func (w *Watcher) SetOnChange(fn func()) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.onChange = fn
}

// NewWatcher 创建配置 watcher。
func NewWatcher(endpoints []string, etcdUsername, etcdPassword string) (*Watcher, error) {
	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: 5 * time.Second,
		Username:    etcdUsername,
		Password:    etcdPassword,
		Logger:      zap.L().Named("etcd"),
	})
	if err != nil {
		return nil, fmt.Errorf("connect etcd failed: %w", err)
	}
	return &Watcher{
		cli:  cli,
		data: make(map[string]*ConfigValue),
	}, nil
}

// Watch 开始监听整个环境的配置：一次性 Watch 前缀 /{project}/config/content/{env}/
// 首次调用立即拉取前缀下全部配置；之后 etcd 变更自动更新到内存缓存。
func (w *Watcher) Watch(ctx context.Context, project, env string) error {
	prefix := fmt.Sprintf("/%s/config/content/%s/", project, env)

	resp, err := w.cli.Get(ctx, prefix, clientv3.WithPrefix())
	if err != nil {
		return fmt.Errorf("etcd get failed: %w", err)
	}
	w.mu.Lock()
	for _, kv := range resp.Kvs {
		w.upsert(string(kv.Key), kv.Value)
	}
	w.mu.Unlock()
	zap.L().Info(fmt.Sprintf("[xetcd] loaded %d config(s) under %s", len(resp.Kvs), prefix),
		zap.String("prefix", prefix),
		zap.Int("count", len(resp.Kvs)),
	)

	go func() {
		ch := w.cli.Watch(ctx, prefix, clientv3.WithPrefix())
		for wresp := range ch {
			var hasChange bool
			w.mu.Lock()
			for _, ev := range wresp.Events {
				switch ev.Type {
				case mvccpb.PUT:
					w.upsert(string(ev.Kv.Key), ev.Kv.Value)
					hasChange = true
				case mvccpb.DELETE:
					w.remove(string(ev.Kv.Key))
					hasChange = true
				}
			}
			onChangeFn := w.onChange
			w.mu.Unlock()

			if hasChange && onChangeFn != nil {
				onChangeFn()
			}
		}
		zap.L().Warn(fmt.Sprintf("[xetcd] watch channel closed for %s", prefix),
			zap.String("prefix", prefix),
		)
	}()
	return nil
}

func (w *Watcher) upsert(key string, val []byte) {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return
	}
	v, err := DecodeConfigValue(string(val))
	if err != nil {
		zap.L().Error(fmt.Sprintf("[xetcd] decode %s failed: %v", key, err),
			zap.String("key", key),
			zap.Error(err),
		)
		return
	}
	w.data[group+"/"+dataId] = v
	zap.L().Info(fmt.Sprintf("[xetcd] loaded %s/%s (version=%d, format=%s)", group, dataId, v.Version, v.Format),
		zap.String("group", group),
		zap.String("dataId", dataId),
		zap.Int64("version", v.Version),
		zap.String("format", v.Format),
	)
}

func (w *Watcher) remove(key string) {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return
	}
	delete(w.data, group+"/"+dataId)
	zap.L().Info(fmt.Sprintf("[xetcd] removed %s/%s", group, dataId),
		zap.String("group", group),
		zap.String("dataId", dataId),
	)
}

// Get 读取已缓存的配置值。goroutine-safe。
func (w *Watcher) Get(group, dataId string) *ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	return w.data[group+"/"+dataId]
}

// GetContent 返回配置内容字符串（快捷方法）。
func (w *Watcher) GetContent(group, dataId string) string {
	if v := w.Get(group, dataId); v != nil {
		return v.Content
	}
	return ""
}

// All 返回当前缓存的所有配置项（快照副本）。goroutine-safe。
func (w *Watcher) All() map[string]*ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	out := make(map[string]*ConfigValue, len(w.data))
	for k, v := range w.data {
		out[k] = v
	}
	return out
}

// Close 关闭 etcd 连接。
func (w *Watcher) Close() error {
	return w.cli.Close()
}

// Scan 将已缓存的配置内容按 format（yaml/json/properties）反序列化到 out。
func (w *Watcher) Scan(group, dataId string, out any) error {
	v := w.Get(group, dataId)
	if v == nil {
		return fmt.Errorf("config %s/%s not found, did you call Watch?", group, dataId)
	}
	if out == nil {
		return fmt.Errorf("out must not be nil")
	}
	return UnmarshalConfigContent(v.Format, v.Content, out)
}
