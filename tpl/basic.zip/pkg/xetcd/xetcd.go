package xetcd

import (
	"context"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	"go.etcd.io/etcd/api/v3/mvccpb"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.uber.org/zap"
)

// ============================================================================
// 1. Client & ClientPool (多集群客户端连接池与健康检查 - 服务端管理视角)
// ============================================================================

type Client struct {
	*clientv3.Client

	endpoints       string    // 归一化后的地址键，供池在失效时定位并剔除
	username        string    // 认证用户名
	lastHealthCheck time.Time // 上次健康检查时间（受 ClientPool.mu 保护）
	mu              sync.Mutex
}

// defaultDialTimeout 默认 etcd 拨号超时。
const defaultDialTimeout = 5 * time.Second

// defaultHealthCheckInterval 默认健康检查间隔；超过此时长未检查则自动执行 Status ping。
const defaultHealthCheckInterval = 30 * time.Second

// newRawClient 构造一个 etcd client 并 Ping 校验首端点可达。
// 供 ClientPool.Get 复用。username 为空则不启用认证。
// Status ping 失败时仍返回 client（仅告警），因为实际读写操作会携带凭据；
// 这样可避免 etcd 开启认证但环境单元格未配置用户名时，健康检查阻塞所有操作。
func newRawClient(endpoints []string, timeout time.Duration, logger *zap.Logger, username, password string) (*clientv3.Client, error) {
	if len(endpoints) == 0 {
		return nil, fmt.Errorf("etcd endpoints empty")
	}
	if timeout == 0 {
		timeout = defaultDialTimeout
	}
	cfg := clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: timeout,
	}
	if username != "" {
		cfg.Username = username
		cfg.Password = password
	}
	cli, err := clientv3.New(cfg)
	if err != nil {
		return nil, err
	}
	// Ping etcd using status — 非致命检查，失败仅告警
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	_, err = cli.Status(ctx, endpoints[0])
	if err != nil {
		if logger != nil {
			logger.Sugar().Warnf("etcd endpoint %s status check failed: %v", endpoints[0], err)
		} else {
			zap.L().Sugar().Warnf("etcd endpoint %s status check failed: %v (client returned anyway)", endpoints[0], err)
		}
	}
	return cli, nil
}

// ClientPool 按 etcd 地址集合+用户名缓存复用 *Client。
// 相同 endpoints（无论顺序/空白）+ 相同 username 共享同一 client，避免反复建连。
// Get 返回前会对缓存连接做定期健康检查（Status ping），失效自动重建。
type ClientPool struct {
	logger              *zap.Logger
	timeout             time.Duration
	healthCheckInterval time.Duration

	mu      sync.RWMutex
	clients map[string]*Client
}

// NewClientPool 构造地址+用户 → client 缓存池。
func NewClientPool(logger *zap.Logger) *ClientPool {
	return &ClientPool{
		logger:              logger,
		timeout:             defaultDialTimeout,
		healthCheckInterval: defaultHealthCheckInterval,
		clients:             make(map[string]*Client),
	}
}

// SetHealthCheckInterval 设置健康检查间隔。传入 0 禁用健康检查。
func (p *ClientPool) SetHealthCheckInterval(d time.Duration) {
	if d < 0 {
		d = defaultHealthCheckInterval
	}
	p.healthCheckInterval = d
}

// Get 按 endpoints + username 取复用 client。
// 缓存键格式为 "username@host1,host2"（username 为空时退化为 "host1,host2"）。
// 命中缓存且距上次健康检查超过间隔时执行 Status ping，校验失败则自动重建连接。
func (p *ClientPool) Get(endpoints []string, username, password string) (*Client, error) {
	key := normalizeEndpoints(endpoints, username)
	if key == "" {
		return nil, fmt.Errorf("etcd endpoints empty")
	}

	p.mu.RLock()
	c, ok := p.clients[key]
	if ok {
		p.mu.RUnlock()
		// 健康检查：超过间隔则执行 Status ping
		if p.healthCheckInterval > 0 && func() bool {
			c.mu.Lock()
			defer c.mu.Unlock()
			return time.Since(c.lastHealthCheck) > p.healthCheckInterval
		}() {
			ctx, cancel := context.WithTimeout(context.Background(), p.timeout)
			_, err := c.Status(ctx, splitEndpoints(key)[0])
			cancel()
			if err != nil {
				// 连接失效：剔除旧连接，重建
				p.Invalidate(splitEndpoints(key), username)
				if p.logger != nil {
					p.logger.Sugar().Warnf("etcd health check failed for %s, reconnecting: %v", key, err)
				} else {
					zap.L().Sugar().Warnf("etcd health check failed for %s, reconnecting: %v", key, err)
				}
			} else {
				c.mu.Lock()
				c.lastHealthCheck = time.Now()
				c.mu.Unlock()
				return c, nil
			}
		} else {
			return c, nil
		}
	} else {
		p.mu.RUnlock()
	}

	raw, err := newRawClient(splitEndpoints(key), p.timeout, p.logger, username, password)
	if err != nil {
		if p.logger != nil {
			p.logger.Sugar().Warnf("etcd client connect failed for %s: %v", key, err)
		} else {
			zap.L().Sugar().Warnf("etcd client connect failed for %s: %v", key, err)
		}
		return nil, err
	}
	c = &Client{Client: raw, endpoints: key, username: username, lastHealthCheck: time.Now()}

	p.mu.Lock()
	if existing, ok := p.clients[key]; ok {
		p.mu.Unlock()
		_ = raw.Close()
		return existing, nil
	}
	p.clients[key] = c
	p.mu.Unlock()
	if p.logger != nil {
		p.logger.Sugar().Infof("etcd client established for %s", key)
	} else {
		zap.L().Sugar().Infof("etcd client established for %s", key)
	}
	return c, nil
}

// Invalidate 剔除指定地址集合+用户的缓存 client 并关闭底层连接。
func (p *ClientPool) Invalidate(endpoints []string, username string) {
	key := normalizeEndpoints(endpoints, username)
	if key == "" {
		return
	}
	p.mu.Lock()
	c, ok := p.clients[key]
	if ok {
		delete(p.clients, key)
	}
	p.mu.Unlock()
	if ok {
		_ = c.Client.Close()
		if p.logger != nil {
			p.logger.Sugar().Infof("etcd client invalidated for %s", key)
		} else {
			zap.L().Sugar().Infof("etcd client invalidated for %s", key)
		}
	}
}

// Close 关闭池中所有 client。供进程退出时调用。
func (p *ClientPool) Close() {
	p.mu.Lock()
	defer p.mu.Unlock()
	for key, c := range p.clients {
		_ = c.Client.Close()
		delete(p.clients, key)
	}
}

// normalizeEndpoints 将地址切片+用户名归一为稳定的缓存键：去空、去前后空白、排序、逗号拼接。
// username 为空时缓存键仅为地址部分；不为空时前缀 "username@" 使不同用户即使连同一集群也独立复用。
func normalizeEndpoints(endpoints []string, username string) string {
	cleaned := make([]string, 0, len(endpoints))
	for _, e := range endpoints {
		e = strings.TrimSpace(e)
		if e != "" {
			cleaned = append(cleaned, e)
		}
	}
	sort.Strings(cleaned)
	addr := strings.Join(cleaned, ",")
	if username != "" {
		return username + "@" + addr
	}
	return addr
}

// splitEndpoints 将归一键拆回地址切片。如果键含 "@" 前缀（username@hosts），则去掉用户名部分。
func splitEndpoints(key string) []string {
	if key == "" {
		return nil
	}
	// 去除 username@ 前缀
	if idx := strings.Index(key, "@"); idx >= 0 {
		key = key[idx+1:]
	}
	return strings.Split(key, ",")
}

// ============================================================================
// 2. Watcher (配置动态监听与只读缓存 - 客户端订阅视角)
// ============================================================================

// Watcher 通过 etcd Watch 实时同步配置变更。
// 一次 Watch 监听整个环境前缀，业务侧按 (group, dataId) 取值。
// 打印日志统一使用全局 zap.L()。
// goroutine-safe。
type Watcher struct {
	cli      *clientv3.Client
	mu       sync.RWMutex
	data     map[string]*ConfigValue // key: "{group}/{dataId}"
	onChange func()
}

// SetOnChange 注册配置变更时的回调函数（热重载触发）。
func (w *Watcher) SetOnChange(fn func()) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.onChange = fn
}

// NewWatcher 创建配置 watcher。
func NewWatcher(endpoints []string, etcdUsername, etcdPassword string) (*Watcher, error) {
	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: 5 * time.Second,
		Username:    etcdUsername,
		Password:    etcdPassword,
		Logger:      zap.L().Named("etcd"),
	})
	if err != nil {
		return nil, fmt.Errorf("connect etcd failed: %w", err)
	}
	return &Watcher{
		cli:  cli,
		data: make(map[string]*ConfigValue),
	}, nil
}

// Watch 开始监听整个环境的配置：一次性 Watch 前缀 /{project}/config/content/{env}/
// 首次调用立即拉取前缀下全部配置；之后 etcd 变更自动更新到内存缓存。
func (w *Watcher) Watch(ctx context.Context, project, env string) error {
	prefix := fmt.Sprintf("/%s/config/content/%s/", project, env)

	resp, err := w.cli.Get(ctx, prefix, clientv3.WithPrefix())
	if err != nil {
		return fmt.Errorf("etcd get failed: %w", err)
	}
	w.mu.Lock()
	for _, kv := range resp.Kvs {
		w.upsert(string(kv.Key), kv.Value)
	}
	w.mu.Unlock()
	zap.L().Info(fmt.Sprintf("[xetcd] loaded %d config(s) under %s", len(resp.Kvs), prefix),
		zap.String("prefix", prefix),
		zap.Int("count", len(resp.Kvs)),
	)

	go func() {
		ch := w.cli.Watch(ctx, prefix, clientv3.WithPrefix())
		for wresp := range ch {
			var hasChange bool
			w.mu.Lock()
			for _, ev := range wresp.Events {
				switch ev.Type {
				case mvccpb.PUT:
					w.upsert(string(ev.Kv.Key), ev.Kv.Value)
					hasChange = true
				case mvccpb.DELETE:
					w.remove(string(ev.Kv.Key))
					hasChange = true
				}
			}
			onChangeFn := w.onChange
			w.mu.Unlock()

			if hasChange && onChangeFn != nil {
				onChangeFn()
			}
		}
		zap.L().Warn(fmt.Sprintf("[xetcd] watch channel closed for %s", prefix),
			zap.String("prefix", prefix),
		)
	}()
	return nil
}

func (w *Watcher) upsert(key string, val []byte) {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return
	}
	v, err := DecodeConfigValue(string(val))
	if err != nil {
		zap.L().Error(fmt.Sprintf("[xetcd] decode %s failed: %v", key, err),
			zap.String("key", key),
			zap.Error(err),
		)
		return
	}
	w.data[group+"/"+dataId] = v
	zap.L().Info(fmt.Sprintf("[xetcd] loaded %s/%s (version=%d, format=%s)", group, dataId, v.Version, v.Format),
		zap.String("group", group),
		zap.String("dataId", dataId),
		zap.Int32("version", v.Version),
		zap.String("format", v.Format),
	)
}

func (w *Watcher) remove(key string) {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return
	}
	delete(w.data, group+"/"+dataId)
	zap.L().Info(fmt.Sprintf("[xetcd] removed %s/%s", group, dataId),
		zap.String("group", group),
		zap.String("dataId", dataId),
	)
}

// Get 读取已缓存的配置值。goroutine-safe。
func (w *Watcher) Get(group, dataId string) *ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	return w.data[group+"/"+dataId]
}

// GetContent 返回配置内容字符串（快捷方法）。
func (w *Watcher) GetContent(group, dataId string) string {
	if v := w.Get(group, dataId); v != nil {
		return v.Content
	}
	return ""
}

// All 返回当前缓存的所有配置项（快照副本）。goroutine-safe。
func (w *Watcher) All() map[string]*ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	out := make(map[string]*ConfigValue, len(w.data))
	for k, v := range w.data {
		out[k] = v
	}
	return out
}

// Close 关闭 etcd 连接。
func (w *Watcher) Close() error {
	return w.cli.Close()
}

// Scan 将已缓存的配置内容按 format（yaml/json/properties）反序列化到 out。
func (w *Watcher) Scan(group, dataId string, out any) error {
	v := w.Get(group, dataId)
	if v == nil {
		return fmt.Errorf("config %s/%s not found, did you call Watch?", group, dataId)
	}
	if out == nil {
		return fmt.Errorf("out must not be nil")
	}
	return UnmarshalConfigContent(v.Format, v.Content, out)
}
