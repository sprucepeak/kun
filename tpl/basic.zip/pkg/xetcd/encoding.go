package xetcd

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

// InstanceInfo 表示 etcd 中存储的服务实例信息。
// etcd key: /{project}/{env}/{serviceName}/{ip}:{port}
// etcd value: {weight}|{enabled}|{version}
type InstanceInfo struct {
	ServiceName string            `json:"serviceName"`
	Env         string            `json:"env"`
	Ip          string            `json:"ip"`
	Port        int32             `json:"port"`
	Weight      float64           `json:"weight"`
	Enabled     bool              `json:"enabled"`
	Metadata    map[string]string `json:"metadata"`
}

// ConfigValue 表示 etcd 中存储的配置内容（单 key 存储格式）。
// etcd key: /{project}/config/content/{env}/{group}/{dataId}
// etcd value: JSON 序列化的 ConfigValue
type ConfigValue struct {
	Content   string `json:"content"`
	Md5       string `json:"md5"`
	Format    string `json:"format"` // yaml | json | properties
	Version   int32  `json:"version"`
	UpdatedAt int64  `json:"updatedAt"` // Unix timestamp in seconds
}

// EncodeConfigValue 将 ConfigValue 序列化为 JSON 存入 etcd。
func EncodeConfigValue(v *ConfigValue) string {
	b, err := json.Marshal(v)
	if err != nil {
		return ""
	}
	return string(b)
}

// DecodeConfigValue 从 JSON 解析 ConfigValue。
func DecodeConfigValue(value string) (*ConfigValue, error) {
	var v ConfigValue
	if err := json.Unmarshal([]byte(value), &v); err != nil {
		return nil, fmt.Errorf("invalid config value: %w", err)
	}
	return &v, nil
}

// NewConfigValue 创建配置值，自动填充 UpdatedAt。
func NewConfigValue(content, md5, format string, version int32) *ConfigValue {
	return &ConfigValue{
		Content:   content,
		Md5:       md5,
		Format:    format,
		Version:   version,
		UpdatedAt: time.Now().Unix(),
	}
}

// EncodeInstance 将 InstanceInfo 序列化为格式存入 etcd。
// ip:port 已在 key 中，value 只存 weight|enabled|version。
func EncodeInstance(inst *InstanceInfo) string {
	var version string
	if inst.Metadata != nil {
		version = inst.Metadata["version"]
	}
	var buf []byte
	buf = strconv.AppendFloat(buf, inst.Weight, 'f', 0, 64)
	buf = append(buf, '|')
	if inst.Enabled {
		buf = append(buf, '1')
	} else {
		buf = append(buf, '0')
	}
	buf = append(buf, '|')
	buf = append(buf, version...)
	return string(buf)
}

// DecodeInstance 从 etcd key+value 解析 InstanceInfo。
// key 格式: /{project}/{env}/{serviceName}/{ip}:{port}
// value 格式: weight|enabled|version
func DecodeInstance(key, value string) (*InstanceInfo, error) {
	segs := strings.Split(strings.TrimPrefix(key, "/"), "/")
	if len(segs) < 4 {
		return nil, fmt.Errorf("invalid key format: %s", key)
	}
	ip, port := parseAddrSegment(segs[len(segs)-1])

	inst, err := decodeCompact(value)
	if err != nil {
		return nil, err
	}
	inst.ServiceName = segs[2]
	inst.Env = segs[1]
	inst.Ip = ip
	inst.Port = port
	return inst, nil
}

// decodeCompact 解析格式 value: weight|enabled|version
func decodeCompact(value string) (*InstanceInfo, error) {
	parts := strings.Split(value, "|")
	if len(parts) < 2 {
		return nil, fmt.Errorf("compact value needs at least weight|enabled")
	}
	weight, err := strconv.ParseFloat(parts[0], 64)
	if err != nil {
		return nil, fmt.Errorf("invalid weight: %w", err)
	}
	enabled := parts[1] == "1"
	version := ""
	if len(parts) >= 3 {
		version = parts[2]
	}
	inst := &InstanceInfo{
		Weight:   weight,
		Enabled:  enabled,
		Metadata: map[string]string{},
	}
	if version != "" {
		inst.Metadata["version"] = version
	}
	return inst, nil
}

func parseAddrSegment(seg string) (string, int32) {
	idx := strings.LastIndex(seg, ":")
	if idx < 0 {
		return seg, 0
	}
	ip := seg[:idx]
	port, _ := strconv.ParseInt(seg[idx+1:], 10, 32)
	return ip, int32(port)
}

// ParseConfigKey 从 etcd key /{project}/config/content/{env}/{group}/{dataId}
// 解析出 group 与 dataId。末尾不足两段或路径层级不对时返回 ok=false。
func ParseConfigKey(key string) (group, dataId string, ok bool) {
	parts := strings.Split(strings.TrimPrefix(key, "/"), "/")
	if len(parts) < 6 {
		return "", "", false
	}
	group, dataId = parts[len(parts)-2], parts[len(parts)-1]
	return group, dataId, true
}

// ScanProperties 解析 key=value 格式的 properties 内容到 map[string]string。
func ScanProperties(content string, out interface{}) error {
	m, ok := out.(*map[string]string)
	if !ok {
		return fmt.Errorf("properties format only supports *map[string]string target")
	}
	result := make(map[string]string)
	for _, line := range strings.Split(content, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") {
			continue
		}
		idx := strings.IndexAny(line, "=:")
		if idx < 0 {
			continue
		}
		key := strings.TrimSpace(line[:idx])
		val := strings.TrimSpace(line[idx+1:])
		result[key] = val
	}
	*m = result
	return nil
}

// UnmarshalConfigContent 将配置内容按 format（yaml/json/properties）反序列化到 out。
func UnmarshalConfigContent(format, content string, out interface{}) error {
	switch strings.ToLower(format) {
	case "yaml", "yml":
		return yaml.Unmarshal([]byte(content), out)
	case "json":
		return json.Unmarshal([]byte(content), out)
	case "properties":
		return ScanProperties(content, out)
	default:
		if err := json.Unmarshal([]byte(content), out); err != nil {
			return yaml.Unmarshal([]byte(content), out)
		}
		return nil
	}
}
