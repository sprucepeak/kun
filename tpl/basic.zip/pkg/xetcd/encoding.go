package xetcd

import (
	"encoding/json"
	"fmt"
	"strings"

	"gopkg.in/yaml.v3"
)

// ConfigValue 表示 etcd 中存储的配置内容（单 key 存储格式）。
// etcd key: /{project}/config/content/{env}/{group}/{dataId}
type ConfigValue struct {
	Content   string `json:"content"`
	Md5       string `json:"md5"`
	Format    string `json:"format"` // yaml | json | properties
	Version   int64  `json:"version"`
	UpdatedAt int64  `json:"updatedAt"` // Unix timestamp in seconds
}

// DecodeConfigValue 从 JSON 解析 ConfigValue。
func DecodeConfigValue(value string) (*ConfigValue, error) {
	var v ConfigValue
	if err := json.Unmarshal([]byte(value), &v); err != nil {
		return nil, fmt.Errorf("invalid config value: %w", err)
	}
	return &v, nil
}

// ParseConfigKey 从 etcd key /{project}/config/content/{env}/{group}/{dataId} 解析出 group 与 dataId。
func ParseConfigKey(key string) (group, dataId string, ok bool) {
	parts := strings.Split(strings.TrimPrefix(key, "/"), "/")
	if len(parts) < 6 {
		return "", "", false
	}
	return parts[len(parts)-2], parts[len(parts)-1], true
}

// ScanProperties 解析 key=value 格式的 properties 内容到 map[string]string。
func ScanProperties(content string, out interface{}) error {
	m, ok := out.(*map[string]string)
	if !ok {
		return fmt.Errorf("properties format only supports *map[string]string target")
	}
	result := make(map[string]string)
	for _, line := range strings.Split(content, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") {
			continue
		}
		idx := strings.IndexAny(line, "=:")
		if idx < 0 {
			continue
		}
		result[strings.TrimSpace(line[:idx])] = strings.TrimSpace(line[idx+1:])
	}
	*m = result
	return nil
}

// UnmarshalConfigContent 将配置内容按 format（yaml/json/properties）反序列化到 out。
func UnmarshalConfigContent(format, content string, out interface{}) error {
	switch strings.ToLower(format) {
	case "yaml", "yml":
		return yaml.Unmarshal([]byte(content), out)
	case "json":
		return json.Unmarshal([]byte(content), out)
	case "properties":
		return ScanProperties(content, out)
	default:
		if err := json.Unmarshal([]byte(content), out); err != nil {
			return yaml.Unmarshal([]byte(content), out)
		}
		return nil
	}
}
