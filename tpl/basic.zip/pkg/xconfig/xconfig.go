package xconfig

import (
	"context"
	"fmt"
	"os"
	"strings"
	"sync"
	"sync/atomic"

	"basic/pkg/xetcd"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

const (
	EnvDebug   = "debug"
	EnvTest    = "test"
	EnvStaging = "staging"
	EnvRelease = "release"
)

type (
	// Conf 是配置容器。
	//
	// 模式互斥原则:
	//  - remoteConfig: true 时,完全由远程 etcd 接管,本地配置仅作引导(Bootstrap),绝不合并覆盖,
	//    etcd 变更触发 log/token 等热更新,不受本地 yaml 影响;
	//  - remoteConfig: false 时,纯本地配置模式,随本地 yaml 变动热更新,不连接 etcd。
	//
	// 读取方式分两类:
	//  1. 启动期一次性读取(如 xdb.New 读 Database.Source 建连接):直接访问字段 conf.Database.Source。
	//     New 返回时字段即首份配置,且启动期之后字段不再变化,无竞态。
	//  2. 运行期重复读取(如每条消息读 Env):用 conf.Get().Xxx,返回原子快照,
	//     零竞态,能拿到热重载后的最新值。不要长期缓存 Get() 返回值。
	//
	// DB/Redis 连接等启动期固化的资源不会重建,热重载对运行期通过 Get() 或 OnUpdate 监听的逻辑生效。
	Conf struct {
		Project      string
		Env          string
		Version      string
		RemoteConfig bool

		Server   ServerConf
		Token    TokenConf
		Log      LogConf
		Database DatabaseConf
		Redis    RedisConf
		Jaeger   JaegerConf

		EtcdConfig EtcdConf
		Watcher    *xetcd.Watcher `mapstructure:"-"`

		// current 原子持有"当前配置快照"指针,供运行期 Get() 读取,零竞态。
		current atomic.Pointer[Conf]

		// onUpdateHooks 保存所有已注册的配置热更新回调
		onUpdateHooks []func(newConf *Conf)
		hookMu        sync.Mutex
	}

	EtcdConf struct {
		Host     []string // etcd 节点列表，为空时自动降级走纯本地配置
		Username string   // 可选认证账号
		Password string   // 可选认证密码
	}

	ServerConf struct {
		Port         int64
		ReadTimeout  int64
		WriteTimeout int64
		AllowOrigins []string // CORS 允许的来源白名单,为空则允许所有
	}

	TokenConf struct {
		Secret        string
		RefreshSecret string
		CSRFKey       string
		Expire        int64
		Refresh       int64
		MaxRefresh    int64 // 绝对最大有效期(秒), 默认30天(2592000)
		GracePeriod   int64 // 轮换宽限期(秒), 默认30秒

		QueryKey   string
		MultiLogin bool
	}

	LogConf struct {
		Level        string
		FilePath     string
		Stdout       bool
		KafkaTopic   string
		KafkaBrokers []string
	}

	DatabaseConf struct {
		Driver          string   // 数据库驱动类型: mysql | postgres | pgsql | sqlite | clickhouse
		LogLevel        string   // 日志级别: debug, info, warn, error
		Source          []string // 主库 DSN 地址(取第 1 条为主库/写库)
		Replicas        []string // 从库只读副本 DSN 列表 (mysql, pgsql, clickhouse 主从读写分离; sqlite 忽略)
		MaxIdleConns    int      // 空闲连接池中连接的最大数量
		MaxOpenConns    int      // 打开数据库连接的最大数量
		ConnMaxLifetime int      // 连接可复用的最大时间(秒)
	}

	RedisConf struct {
		Source       []string
		Password     string
		DB           int // Redis 数据库索引(单机模式有效)
		Cluster      bool
		PoolSize     int // 连接池大小
		MinIdleConns int // 最小空闲连接数
	}

	JaegerConf struct {
		Endpoint   string
		SampleRate float64 // 采样率 0.0~1.0,0 表示用默认 10%
	}
)

func New(path string) *Conf {
	confPath := os.Getenv("CONF")
	if confPath == "" {
		confPath = path
	}
	v := viper.New()
	v.AutomaticEnv()                                   // 自动识别环境变量
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_")) // 将 . 替换为 _ SERVER_PORT=10088 覆盖文件中 server下面port值
	v.SetConfigFile(confPath)

	if e := v.ReadInConfig(); e != nil {
		panic(fmt.Errorf("fatal error config file: %w", e))
	}
	c := new(Conf)
	if e := v.Unmarshal(c); e != nil {
		panic(fmt.Errorf("fatal error config to Conf: %w", e))
	}

	if c.RemoteConfig && len(c.EtcdConfig.Host) > 0 {
		// ==================== 纯远程配置模式 (remoteConfig == true) ====================
		// 本地与远程严格互斥，绝不合并覆盖。
		// 本地配置仅作为引导(Bootstrap),业务应用配置100%从 etcd 拉取。
		w, err := xetcd.NewWatcher(c.EtcdConfig.Host, c.EtcdConfig.Username, c.EtcdConfig.Password)
		if err != nil {
			panic(fmt.Errorf("[remote-config] create watcher failed: %w", err))
		}
		project, env := c.Project, c.Env
		if project == "" {
			project = "default"
		}
		if env == "" {
			env = EnvDebug
		}
		if err := w.Watch(context.Background(), project, env); err != nil {
			panic(fmt.Errorf("[remote-config] watch failed: %w", err))
		}
		c.Watcher = w

		// 启动期：构造纯净对象接收 etcd 远端全量配置，不掺杂本地 yaml 的业务配置
		rc := &Conf{
			Project:      c.Project,
			Env:          c.Env,
			Version:      c.Version,
			RemoteConfig: c.RemoteConfig,
			EtcdConfig:   c.EtcdConfig,
			Watcher:      w,
		}
		rc.loadEtcd(w)
		c = rc

		// 运行期：监听 etcd 变更实现动态热重载，不受本地 yaml 影响
		w.SetOnChange(func() {
			nc := &Conf{
				Project:      c.Project,
				Env:          c.Env,
				Version:      c.Version,
				RemoteConfig: c.RemoteConfig,
				EtcdConfig:   c.EtcdConfig,
				Watcher:      c.Watcher,
			}
			nc.loadEtcd(w)
			c.update(nc)
		})
	} else {
		// ==================== 纯本地配置模式 (remoteConfig == false) ====================
		// 完全随本地 yaml 变动而热更新，不连接 etcd，不受远程影响。
		v.OnConfigChange(func(event fsnotify.Event) {
			nc := new(Conf)
			if e := v.Unmarshal(nc); e != nil {
				fmt.Fprintf(os.Stderr, "config hot reload unmarshal failed: %s\n", e)
				return
			}
			c.update(nc)
		})
		v.WatchConfig()
	}

	c.current.Store(c)
	return c
}

// Get 返回当前配置的稳定快照指针,热重载后返回新快照。
// 运行期重复读取必须走 Get(),零分配、零竞态。
func (c *Conf) Get() *Conf {
	return c.current.Load()
}

// OnUpdate 注册配置变更监听器 (无论是本地 yaml 还是 etcd 热重载, 均会触发)
func (c *Conf) OnUpdate(fn func(newConf *Conf)) {
	c.hookMu.Lock()
	defer c.hookMu.Unlock()
	c.onUpdateHooks = append(c.onUpdateHooks, fn)
}

// update 原子替换快照指针,并维持自指以防快照上连续 Get,最后广播热更新事件
func (c *Conf) update(nc *Conf) {
	c.hookMu.Lock()
	nc.onUpdateHooks = c.onUpdateHooks
	hooks := make([]func(newConf *Conf), len(c.onUpdateHooks))
	copy(hooks, c.onUpdateHooks)
	c.hookMu.Unlock()

	nc.current.Store(nc)
	c.current.Store(nc)

	for _, fn := range hooks {
		fn(nc)
	}
}

// loadEtcd 将 etcd 中拉取的所有远端配置填充至 Conf 中 (仅用于 remoteConfig 模式)
func (c *Conf) loadEtcd(w *xetcd.Watcher) {
	if w == nil {
		return
	}
	configs := w.All()
	if len(configs) == 0 {
		return
	}
	etcdV := viper.New()
	for _, cv := range configs {
		if cv == nil || cv.Content == "" {
			continue
		}
		subV := viper.New()
		subV.SetConfigType("yaml")
		if err := subV.ReadConfig(strings.NewReader(cv.Content)); err == nil {
			_ = etcdV.MergeConfigMap(subV.AllSettings())
		}
	}
	_ = etcdV.Unmarshal(c)
}

// Scan 从 etcd 配置中心反序列化指定 group/dataId 的配置到 target 结构体
func (c *Conf) Scan(group, dataId string, target any) error {
	w := c.Get().Watcher
	if w == nil {
		return fmt.Errorf("etcd watcher not initialized")
	}
	return w.Scan(group, dataId, target)
}

// GetRawConfig 获取 etcd 中指定的原始配置元信息
func (c *Conf) GetRawConfig(group, dataId string) *xetcd.ConfigValue {
	if w := c.Get().Watcher; w != nil {
		return w.Get(group, dataId)
	}
	return nil
}
