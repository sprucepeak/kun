package encrypt

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"strings"
	"testing"
)

func TestHashAndBcrypt(t *testing.T) {
	// MD5 测试
	raw := "hello-kun"
	md5Val := MD5(raw)
	if len(md5Val) != 32 {
		t.Fatalf("unexpected md5 length: %d", len(md5Val))
	}
	if MD5to16(raw) != md5Val[8:24] {
		t.Fatalf("MD5to16 mismatch")
	}

	// SHA256 / SHA512
	sha256Val := Sha256(raw, "secret-key")
	if len(sha256Val) != 64 {
		t.Fatalf("unexpected sha256 length: %d", len(sha256Val))
	}

	// Bcrypt 测试
	pwd := "MySecurePassword123!"
	hashed, err := BcryptHash(pwd)
	if err != nil {
		t.Fatalf("BcryptHash failed: %v", err)
	}
	if !BcryptCompare(hashed, pwd) {
		t.Fatalf("BcryptCompare should match for correct password")
	}
	if BcryptCompare(hashed, "WrongPassword") {
		t.Fatalf("BcryptCompare should fail for wrong password")
	}

	// 密码超长拦截测试 (72 字节上限)
	longPwd := strings.Repeat("A", 73)
	if _, err := BcryptHash(longPwd); err == nil {
		t.Fatalf("BcryptHash should reject password > 72 bytes")
	}
	if BcryptCompare(hashed, longPwd) {
		t.Fatalf("BcryptCompare should reject password > 72 bytes")
	}
}

func TestAESSuite(t *testing.T) {
	keyStr := "12345678901234567890123456789012" // 32 字节
	raw := "kun configuration content yaml/json"

	// 1. HashKey32
	key32 := HashKey32("any-arbitrary-string-token-secret")
	if len(key32) != 32 {
		t.Fatalf("HashKey32 length must be 32, got %d", len(key32))
	}

	// 2. 配置中心专用字节切片 AES-GCM
	cipherText, err := AESGCMEncrypt([]byte(raw), key32)
	if err != nil {
		t.Fatalf("AESGCMEncrypt failed: %v", err)
	}
	plainBytes, err := AESGCMDecrypt(cipherText, key32)
	if err != nil {
		t.Fatalf("AESGCMDecrypt failed: %v", err)
	}
	if string(plainBytes) != raw {
		t.Fatalf("AESGCM roundtrip mismatch: got %s, want %s", string(plainBytes), raw)
	}

	// 3. 字符串版 AES-GCM (默认 AESEncrypt / AESDecrypt)
	gcmCipher, err := AESEncrypt(raw, keyStr)
	if err != nil {
		t.Fatalf("AESEncrypt failed: %v", err)
	}
	gcmPlain, err := AESDecrypt(gcmCipher, keyStr)
	if err != nil {
		t.Fatalf("AESDecrypt failed: %v", err)
	}
	if gcmPlain != raw {
		t.Fatalf("AESEncrypt/Decrypt mismatch: got %s, want %s", gcmPlain, raw)
	}

	// 4. AES CBC
	cbcKey := "1234567890123456" // 16 字节
	cbcCipher, err := AESEncryptCBC(raw, cbcKey)
	if err != nil {
		t.Fatalf("AESEncryptCBC failed: %v", err)
	}
	cbcPlain, err := AESDecryptCBC(cbcCipher, cbcKey)
	if err != nil {
		t.Fatalf("AESDecryptCBC failed: %v", err)
	}
	if cbcPlain != raw {
		t.Fatalf("AESEncryptCBC/DecryptCBC mismatch")
	}

	// 5. AES CTR
	ctrCipher, err := AESEncryptCTR(raw, cbcKey)
	if err != nil {
		t.Fatalf("AESEncryptCTR failed: %v", err)
	}
	ctrPlain, err := AESDecryptCTR(ctrCipher, cbcKey)
	if err != nil {
		t.Fatalf("AESDecryptCTR failed: %v", err)
	}
	if ctrPlain != raw {
		t.Fatalf("AESEncryptCTR/DecryptCTR mismatch")
	}
}

func TestRSASecurity(t *testing.T) {
	// 生成临时 2048 位 RSA 密钥对
	privKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatalf("failed to generate rsa key: %v", err)
	}

	privBytes := x509.MarshalPKCS1PrivateKey(privKey)
	privPem := pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: privBytes})

	pubBytes, err := x509.MarshalPKIXPublicKey(&privKey.PublicKey)
	if err != nil {
		t.Fatalf("failed to marshal public key: %v", err)
	}
	pubPem := pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: pubBytes})

	rsaSec := NewRSASecurity()
	if err := rsaSec.SetPublicKey(string(pubPem)); err != nil {
		t.Fatalf("SetPublicKey failed: %v", err)
	}
	if err := rsaSec.SetPrivateKey(string(privPem)); err != nil {
		t.Fatalf("SetPrivateKey failed: %v", err)
	}

	// 1. 公钥加密，私钥解密
	msg := "hello rsa encryption"
	encrypted, err := rsaSec.PubKeyEncrypt(msg)
	if err != nil {
		t.Fatalf("PubKeyEncrypt failed: %v", err)
	}
	decrypted, err := rsaSec.PriKeyDecrypt(encrypted)
	if err != nil {
		t.Fatalf("PriKeyDecrypt failed: %v", err)
	}
	if decrypted != msg {
		t.Fatalf("RSA PubKeyEncrypt/PriKeyDecrypt mismatch: got %s, want %s", decrypted, msg)
	}

	// 2. 私钥签名，公钥验签
	sig, err := rsaSec.PriKeyEncrypt(msg)
	if err != nil {
		t.Fatalf("PriKeyEncrypt (sign) failed: %v", err)
	}
	if err := rsaSec.Verify(msg, sig); err != nil {
		t.Fatalf("Verify failed: %v", err)
	}
	if err := rsaSec.Verify("tampered-message", sig); err == nil {
		t.Fatalf("Verify should fail for tampered message")
	}
}

func TestHashids(t *testing.T) {
	salt := "kun-id-salt"
	encoded, err := HashidsEncode(salt, 8, 1001, 2002)
	if err != nil {
		t.Fatalf("HashidsEncode failed: %v", err)
	}
	decoded, err := HashidsDecode(salt, 8, encoded)
	if err != nil {
		t.Fatalf("HashidsDecode failed: %v", err)
	}
	if len(decoded) != 2 || decoded[0] != 1001 || decoded[1] != 2002 {
		t.Fatalf("Hashids roundtrip mismatch: got %v", decoded)
	}
}
