package svc

import (
	"context"
	"errors"
	"fmt"

	"basic/internal/repository/cache"
	"basic/internal/repository/db"
	"basic/pkg/xerror"
	"basic/pkg/xlog"

	"golang.org/x/sync/singleflight"
)

//go:generate mockgen -source=./demo.go -destination=../../../test/mocks/service/demo.go  -package mock_service

var _ DemoSvc = (*demoSvc)(nil)

type (
	DemoSvc interface {
		Detail(ctx context.Context, id int64) (*DemoResp, error)
		FindList(ctx context.Context, args *DemoListReq) ([]*DemoResp, int64, error)
		Create(ctx context.Context, args *DemoCreateReq) error
		Update(ctx context.Context, args *DemoUpdateReq) error
		Delete(ctx context.Context, id int64) error
		SoftDelete(ctx context.Context, id int64) error
	}
	DemoCtx struct {
		*Ctx
		DemoDb    db.DemoDb
		DemoCache cache.DemoCache
	}
	demoSvc struct {
		ctx *DemoCtx
		sf  singleflight.Group
	}

	// DemoResp 业务响应 DTO (面向 API 接口输出的纯净视图, 严格屏蔽持久层内部/敏感字段)
	DemoResp struct {
		Id    int64   `json:"id"`    // ID
		Name  string  `json:"name"`  // 名称
		Test1 float64 `json:"test1"` // 测试1
		Test4 int8    `json:"test4"` // 测试4
	}

	// DemoCreateReq 创建 Demo 接口请求入参
	DemoCreateReq struct {
		Name  string  `form:"name" json:"name" binding:"required"`
		Test1 float64 `form:"test1" json:"test1"`
		Test4 int8    `form:"test4" json:"test4"`
	}

	// DemoUpdateReq 更新 Demo 接口请求入参
	DemoUpdateReq struct {
		Id    int64   `json:"id" binding:"required"`
		Name  string  `json:"name"`
		Test1 float64 `json:"test1"`
		Test4 int8    `json:"test4"`
	}

	// DemoListReq 列表查询接口请求入参 (内嵌公共分页模型 PageReq)
	DemoListReq struct {
		PageReq

		Id   *int64 `form:"id"   json:"id"`
		Name string `form:"name" json:"name"`
	}
)

func NewDemoSvc(ctx *DemoCtx) DemoSvc {
	return &demoSvc{
		ctx: ctx,
	}
}

// 查找一个(接入 singleflight 防缓存击穿)
func (d *demoSvc) Detail(ctx context.Context, id int64) (*DemoResp, error) {
	if id <= 0 {
		return nil, xerror.NewError(xerror.InvalidArgument, "Get Demo Detail invalid id", nil)
	}

	xlog.Info(ctx, "Get Demo Detail", "测试手工日志")

	// 1. 优先查通用中间缓存 (多处业务共享复用)
	if cacheData, cacheErr := d.ctx.DemoCache.Get(ctx, id); cacheErr == nil {
		return CacheToDemoResp(cacheData), nil
	}

	// 2. 缓存未命中: singleflight 合并同 ID 并发请求,防缓存击穿
	val, err, _ := d.sf.Do(fmt.Sprintf("demo:detail:%d", id), func() (any, error) {
		// double check 缓存,避免并发排队协程重复打库
		if dCached, cErr := d.ctx.DemoCache.Get(ctx, id); cErr == nil {
			return CacheToDemoResp(dCached), nil
		}

		demoDb, dbErr := d.ctx.DemoDb.Find(ctx, id)
		if dbErr != nil {
			return nil, dbErr
		}

		// 将 DB 底层数据清洗为可多处复用的中间缓存数据，写入缓存
		cacheItem := ToCacheDemo(demoDb)
		if cErr := d.ctx.DemoCache.Set(ctx, id, cacheItem, 300); cErr != nil {
			xlog.Error(ctx, fmt.Sprintf("set demo cache failed, id=%d", id), cErr)
		}

		// 转换为当前 API 接口所需的纯净 Response DTO
		return ToDemoResp(demoDb), nil
	})

	if err != nil {
		if errors.Is(err, db.ErrNotFound) {
			return nil, xerror.NewError(xerror.BusinessError, "没有相关记录", err)
		}
		return nil, xerror.NewError(xerror.BusinessError, "Get Demo Detail 失败", err)
	}

	return val.(*DemoResp), nil
}

// 查找列表
func (d *demoSvc) FindList(ctx context.Context, args *DemoListReq) ([]*DemoResp, int64, error) {
	dbArgs := ToDbDemoSearch(args)

	list, total, listErr := d.ctx.DemoDb.ListWithTotal(ctx, dbArgs)
	if listErr != nil {
		if errors.Is(listErr, db.ErrNotFound) {
			return []*DemoResp{}, 0, nil
		}
		return nil, 0, xerror.NewError(xerror.BusinessError, "Get Demo List 失败", listErr)
	}
	return ToDemoRespList(list), total, nil
}

// 创建
func (d *demoSvc) Create(ctx context.Context, args *DemoCreateReq) error {
	_, dbErr := d.ctx.DemoDb.Insert(ctx, ToDbDemoForCreate(args))
	if dbErr != nil {
		return xerror.NewError(xerror.BusinessError, "Create Demo 失败", dbErr)
	}
	return nil
}

// 修改(事务示例)
func (d *demoSvc) Update(ctx context.Context, args *DemoUpdateReq) error {
	if args.Id <= 0 {
		// id 不合法属于调用方参数错误，应返回 400 级 InvalidArgument，而非 500 级 BusinessError
		return xerror.NewError(xerror.InvalidArgument, "Update Demo invalid id", nil)
	}
	err := d.ctx.DemoDb.DemoUpdateTrans(ctx, args.Id, ToDbDemoForUpdate(args))
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "Update Demo 失败", err)
	}
	// DemoUpdateTrans 内部会删除 id-1 的记录,故 args.Id 与 args.Id-1 的缓存都要失效。
	d.invalidateCache(ctx, args.Id)
	d.invalidateCache(ctx, args.Id-1)
	return nil
}

// 物理删除
func (d *demoSvc) Delete(ctx context.Context, id int64) error {
	if id <= 0 {
		return xerror.NewError(xerror.InvalidArgument, "Delete Demo invalid id", nil)
	}
	err := d.ctx.DemoDb.Delete(ctx, []int64{id})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "Delete Demo 失败", err)
	}
	d.invalidateCache(ctx, id)
	return nil
}

// 逻辑删除
func (d *demoSvc) SoftDelete(ctx context.Context, id int64) error {
	if id <= 0 {
		return xerror.NewError(xerror.InvalidArgument, "SoftDelete Demo invalid id", nil)
	}
	err := d.ctx.DemoDb.SoftDelete(ctx, []int64{id})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "SoftDelete Demo 失败", err)
	}
	d.invalidateCache(ctx, id)
	return nil
}

// invalidateCache 失效指定 id 的缓存(Redis + 本地)。
// 缓存删除失败不阻断主流程(数据已落库),仅记录日志,等 TTL 自然过期。
func (d *demoSvc) invalidateCache(ctx context.Context, id int64) {
	if id <= 0 {
		return
	}
	if err := d.ctx.DemoCache.Delete(ctx, id); err != nil {
		xlog.Error(ctx, fmt.Sprintf("invalidate demo cache failed, id=%d", id), err)
	}
}

// =============================================================================
// 层间转换函数 (DO <-> Cache 中间数据 <-> DTO)
// =============================================================================

// ToCacheDemo 将底层 db.Demo 转换为可多处共享的中间缓存模型 cache.Demo
func ToCacheDemo(do *db.Demo) *cache.Demo {
	if do == nil {
		return nil
	}
	return &cache.Demo{
		Id:    do.Id,
		Name:  do.Name,
		Test1: do.Test1,
		Test4: do.Test4,
	}
}

// CacheToDemoResp 将多处通用的中间缓存数据转换为当前接口响应 DTO
func CacheToDemoResp(c *cache.Demo) *DemoResp {
	if c == nil {
		return nil
	}
	return &DemoResp{
		Id:    c.Id,
		Name:  c.Name,
		Test1: c.Test1,
		Test4: c.Test4,
	}
}

// ToDemoResp 将数据库底层实体 db.Demo 直接转换为业务响应 DTO
func ToDemoResp(do *db.Demo) *DemoResp {
	if do == nil {
		return nil
	}
	return &DemoResp{
		Id:    do.Id,
		Name:  do.Name,
		Test1: do.Test1,
		Test4: do.Test4,
	}
}

// ToDemoRespList 批量将数据库底层实体转换为业务响应 DTO 列表
func ToDemoRespList(dos []*db.Demo) []*DemoResp {
	if dos == nil {
		return []*DemoResp{}
	}
	res := make([]*DemoResp, len(dos))
	for i, do := range dos {
		res[i] = ToDemoResp(do)
	}
	return res
}

// ToDbDemoForCreate 将创建入参转换为 db.Demo 实体
func ToDbDemoForCreate(req *DemoCreateReq) *db.Demo {
	if req == nil {
		return nil
	}
	return &db.Demo{
		Name:  req.Name,
		Test1: req.Test1,
		Test4: req.Test4,
	}
}

// ToDbDemoForUpdate 将更新入参转换为 db.Demo 实体 (仅赋值允许修改的字段)
func ToDbDemoForUpdate(req *DemoUpdateReq) *db.Demo {
	if req == nil {
		return nil
	}
	return &db.Demo{
		Id:    req.Id,
		Name:  req.Name,
		Test1: req.Test1,
		Test4: req.Test4,
	}
}

// ToDbDemoSearch 将列表查询入参转换为 Repository 层的 db.DemoSearch
func ToDbDemoSearch(req *DemoListReq) *db.DemoSearch {
	if req == nil {
		return &db.DemoSearch{}
	}
	return &db.DemoSearch{
		SearchPage: req.PageReq.ToDbSearchPage(),
		Id:         req.Id,
		Name:       req.Name,
	}
}
