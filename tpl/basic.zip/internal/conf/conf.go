package conf

import (
	"basic/pkg/token"
	"basic/pkg/xconfig"
	"basic/pkg/xdb"
	"basic/pkg/xlog"
	"basic/pkg/xredis"
	xhttp "basic/pkg/xserver/http"

	"github.com/google/wire"
)

type (
	// Conf 是应用全量配置模型。
	// 它聚合了各个独立组件暴露的自身 Config 结构，专属于当前业务服务。
	Conf struct {
		Project      string           `mapstructure:"project"`
		Env          string           `mapstructure:"env"`
		Version      string           `mapstructure:"version"`
		RemoteConfig xconfig.EtcdConf `mapstructure:"remoteConfig"`

		Server xhttp.Config `mapstructure:"server"`

		Token    token.Config  `mapstructure:"token"`
		Log      xlog.Config   `mapstructure:"log"`
		Database xdb.Config    `mapstructure:"database"`
		Redis    xredis.Config `mapstructure:"redis"`
		Jaeger   JaegerConf    `mapstructure:"jaeger"`
	}

	JaegerConf struct {
		Endpoint   string  `mapstructure:"endpoint"`
		SampleRate float64 `mapstructure:"sampleRate"`
	}

	// Container 组合了启动期不可变配置 Conf 与运行期泛型管理器 Manager[Conf]。
	// 启动期直接访问字段(如 c.Database.Source)，运行期使用 c.Get().Xxx 获取最新快照。
	Container struct {
		Conf
		*xconfig.Manager[Conf]
	}
)

// New 初始化应用配置容器
func New(path string) *Container {
	mgr, initial, err := xconfig.New[Conf](path)
	if err != nil {
		panic(err)
	}
	return &Container{
		Conf:    *initial,
		Manager: mgr,
	}
}

// Wire Provider 函数：从容器中提取各组件所需的独立配置
func ProvideDatabaseConfig(c *Container) xdb.Config { return c.Database }
func ProvideRedisConfig(c *Container) xredis.Config { return c.Redis }
func ProvideLogConfig(c *Container) xlog.Config     { return c.Log }
func ProvideTokenConfig(c *Container) token.Config  { return c.Token }
func ProvideServerConfig(c *Container) xhttp.Config { return c.Server }

// ProviderSet 用于 wire 依赖注入
var ProviderSet = wire.NewSet(
	New,
	ProvideDatabaseConfig,
	ProvideRedisConfig,
	ProvideLogConfig,
	ProvideTokenConfig,
	ProvideServerConfig,
)
