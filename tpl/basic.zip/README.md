# basic — 精简基础工程布局

## 技术栈

| 类别 | 库 / 组件 | 说明 |
| :--- | :--- | :--- |
| Web 框架 | [Gin](https://github.com/gin-gonic/gin) | 高性能 HTTP 路由、上下文与中间件 |
| ORM 引擎 | [Gorm](https://github.com/go-gorm/gorm) | 数据库操作、连接池与事务管理 |
| 依赖注入 | [Wire](https://github.com/google/wire) | Google 编译期依赖注入（Compile-time DI） |
| 配置管理 | [Viper](https://github.com/spf13/viper) | 多环境 YAML 配置动态加载 |
| 结构化日志 | [Zap](https://github.com/uber-go/zap) | 高性能结构化日志，支持动态跳层与业务穿透 |
| 链路追踪 | [OpenTelemetry](https://github.com/open-telemetry/opentelemetry-go) | 全链路分布式追踪支持 |
| JWT 鉴权 | [Golang-jwt](https://github.com/golang-jwt/jwt) | HS384 双 Token 轮换、单端互斥、防重放熔断 |
| 缓存服务 | [Go-redis](https://github.com/redis/go-redis) | Redis 单机/集群客户端，单槽 Lua 原子操作 |
| 参数校验 | [Validator](https://github.com/go-playground/validator) | 请求参数规则校验与多语言翻译 |

---

## 分层架构说明

项目采用经典的分层解耦架构，通过 Google `Wire` 在编译期完成依赖组装：

```
┌─────────────────────────────────────────────────────────┐
│                    router / handler                     │  ── 路由分发 & 控制层（参数校验、协议转换）
├─────────────────────────────────────────────────────────┤
│                      service / svc                      │  ── 核心业务逻辑编排层（事务管理、规则运算）
├─────────────────────────────────────────────────────────┤
│           repository/db   |   repository/cache          │  ── 数据持久化访问层（DB CRUD + 二级缓存）
├─────────────────────────────────────────────────────────┤
│                         pkg / x*                        │  ── 基础设施与公共工具库
└─────────────────────────────────────────────────────────┘
```

- **handler**: 负责接收 HTTP 请求，执行入参校验（Validator），调用 Service 编排逻辑，返回统一 JSON 响应。
- **service**: 承载核心业务逻辑，负责事务控制、领域计算与缓存策略，调用 Repository。
- **repository**: 屏蔽底层数据库与缓存的具体实现细节，提供纯粹的数据持久化接口。
- **pkg**: 基础设施工具包（日志、配置、加密、数据库适配、JWT 鉴权等）。

---

## 目录结构

```
.
├── cmd/                           服务入口目录
│   └── server/                    HTTP 服务入口
│       ├── main.go                Wire DI 启动入口，信号优雅关闭
│       └── wire/                  Wire 依赖注入与应用装配
│           ├── app.go             HTTP 应用装配（Gin 模式、中间件、路由与资源回收）
│           ├── wire.go            声明 Server 全栈分层依赖
│           └── wire_gen.go        Wire 自动生成代码
├── config/                        配置文件目录
│   ├── local.yml                  本地开发环境配置
│   └── release.yml                生产环境标准配置
├── docs/                          项目文档
│   └── sql/                       数据库建表脚本
│       └── basic.sql              数据库初始化 SQL
├── internal/                      内部业务核心逻辑
│   ├── handler/                   HTTP 处理器层
│   │   ├── demo.go                Demo 演示处理器
│   │   └── serverDI.go            Wire DI 注册全部 Handler
│   ├── global/                    全局常量与枚举
│   │   └── constants.go           上下文 Key、统一前缀与全局常量
│   ├── middleware/                HTTP 中间件
│   │   ├── auth.go                JWT 鉴权拦截器（支持强制/可选模式）
│   │   ├── cors.go                CORS 跨域安全配置
│   │   ├── metrics.go             Prometheus 性能指标收集
│   │   ├── ratelimit.go           单机 / Redis 分布式滑动窗口限流器
│   │   └── recovery.go            Panic 异常捕获与堆栈保护
│   ├── repository/                数据访问与持久化层
│   │   ├── cache/                 缓存层
│   │   │   ├── demo.go            二级缓存（Local go-cache + Redis）实现
│   │   │   ├── keys.go            缓存 Key 模板统一管理
│   │   │   └── local.go           线程安全本地内存缓存封装
│   │   ├── db/                    数据库访问层
│   │   │   ├── demo.go            Demo 自定义查询（分页/游标分页/事务更新）
│   │   │   ├── demo_gen.go        SqlGen 自动生成的基础 CRUD 样板代码
│   │   │   └── mysql.go           GORM 连接池/事务/分页/排序封装
│   │   └── serverDI.go            Wire DI 注册全部 Repository
│   ├── router/                    路由注册层
│   │   ├── router.go              全局通用路由（404/健康检查/Metrics）
│   │   ├── serverDI.go            Wire DI 注册全部路由
│   │   └── v0/demo.go             v0 版本 Demo RESTful 路由组
│   └── service/                   业务服务层
│       ├── svc/                   核心业务服务
│       │   ├── context.go         服务公共上下文（配置/DB/Redis）
│       │   └── demo.go            Demo 业务逻辑实现（CRUD + 缓存）
│       └── serverDI.go            Wire DI 注册 HTTP 服务层
├── pkg/                           通用公共工具库
│   ├── encrypt/                   安全加解密套件（AES/RSA/MD5/Bcrypt）
│   ├── token/                     JWT 认证中心（双 Token 轮换/单端互斥/防重放）
│   ├── utils/                     常用工具函数（Snowflake/时间/字符串/网络/协程池）
│   ├── validator/                 参数校验器与翻译器
│   ├── xconfig/                   配置动态加载器（Viper 驱动）
│   ├── xdb/                       数据库集成与链路追踪适配器（智能穿透调用栈）
│   ├── xerror/                    结构化业务错误码与错误模型
│   ├── xhttp/                     统一 JSON 响应包装与分页入参
│   ├── xlog/                      高性能结构化日志（Zap + OpenTelemetry 追踪）
│   ├── xredis/                    Redis 连接池与操作封装（Cluster 友好）
│   └── xserver/                   服务抽象与生命周期优雅退出（Closer）
└── README.md                      项目说明文档
```

---

## 环境要求

- **Go**: `1.25.11` 或更高版本
- **Git**
- **Wire**: `go install github.com/google/wire/cmd/wire@latest`

---

## 常用开发命令

### 1. 启动服务

```bash
kun run
```

### 2. 编译依赖注入 (Wire)

修改了任何服务依赖、构造函数或 DI 注册文件后，执行编译生成 `wire_gen.go`：

```bash
kun wire
```

### 3. 生成业务组件代码 (`kun gen`)

```bash
# 生成路由层代码
kun gen rt user

# 生成处理器层代码
kun gen hdl user

# 生成服务层代码
kun gen svc user

# 生成缓存层代码
kun gen cache user

# 一键生成 Handler + Service
kun gen hs user

# 一键生成 Router + Handler + Service
kun gen crud user

# 数据库逆向代码生成（自动生成 Model 与 Repository 样板代码）
kun gen db "root:123456@tcp(127.0.0.1:3306)/dbname" "*"
```

---

## 核心设计与开发约定

1. **依赖注入**: 模块间均通过 `Wire` 进行强类型编译期注入，避免手动管理单例与全局全局变量。
2. **配置管理**: 使用 `Viper` 动态加载 `config/` 下的配置文件，支持多环境无缝切换。
3. **结构化日志**: 业务模块与数据访问层 100% 仅依赖 `pkg/xlog` 包；支持 `WithCallerSkip` 动态跳层，数据库日志自动穿透 `_gen.go` 样板代码，直达业务服务源码行号。
4. **高安全认证**: 内置双 Token 体系，支持 CSPRNG 密码学安全 JTI、双密钥强隔离、时钟漂移容错与 Redis Cluster 单槽原子操作。
5. **统一错误模型**: 统一使用 `xerror` 包管理错误码，返回结构化 JSON 错误响应。
6. **缓存 Key 集中化**: 所有缓存 Key 集中在 `repository/cache/keys.go` 中统一定义，避免散落硬编码。
