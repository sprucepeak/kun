# basic — 精简基础工程布局

`basic` 是基于 Go 语言设计的高并发、高可用轻量级企业微服务工程样板脚手架。项目采用模块化分层解耦架构，通过 Google `Wire` 在编译期完成强类型依赖注入；移除了消息队列与异步调度中心等重量级组件，聚焦于纯粹、极速、低内存占用的 HTTP RESTful API 业务服务，同时完整保留了分布式链路追踪、敏感信息自动脱敏、单槽 Lua 原子认证与高可靠云原生健康检测能力。

---

## 技术栈与核心组件

| 类别 | 库 / 组件 | 说明 |
|:---|:---|:---|
| **Web 框架** | [Gin](https://github.com/gin-gonic/gin) | 高性能 HTTP 路由引擎、上下文与中间件链路 |
| **ORM 引擎** | [GORM](https://github.com/go-gorm/gorm) + [dbresolver](https://gorm.io/plugin/dbresolver) | 支持 MySQL / PostgreSQL / SQLite / ClickHouse 多驱动与主从读写分离 |
| **依赖注入** | [Wire](https://github.com/google/wire) | Google 编译期静态依赖注入（Compile-time DI），杜绝运行时反射 |
| **配置与服务治理** | [Viper](https://github.com/spf13/viper) + [etcd](https://github.com/etcd-io/etcd) | 多环境本地 YAML 动态加载，支持 etcd v3 远程配置热更新、租约服务注册与 gRPC 负载均衡 |
| **结构化日志** | [Zap](https://github.com/uber-go/zap) | 高性能结构化日志，支持 40+ 类敏感字段自动脱敏、动态跳层（穿透生成代码）与业务穿透 |
| **链路追踪** | [OpenTelemetry](https://github.com/open-telemetry/opentelemetry-go) | 全链路分布式追踪（Jaeger / OTLP 导出），无缝覆盖 HTTP、GORM、Redis |
| **认证与安全** | [Golang-jwt/jwt/v5](https://github.com/golang-jwt/jwt) | HS384 双 Token 轮换、单端互斥、防重放熔断、CSPRNG 安全随机数 |
| **缓存服务** | [go-redis/v9](https://github.com/redis/go-redis) + [go-cache](https://github.com/patrickmn/go-cache) | Redis 单机/集群客户端（单槽 `{u:userId}` Hash Tag 原子 Lua 鉴权）+ 线程安全本地内存二级缓存 |
| **并发防击穿** | [Singleflight](https://pkg.go.dev/golang.org/x/sync/singleflight) | 内存级请求合并，防止高并发热点数据缓存击穿打垮数据库 |
| **指标监控** | [Prometheus](https://github.com/prometheus/client_golang) | 内置 `/metrics` 端点，监控请求吞吐、耗时分布与状态码分布 |
| **参数校验** | [Validator/v10](https://github.com/go-playground/validator) | 请求参数规则校验、中文/多语言错误提示自动翻译与自定义校验扩展 |

---

## 分层架构设计

项目采用严格的单向依赖与工程化分层解耦架构，通过 Google `Wire` 在编译期完成装配：

```
┌─────────────────────────────────────────────────────────┐
│                    router / handler                     │  ── 路由分发 & 控制层（参数校验、协议转换、接口鉴权）
├─────────────────────────────────────────────────────────┤
│                      service / svc                      │  ── 核心业务逻辑编排层（事务管理、领域规则、单飞防击穿）
├─────────────────────────────────────────────────────────┤
│           repository/db   |   repository/cache          │  ── 数据持久化访问层（DB CRUD/读写分离 + 本地/Redis二级缓存）
├─────────────────────────────────────────────────────────┤
│                         pkg / x*                        │  ── 跨项目基础设施与公共组件库（日志、配置、Token、加解密等）
└─────────────────────────────────────────────────────────┘
```

- **handler**: 负责接收 HTTP 请求，执行入参校验（Validator），调用 Service 编排逻辑，返回统一 JSON 响应。
- **service (svc)**: 承载核心业务领域逻辑，负责数据库事务控制、Singleflight 防击穿、二级缓存策略调用。
- **repository**: 屏蔽底层数据库与缓存的具体实现细节，提供纯粹的数据持久化接口（支持游标分页与 SQL 注入拦截）。
- **pkg**: 通用基础设施库（Zap 日志脱敏、Viper/etcd 动态配置、AES/RSA/Bcrypt 加解密、JWT 双 Token 中心等）。

---

## 目录结构

```
.
├── cmd/                           项目服务入口目录
│   └── server/                    HTTP 业务服务入口
│       ├── main.go                启动入口（命令行参数解析、声明应用元信息）
│       └── wire/                  Wire 依赖注入与应用装配
│           ├── app.go             HTTP 应用装配（Gin 引擎、中间件栈、路由挂载与生命周期资源回收）
│           ├── wire.go            声明 Server 全栈分层依赖 ProviderSet
│           └── wire_gen.go        Wire 自动生成装配代码
├── config/                        配置文件目录
│   ├── dev.yml                    本地开发环境配置（包含 MySQL/Redis/etcd 连接与数据库驱动切换示例）
│   └── release.yml                生产环境标准配置模板（支持无敏感明文，完全由环境变量注入）
├── docs/                          项目文档与资产
│   └── sql/                       数据库初始化与变更脚本
│       └── basic.sql              全量数据库建表结构与初始演示数据
├── internal/                      内部业务核心逻辑
│   ├── conf/                      应用配置模型与 Wire 依赖注入
│   │   └── conf.go                应用全量配置模型（Conf）与配置容器（Container），聚合组件独立配置并提供 Wire ProviderSet
│   ├── global/                    全局常量与枚举
│   │   ├── code.go                业务错误码定义（统一错误码常量、CodeMap 映射字典与 Msg/New 便捷构造函数）
│   │   └── constant.go            上下文 Key、路由统一前缀与全局基础常量
│   ├── handler/                   HTTP 控制器与处理器层
│   │   ├── demo.go                Demo 演示处理器（CRUD、参数校验、分页查询）
│   │   └── serverDI.go            Wire DI 注册全部 Handler
│   ├── middleware/                HTTP 中间件
│   │   ├── auth.go                JWT 鉴权拦截器（支持 Auth 强制模式、WriteAuth 可选模式）
│   │   ├── cors.go                CORS 跨域安全配置（支持白名单精准匹配）
│   │   ├── metrics.go             Prometheus 吞吐量与请求耗时性能监控
│   │   ├── ratelimit.go           单机滑动窗口与 Redis 分布式限流器（支持触发封禁与 Retry-After）
│   │   └── recovery.go            Panic 异常捕获、调用栈格式化与全局错误日志落地
│   ├── repository/                数据访问与持久化层
│   │   ├── cache/                 缓存层
│   │   │   ├── demo.go            二级缓存实现（Local go-cache + Redis 互补）
│   │   │   ├── keys.go            缓存 Key 模板统一管理
│   │   │   └── local.go           线程安全本地内存缓存封装
│   │   ├── db/                    数据库持久化层
│   │   │   ├── db.go              GORM 客户端封装、事务（Transaction）、排序安全校验、通用分页逻辑
│   │   │   ├── demo.go            Demo 自定义业务查询（多字段组合检索、事务更新）
│   │   │   └── demo_gen.go        SqlGen 自动生成的标准 CRUD 样板代码
│   │   └── serverDI.go            Wire DI 注册全部 Repository
│   ├── router/                    路由注册层
│   │   ├── router.go              全局基础设施路由（404缺省、/metrics监控、/healthz与/ready探活）
│   │   ├── serverDI.go            Wire DI 注册全部业务路由
│   │   └── v0/demo.go             v0 版本 RESTful 业务路由组（API 公开/业务管理路由组）
│   └── service/                   业务服务层
│       ├── svc/                   核心业务逻辑实现
│       │   ├── context.go         服务公共上下文定义与标准分页契约模型（PageReq/PageResp/PageMoreResp）
│       │   └── demo.go            Demo 业务逻辑实现（CRUD、二级缓存流转、Singleflight 防击穿）
│       └── serverDI.go            Wire DI 注册 HTTP 服务层
├── pkg/                           通用跨项目公共基础设施工具库
│   ├── encrypt/                   安全加解密套件（AES-GCM/CBC、RSA 签名验签、MD5、Bcrypt 密码哈希）
│   ├── token/                     JWT 认证中心（双 Token 轮换、单端互斥、防重放熔断、基于官方 redis.UniversalClient 接口单槽原子鉴权）
│   ├── utils/                     常用通用工具库（Sonyflake 雪花ID、时间/网络/文件/协程池/正则校验）
│   ├── validator/                 参数校验引擎（基于 Validator v10，内置常用正则与多语言翻译）
│   ├── xconfig/                   通用泛型配置管理器（Manager[T any]，零业务耦合、支持本地 YAML 与 etcd 远程互斥切换，原子快照与变更通知）
│   ├── xdb/                       数据库连接池封装（基于独立 Config 驱动，适配 MySQL/PG/SQLite/ClickHouse、dbresolver 读写分离）
│   ├── xerror/                    统一错误抽象契约模型（定义通用 Error 接口与标准状态，彻底解耦具体业务错误码）
│   ├── xetcd/                     etcd v3 客户端套件（租约心跳注册 Registrar、gRPC 发现 Resolver、配置 Watcher）
│   ├── xhttp/                     统一 HTTP JSON 响应封装（泛型支持、标准嵌套分页契约、支持外部错误码字典映射注入）
│   ├── xlog/                      高性能 Zap 结构化日志（基于独立 Config 驱动，40+类敏感数据掩码、链路 Span 关联、底层零偏移与业务动态跳层）
│   ├── xredis/                    Redis 连接池封装（基于独立 Config 驱动，单机/集群自适应、Lua 脚本预编译 EVALSHA、追踪注入）
│   └── xserver/                   服务抽象与生命周期管理（HTTP 服务装配、优雅退出 LIFO Closer）
└── README.md                      项目技术说明文档
```

---

## 环境要求

- **Go**: `1.25.11` 或更高版本
- **Git**
- **Wire**: `go install github.com/google/wire/cmd/wire@latest`

---

## 常用开发命令

### 1. 服务运行与编译

```bash
# 启动 HTTP API 服务 (默认加载 config/dev.yml)
kun run
# 或显式指定入口
kun run ./cmd/server

# 指定不同配置文件启动
go run ./cmd/server/main.go -conf ./config/release.yml

# 编译静态二进制文件
CGO_ENABLED=0 go build -ldflags="-s -w" -o ./bin/server ./cmd/server
```

### 2. 编译依赖注入 (Wire)

修改了任何服务依赖、构造函数或 DI 注册文件后，执行编译生成 `wire_gen.go`：

```bash
kun wire
# 或执行
wire ./cmd/server/wire
```

### 3. 生成业务组件代码 (`kun gen`)

```bash
# 生成路由层代码
kun gen rt <module>

# 生成处理器层代码
kun gen hdl <module>

# 生成服务层代码
kun gen svc <module>

# 生成缓存层代码
kun gen cache <module>

# 一键生成 Handler + Service
kun gen hs <module>

# 一键生成 Router + Handler + Service (标准 CRUD)
kun gen crud <module>

# 数据库逆向代码生成（自动生成 Model 与 Repository 样板代码）
kun gen db "root:password@tcp(127.0.0.1:3306)/dbname" "*"
```

---

## 配置中心与热更新操作手册

项目内置双模式配置驱动系统，支持本地 YAML 与远程 etcd 隔离运行，并对关键基础设施组件与业务配置提供了零停机热更新支持。

### 1. 运行模式设置 (`config/dev.yml` 或 `config/release.yml`)

在配置文件中通过 `remoteConfig` 参数切换工作模式，字段格式完全遵循 `config/dev.yml`：

```yaml
project: "basic"
env: "debug"
version: "0.0.1"

# 远程配置中心配置:
# hosts 为空列表 [] 时：自动降级为【纯本地模式】，完全由本地 YAML 配置驱动，修改本地文件即触发热更新，不连接 etcd；
# hosts 包含有效节点时：自动切换为【纯远程模式】，业务配置由 etcd 全权驱动并动态监听，杜绝本地冲突覆盖。
remoteConfig:
  hosts: []
  # - "127.0.0.1:2379"
  username: ""
  password: ""

# ──────────────── 常见热更新配置节点 (本地/远程修改均实时生效) ────────────────
token:
  secret: "123456ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  refreshSecret: "abcdefghijklmnopqrstuvwxyz123456"
  csrfKey: "abcdefghijklmnopqrstuvwxyz123456"
  expire: 3600        # 短 Token 过期时间(秒)
  refresh: 604800     # 刷新 Token 存活时长(秒)
  maxRefresh: 2592000 # 绝对最大有效期(秒)
  gracePeriod: 30     # 轮换宽限期(秒)
  queryKey: "Authorization"
  multiLogin: false   # 是否允许多端登录

log:
  level: "debug"   # 日志级别: debug, info, warn, error (原子指针切换，纳秒级生效)
  filePath: ""     # 落盘文件路径, 如: "./logs/app.log", 为空则不写文件
  stdout: true     # 是否输出到控制台

# 数据库配置: 支持 mysql / postgres (pgsql) / sqlite / clickhouse
# mysql, pgsql, clickhouse 支持主从读写分离(replicas); sqlite 单文件自动忽略从库
database:
  driver: "mysql"
  logLevel: "debug"
  source:
    - "root:password@tcp(127.0.0.1:3306)/basic?charset=utf8mb4&parseTime=true&loc=Asia%2FShanghai"
  replicas: []
  maxIdleConns: 10
  maxOpenConns: 100
  connMaxLifetime: 3600
```

### 2. 开箱即用的内置热更新组件

修改配置后（本地 YAML 保存 或 远程 etcd 提交），无需重启服务即可立即生效：
* **结构化日志 (`xlog`)**：全参数支持热更新。
  * `level`（日志等级）：纯原子指针切换，零分配、纳秒级生效。
  * `filePath`、`stdout`（输出拓扑）：动态重建输出 Core，平滑替换全局 Logger，后台延迟 2 秒安全释放旧文件句柄，无掉日志风险。
* **JWT 鉴权 (`token`)**：密钥轮换、宽限期（`gracePeriod`）、双 Token 存活时长（`expire`/`refresh`）等参数热重载立即生效。

---

### 3. 精细化配置注入与热更新最佳实践

项目全面落实**精细化配置注入**与**通用泛型配置管理**架构：
- **底层基础设施零业务依赖**：`pkg/xdb`、`pkg/xredis`、`pkg/xlog`、`pkg/token` 等全部接收自身独立的 `Config` 结构体（如 `xdb.New(conf.Database)`），避免将庞大的全局 `*Conf` 传给底层驱动，极大降低耦合度与单元测试成本。
- **业务配置容器编排**：由 `internal/conf/conf.go` 聚合全量业务配置 `Conf` 与泛型管理器 `Manager[Conf]` 构造 `Container`，并通过 Wire 提供精细化子配置注入。

#### 方式一：随用随取最新快照（推荐普通业务使用）
业务层注入 `*conf.Container`。启动期直接访问字段（如 `c.Database.Source`），运行期通过 `c.Get()` 获取当前不可变的配置快照指针。底层由 `atomic.Pointer` 托管，**零锁、零分配、绝对线程安全**。
```go
type OrderService struct {
    conf *conf.Container // 由 Wire 编译期自动注入应用配置容器
}

func (s *OrderService) CreateOrder(ctx context.Context, req *CreateReq) error {
    // 每次通过 conf.Get() 获取当前最新配置快照
    cfg := s.conf.Get()
    
    // 直接读取最新参数，如超时、限流阈值、业务开关等
    writeTimeout := cfg.Server.WriteTimeout
    _ = writeTimeout
    return nil
}
```

#### 方式二：注册变更回调（组件内部维护状态时使用）
若自定义业务组件维护了私有状态、缓存或者需在参数变更时执行计算，可通过 `conf.OnUpdate` 注册监听：
```go
type RateLimiter struct {
    limit int
    mu    sync.RWMutex
}

func NewRateLimiter(c *conf.Container) *RateLimiter {
    limiter := &RateLimiter{
        limit: 100, // 初始值
    }

    // 注册热更新监听钩子
    c.OnUpdate(func(newConf *conf.Conf) {
        limiter.mu.Lock()
        defer limiter.mu.Unlock()

        // 当监听到配置刷新时更新内部参数
        // limiter.limit = newConf.YourBiz.Limit
        xlog.Info(context.Background(), "限流阈值已热更新")
    })

    return limiter
}
```

#### 方式三：远程 etcd 独立业务配置细粒度监听
在 `remoteConfig` 启用 etcd 下，若业务存在按 `group` 和 `dataId` 拆分的特定配置：
```go
// 1. 一次性反序列化指定远端配置到结构体
var payCfg MyPaymentConfig
if err := conf.Scan("pay", "alipay", &payCfg); err != nil {
    xlog.Error(context.Background(), "加载支付配置失败", xlog.KVStr("err", err.Error()))
}

// 2. 单独监听该项配置的动态变更
if w := conf.Get().Watcher; w != nil {
    w.Watch("pay", "alipay", func(cv *xetcd.ConfigValue) {
        var updated MyPaymentConfig
        if err := yaml.Unmarshal([]byte(cv.Content), &updated); err == nil {
            xlog.Info(context.Background(), "支付宝业务配置已动态更新")
        }
    })
}
```

> **注意（长连接组件提示）**：  
> 像 MySQL/Redis 这类底层维护长连接池的组件，若需要动态调整 DSN 或地址，应在 `conf.OnUpdate` 回调中比对连接串变动，新建连接池并原子切换 Client 指针，最后异步释放旧连接池。

---

## 核心设计与开发约定

1. **编译期依赖注入**: 模块间均通过 `Wire` 进行强类型静态编排，严禁手写繁杂的单例与全局变量传参。
2. **零基础包依赖日志规范**: 业务模块与数据访问层 100% 仅依赖 `pkg/xlog` 包；内置 40+ 类敏感信息脱敏；支持 `WithCallerSkip` 动态跳层，数据库日志自动穿透 `_gen.go` 样板代码，直达业务服务源码行号。
3. **高安全双 Token 规范**: 全量鉴权遵循 `pkg/token/README.md` 规范，支持 CSPRNG 密码学安全 JTI、双密钥强物理隔离、Redis 单槽 `{u:userId}` Hash Tag 原子批量校验与凭据泄露自动熔断。
4. **分层错误码与业务语义解耦**:
   - `pkg/xerror` 仅作为通用错误抽象契约层（定义 `Error` 接口及 `Success`/`Unknown` 标准码），零业务码污染。
   - 具体业务错误码及文案字典完全沉淀在 `internal/global/code.go`，提供 `global.Msg`、`global.New` 等便捷方法。
   - HTTP 装配层（`cmd/server/wire/app.go`）显式调用 `xhttp.RegisterCodeLookup(global.Msg)` 与 `xhttp.SetDefaultCodes(...)` 完成字典桥接。
8. **精细化配置依赖注入规范**:
   - 基础设施驱动层（`xdb`、`xredis`、`xlog`、`token` 等）严格仅接收自身专有的 `Config` 结构体，禁止底层反向依赖全局配置；
   - `pkg/xconfig` 保持通用泛型 `Manager[T any]`，所有业务全量配置模型在 `internal/conf/conf.go` 集中聚合，并通过 `conf.ProviderSet` 供 Wire 精细按需注入。
5. **缓存集中管理与防击穿**:
   - 所有 Redis 键与本地缓存 Key 严格集中在 `repository/cache/keys.go` 中定义模板，杜绝硬编码。
   - 高频查询场景使用 `singleflight.Group` 内存请求合并，避免缓存失效瞬间造成数据库雪崩。
6. **统一 HTTP 响应与分页契约规范**:
   - 响应外层全局严格统一为 `{ code, message, data }`。单体数据通过 `xhttp.Data` 承载，分页列表通过 `xhttp.List` 统一封装为标准嵌套结构 `data: { page, pageSize, total, items }`，杜绝平铺结构造成前端拦截器混淆。
   - 请求分页入参统一内嵌 `svc.PageReq`，支持 `form:"...,default=..."` 自动注入与 `ToDbSearchPage()` 默认值兜底。
   - 游标 `LastId` 规范为 `string` 类型，彻底规避雪花算法 64 位大整数在前端 JavaScript 中的精度截断问题。
7. **云原生健康检查与优雅关机**:
   - `/healthz`（存活探针）与 `/ready`（就绪探针，并发探测 DB/Redis 依赖）；
   - 退出时调用 `xserver.SetDraining()` 标记排空状态，使 `/ready` 立即向上游 Ingress / 负载均衡器返回 503 摘除流量，随后按 LIFO 逆序平滑释放数据库连接、Tracer 与日志句柄。
