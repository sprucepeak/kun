# basic — 精简基础工程布局

## 技术栈

| 类别       | 库 / 组件                                                           | 说明                                      |
|:-----------|:--------------------------------------------------------------------|:------------------------------------------|
| Web 框架   | [Gin](https://github.com/gin-gonic/gin)                             | 高性能 HTTP 路由、上下文与中间件          |
| ORM 引擎   | [Gorm](https://github.com/go-gorm/gorm)                             | 数据库操作、连接池与事务管理              |
| 依赖注入   | [Wire](https://github.com/google/wire)                              | Google 编译期依赖注入（Compile-time DI）  |
| 配置管理   | [Viper](https://github.com/spf13/viper)                             | 多环境 YAML 配置动态加载                  |
| 结构化日志 | [Zap](https://github.com/uber-go/zap)                               | 高性能结构化日志，支持动态跳层与业务穿透  |
| 链路追踪   | [OpenTelemetry](https://github.com/open-telemetry/opentelemetry-go) | 全链路分布式追踪支持                      |
| JWT 鉴权   | [Golang-jwt](https://github.com/golang-jwt/jwt)                     | HS384 双 Token 轮换、单端互斥、防重放熔断 |
| 缓存服务   | [Go-redis](https://github.com/redis/go-redis)                       | Redis 单机/集群客户端，单槽 Lua 原子操作  |
| 参数校验   | [Validator](https://github.com/go-playground/validator)             | 请求参数规则校验与多语言翻译              |

---

## 分层架构说明

项目采用经典的分层解耦架构，通过 Google `Wire` 在编译期完成依赖组装：

```
┌─────────────────────────────────────────────────────────┐
│                    router / handler                     │  ── 路由分发 & 控制层（参数校验、协议转换）
├─────────────────────────────────────────────────────────┤
│                      service / svc                      │  ── 核心业务逻辑编排层（事务管理、规则运算）
├─────────────────────────────────────────────────────────┤
│           repository/db   |   repository/cache          │  ── 数据持久化访问层（DB CRUD + 二级缓存）
├─────────────────────────────────────────────────────────┤
│                         pkg / x*                        │  ── 基础设施与公共工具库
└─────────────────────────────────────────────────────────┘
```

- **handler**: 负责接收 HTTP 请求，执行入参校验（Validator），调用 Service 编排逻辑，返回统一 JSON 响应。
- **service**: 承载核心业务逻辑，负责事务控制、领域计算与缓存策略，调用 Repository。
- **repository**: 屏蔽底层数据库与缓存的具体实现细节，提供纯粹的数据持久化接口。
- **pkg**: 基础设施工具包（日志、配置、加密、数据库适配、JWT 鉴权等）。

---

## 目录结构

```
.
├── cmd/                           服务入口目录
│   └── server/                    HTTP 服务入口
│       ├── main.go                Wire DI 启动入口，信号优雅关闭
│       └── wire/                  Wire 依赖注入与应用装配
│           ├── app.go             HTTP 应用装配（Gin 模式、中间件、路由与资源回收）
│           ├── wire.go            声明 Server 全栈分层依赖
│           └── wire_gen.go        Wire 自动生成代码
├── config/                        配置文件目录
│   ├── local.yml                  本地开发环境配置
│   └── release.yml                生产环境标准配置
├── docs/                          项目文档
│   └── sql/                       数据库建表脚本
│       └── basic.sql              数据库初始化 SQL
├── internal/                      内部业务核心逻辑
│   ├── handler/                   HTTP 处理器层
│   │   ├── demo.go                Demo 演示处理器
│   │   └── serverDI.go            Wire DI 注册全部 Handler
│   ├── global/                    全局常量与枚举
│   │   └── constants.go           上下文 Key、统一前缀与全局常量
│   ├── middleware/                HTTP 中间件
│   │   ├── auth.go                JWT 鉴权拦截器（支持强制/可选模式）
│   │   ├── cors.go                CORS 跨域安全配置
│   │   ├── metrics.go             Prometheus 性能指标收集
│   │   ├── ratelimit.go           单机 / Redis 分布式滑动窗口限流器
│   │   └── recovery.go            Panic 异常捕获与堆栈保护
│   ├── repository/                数据访问与持久化层
│   │   ├── cache/                 缓存层
│   │   │   ├── demo.go            二级缓存（Local go-cache + Redis）实现
│   │   │   ├── keys.go            缓存 Key 模板统一管理
│   │   │   └── local.go           线程安全本地内存缓存封装
│   │   ├── db/                    数据库访问层
│   │   │   ├── demo.go            Demo 自定义查询（分页/游标分页/事务更新）
│   │   │   ├── demo_gen.go        SqlGen 自动生成的基础 CRUD 样板代码
│   │   │   └── mysql.go           GORM 连接池/事务/分页/排序封装
│   │   └── serverDI.go            Wire DI 注册全部 Repository
│   ├── router/                    路由注册层
│   │   ├── router.go              全局通用路由（404/健康检查/Metrics）
│   │   ├── serverDI.go            Wire DI 注册全部路由
│   │   └── v0/demo.go             v0 版本 Demo RESTful 路由组
│   └── service/                   业务服务层
│       ├── svc/                   核心业务服务
│       │   ├── context.go         服务公共上下文（配置/DB/Redis）与公共分页契约（PageReq/PageResp）
│       │   └── demo.go            Demo 业务逻辑实现（CRUD + 缓存）
│       └── serverDI.go            Wire DI 注册 HTTP 服务层
├── pkg/                           通用公共工具库
│   ├── encrypt/                   安全加解密套件（AES/RSA/MD5/Bcrypt）
│   ├── token/                     JWT 认证中心（双 Token 轮换/单端互斥/防重放）
│   ├── utils/                     常用工具函数（Snowflake/时间/字符串/网络/协程池）
│   ├── validator/                 参数校验器与翻译器
│   ├── xconfig/                   配置动态加载器（Viper 驱动）
│   ├── xdb/                       数据库集成与链路追踪适配器（智能穿透调用栈）
│   ├── xerror/                    结构化业务错误码与错误模型
│   ├── xhttp/                     统一 HTTP JSON 响应封装（标准嵌套格式/泛型支持）
│   ├── xlog/                      高性能结构化日志（Zap + OpenTelemetry 追踪）
│   ├── xredis/                    Redis 连接池与操作封装（Cluster 友好）
│   └── xserver/                   服务抽象与生命周期优雅退出（Closer）
└── README.md                      项目说明文档
```

---

## 环境要求

- **Go**: `1.25.11` 或更高版本
- **Git**
- **Wire**: `go install github.com/google/wire/cmd/wire@latest`

---

## 常用开发命令

### 1. 启动服务

```bash
kun run
```

### 2. 编译依赖注入 (Wire)

修改了任何服务依赖、构造函数或 DI 注册文件后，执行编译生成 `wire_gen.go`：

```bash
kun wire
```

### 3. 生成业务组件代码 (`kun gen`)

```bash
# 生成路由层代码
kun gen rt user

# 生成处理器层代码
kun gen hdl user

# 生成服务层代码
kun gen svc user

# 生成缓存层代码
kun gen cache user

# 一键生成 Handler + Service
kun gen hs user

# 一键生成 Router + Handler + Service
kun gen crud user

# 数据库逆向代码生成（自动生成 Model 与 Repository 样板代码）
kun gen db "root:123456@tcp(127.0.0.1:3306)/dbname" "*"
```

---

## 配置中心与热更新操作手册

项目内置双模式配置驱动系统，支持本地 YAML 与远程 etcd 隔离运行，并对关键基础设施组件与业务配置提供了零停机热更新支持。

### 1. 运行模式设置 (`config/local.yml` 或 `config/release.yml`)

在配置文件中通过 `remoteConfig` 参数切换工作模式，字段格式完全遵循 `config/local.yml`：

```yaml
project: "basic"
env: "debug"
version: "0.0.1"

# 是否启用远程配置中心:
#   true  = 纯远程模式: 仅从本地读取 etcdConfig 连接信息，所有业务配置由 etcd 驱动并监听热更新，不受本地修改影响
#   false = 纯本地模式: 完全由本地 YAML 配置驱动，修改本地文件即触发热更新，不连接 etcd
remoteConfig: false

# 远程配置中心引导配置 (仅当 remoteConfig: true 时生效)
etcdConfig:
  host:
    - "127.0.0.1:2379"
  username: ""
  password: ""

# ──────────────── 常见热更新配置节点 (本地/远程修改均实时生效) ────────────────
token:
  secret: "123456ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  refreshSecret: "abcdefghijklmnopqrstuvwxyz123456"
  csrfKey: "abcdefghijklmnopqrstuvwxyz123456"
  expire: 3600        # 过期时间(秒)
  refresh: 604800     # 刷新时间(秒)
  maxRefresh: 2592000 # 绝对最大有效期(秒)
  gracePeriod: 30     # 轮换宽限期(秒)
  queryKey: "Authorization"
  multiLogin: false

log:
  level: "debug"   # 日志级别: debug, info, warn, error
  filePath: ""     # 落盘文件路径, 如: "./logs/app.log", 为空则不写文件
  stdout: true     # 是否输出到控制台
  kafkaTopic: ""   # Kafka 推送 Topic, 为空则不推
  kafkaBrokers: [] # Kafka Broker 集群节点地址
```

### 2. 开箱即用的内置热更新组件

修改配置后（本地 YAML 保存 或 远程 etcd 提交），无需重启服务即可立即生效：
* **结构化日志 (`xlog`)**：全参数支持热更新。
  * `level`（日志等级）：纯原子指针切换，零分配、纳秒级生效。
  * `filePath`、`stdout`、`kafkaTopic`、`kafkaBrokers`（输出拓扑）：动态重建输出 Core，平滑替换全局 Logger，后台延迟 2 秒安全释放旧文件/Kafka 句柄，无掉日志风险。
* **JWT 鉴权 (`token`)**：密钥轮换、宽限期（`gracePeriod`）、双 Token 存活时长（`expire`/`refresh`）等参数热重载立即生效。

---

### 3. 业务代码如何获取与响应热更新配置

#### 方式一：随用随取最新快照（推荐普通业务使用）
`conf.Get()` 返回当前不可变的配置快照指针。底层由 `atomic.Pointer` 托管，**零锁、零分配、绝对线程安全**。
```go
type OrderService struct {
    conf *xconfig.Conf // 由 Wire 编译期自动注入
}

func (s *OrderService) CreateOrder(ctx context.Context, req *CreateReq) error {
    // 每次通过 conf.Get() 获取当前最新配置快照
    cfg := s.conf.Get()
    
    // 直接读取最新参数，如超时、限流阈值、业务开关等
    writeTimeout := cfg.Server.WriteTimeout
    _ = writeTimeout
    return nil
}
```

#### 方式二：注册变更回调（组件内部维护状态时使用）
若自定义业务组件维护了私有状态、缓存或者需在参数变更时执行计算，可通过 `conf.OnUpdate` 注册监听：
```go
type RateLimiter struct {
    limit int
    mu    sync.RWMutex
}

func NewRateLimiter(conf *xconfig.Conf) *RateLimiter {
    limiter := &RateLimiter{
        limit: 100, // 初始值
    }

    // 注册热更新监听钩子
    conf.OnUpdate(func(newConf *xconfig.Conf) {
        limiter.mu.Lock()
        defer limiter.mu.Unlock()

        // 当监听到配置刷新时更新内部参数
        // limiter.limit = newConf.YourBiz.Limit
        xlog.Info("限流阈值已热更新")
    })

    return limiter
}
```

#### 方式三：远程 etcd 独立业务配置细粒度监听
在 `remoteConfig: true` 下，若业务存在按 `group` 和 `dataId` 拆分的特定配置：
```go
// 1. 一次性反序列化指定远端配置到结构体
var payCfg MyPaymentConfig
if err := conf.Scan("pay", "alipay", &payCfg); err != nil {
    xlog.Error("加载支付配置失败", xlog.KVStr("err", err.Error()))
}

// 2. 单独监听该项配置的动态变更
if w := conf.Get().Watcher; w != nil {
    w.Watch("pay", "alipay", func(cv *xetcd.ConfigValue) {
        var updated MyPaymentConfig
        if err := yaml.Unmarshal([]byte(cv.Content), &updated); err == nil {
            xlog.Info("支付宝业务配置已动态更新")
        }
    })
}
```

> **注意（长连接组件提示）**：
> 像 MySQL/Redis 这类底层维护长连接池的组件，若需要动态调整 DSN 或地址，应在 `conf.OnUpdate` 回调中比对连接串变动，新建连接池并原子切换 Client 指针，最后异步释放旧连接池。

---

## 核心设计与开发约定

1. **依赖注入**: 模块间均通过 `Wire` 进行强类型编译期注入，避免手动管理单例与全局全局变量。
2. **配置管理**: 使用 `Viper` 动态加载 `config/` 下的配置文件，支持多环境无缝切换。
3. **结构化日志**: 业务模块与数据访问层 100% 仅依赖 `pkg/xlog` 包；支持 `WithCallerSkip` 动态跳层，数据库日志自动穿透
   `_gen.go` 样板代码，直达业务服务源码行号。
4. **高安全认证**: 内置双 Token 体系，支持 CSPRNG 密码学安全 JTI、双密钥强隔离、时钟漂移容错与 Redis Cluster 单槽原子操作。
5. **统一错误模型**: 统一使用 `xerror` 包管理错误码，返回结构化 JSON 错误响应。
6. **缓存 Key 集中化**: 所有缓存 Key 集中在 `repository/cache/keys.go` 中统一定义，避免散落硬编码。
7. **统一 HTTP 响应与分页契约规范**: 响应外层全局严格统一为 `{ code, message, data }`。单体数据通过 `xhttp.Data` 承载，分页列表通过 `xhttp.List` 统一封装为标准嵌套结构 `data: { page, pageSize, total, items }`，杜绝平铺结构造成前端拦截器混淆。请求分页入参统一内嵌 `svc.PageReq`，支持 `form:"...,default=..."` 自动注入与 `ToDbSearchPage()` 默认值兜底，游标 `LastId` 规范为 `string` 类型，彻底规避雪花算法大整数在前端 JavaScript 中的精度截断问题。
