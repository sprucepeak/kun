# advanced — 高级企业级工程布局

## 技术栈

| 类别       | 库 / 组件                                                           | 说明                                      |
|:-----------|:--------------------------------------------------------------------|:------------------------------------------|
| Web 框架   | [Gin](https://github.com/gin-gonic/gin)                             | 高性能 HTTP 路由、上下文与中间件          |
| ORM 引擎   | [Gorm](https://github.com/go-gorm/gorm)                             | 数据库操作、连接池、多驱动与事务管理      |
| 依赖注入   | [Wire](https://github.com/google/wire)                              | Google 编译期依赖注入（Compile-time DI）  |
| 配置管理   | [Viper](https://github.com/spf13/viper)                             | 多环境 YAML 配置动态加载与热重载          |
| 结构化日志 | [Zap](https://github.com/uber-go/zap)                               | 高性能结构化日志，支持动态跳层与业务穿透  |
| 链路追踪   | [OpenTelemetry](https://github.com/open-telemetry/opentelemetry-go) | 全链路分布式追踪（Jaeger / OTLP 导出）    |
| JWT 鉴权   | [Golang-jwt](https://github.com/golang-jwt/jwt)                     | HS384 双 Token 轮换、单端互斥、防重放熔断 |
| 缓存服务   | [Go-redis](https://github.com/redis/go-redis)                       | Redis 单机/集群客户端，单槽 Lua 原子操作  |
| 异步任务   | [Asynq](https://github.com/hibiken/asynq)                           | 基于 Redis 的分布式延迟队列与周期任务     |
| 消息队列   | [Kafka](https://github.com/IBM/sarama)                              | 高吞吐事件驱动架构，支持跨进程分布式追踪  |
| 定时任务   | [Cron](https://github.com/robfig/cron)                              | 精确到秒级的周期性 Cron 调度器            |
| 参数校验   | [Validator](https://github.com/go-playground/validator)             | 请求参数规则校验与多语言翻译              |
| 接口文档   | [Swaggo](https://github.com/swaggo/swag)                            | 代码声明式 Swagger API 接口文档生成       |

---

## 分层架构说明

项目采用工程化分层解耦架构，通过 Google `Wire` 在编译期完成依赖组装：

```
┌─────────────────────────────────────────────────────────┐
│                    router / handler                     │  ── 路由分发 & 控制层（参数校验、协议转换）
├─────────────────────────────────────────────────────────┤
│                      service / svc                      │  ── 核心业务逻辑编排层（事务管理、规则运算）
├─────────────────────────────────────────────────────────┤
│           repository/db   |   repository/cache          │  ── 数据持久化访问层（DB CRUD + 二级缓存）
├─────────────────────────────────────────────────────────┤
│                     internal / event                    │  ── 事件驱动层（Kafka 事件发布/订阅 + 异步队列）
├─────────────────────────────────────────────────────────┤
│                         pkg / x*                        │  ── 跨项目基础设施与公共组件库
└─────────────────────────────────────────────────────────┘
```

- **handler**: 负责接收 HTTP 请求，执行入参校验（Validator），调用 Service 编排逻辑，返回统一 JSON 响应。
- **service**: 承载核心业务逻辑，负责事务控制、领域计算与缓存策略，调用 Repository。
- **repository**: 屏蔽底层数据库与缓存的具体实现细节，提供纯粹的数据持久化接口。
- **event**: 统一抽象事件发布者与订阅者，兼容 Kafka 与 Asynq 多种消息调度后端。
- **pkg**: 基础设施工具包（日志、配置、加密、数据库适配、JWT 鉴权等）。

---

## 目录结构

```
.
├── cmd/                           项目入口目录
│   ├── broker/                    异步调度服务器入口（消息消费、延时任务、定时任务）
│   │   ├── main.go                Wire DI 启动入口，信号优雅关闭
│   │   └── wire/                  Wire 依赖注入与装配
│   │       ├── app.go             Broker 应用装配（健康探针与消费者启动）
│   │       ├── wire.go            声明 Broker 全链路依赖
│   │       └── wire_gen.go        Wire 自动生成代码
│   └── server/                    HTTP 服务入口
│       ├── main.go                Wire DI 启动入口，信号优雅关闭
│       └── wire/                  Wire 依赖注入与装配
│           ├── app.go             HTTP 应用装配（Gin 模式、中间件、路由与资源回收）
│           ├── wire.go            声明 Server 全栈分层依赖
│           └── wire_gen.go        Wire 自动生成代码
├── config/                        配置文件目录
│   ├── local.yml                  本地开发环境配置
│   └── release.yml                生产环境标准配置
├── deploy/                        部署编排与容器化
│   ├── .env.example               环境变量配置示例
│   ├── Dockerfile                 多阶段瘦身构建 Dockerfile
│   └── docker-compose.yml         本地中间件一键编排启动
├── docs/                          项目文档与资产
│   └── sql/                       数据库初始化与变更脚本
│       └── advanced.sql           全量数据库表结构与初始数据
├── swagger/                       Swagger API 静态文档
├── internal/                      内部业务核心逻辑
│   ├── handler/                   HTTP 处理器层
│   │   ├── demo/demo.go           Demo 演示处理器（CRUD、流式响应、导出、WebSocket）
│   │   └── serverDI.go            Wire DI 注册全部 Handler
│   ├── event/                     事件驱动抽象层
│   │   ├── publisher.go           消息发布器（Kafka 同步 + Asynq 异步/延迟）
│   │   ├── subscriber.go          订阅管理器（Kafka 消费者组 + Asynq Worker）
│   │   └── types.go               订阅任务结构定义
│   ├── global/                    全局常量与枚举
│   │   ├── constants.go           上下文 Key、统一前缀与全局常量
│   │   ├── event.go               事件类型、Topic 与消费组定义
│   │   └── pay.go                 业务状态与支付类型枚举
│   ├── middleware/                HTTP 中间件
│   │   ├── auth.go                JWT 鉴权拦截器（支持强制/可选/写入模式）
│   │   ├── cors.go                CORS 跨域安全配置
│   │   ├── csrf.go                CSRF 防跨站请求伪造保护
│   │   ├── metrics.go             Prometheus 性能指标收集
│   │   ├── ratelimit.go           单机 / Redis 分布式滑动窗口限流器
│   │   └── recovery.go            Panic 异常捕获与堆栈保护
│   ├── repository/                数据访问与持久化层
│   │   ├── cache/                 缓存层
│   │   │   ├── demo.go            二级缓存（Local go-cache + Redis）实现
│   │   │   ├── keys.go            缓存 Key 模板统一管理
│   │   │   └── local.go           线程安全本地内存缓存封装
│   │   ├── db/                    数据库访问层
│   │   │   ├── demo.go            Demo 自定义查询（分页/游标分页/事务更新）
│   │   │   ├── demo_gen.go        SqlGen 自动生成的基础 CRUD 样板代码
│   │   │   └── mysql.go           GORM 连接池/事务/分页/排序封装
│   │   └── serverDI.go            Wire DI 注册全部 Repository
│   ├── router/                    路由注册层
│   │   ├── router.go              全局通用路由（404/健康检查/Swagger/Metrics）
│   │   ├── serverDI.go            Wire DI 注册全部路由
│   │   └── v0/demo.go             v0 版本 Demo RESTful 路由组
│   └── service/                   业务服务层
│       ├── svc/                   核心业务服务
│       │   ├── context.go         服务公共上下文（配置/DB/Redis/PubSub/Scheduler）与公共分页契约（PageReq/PageResp）
│       │   ├── demo.go            Demo 业务逻辑实现（登录/鉴权/缓存/事务/流式）
│       │   └── broker.go          事件消费处理器（Kafka 消费 + 异步任务调度）
│       ├── brokerDI.go            Wire DI 注册 Broker 消费任务
│       └── serverDI.go            Wire DI 注册 HTTP 服务层
├── pkg/                           通用公共工具库
│   ├── asynq/                     Asynq 异步/延迟/定时任务队列驱动
│   ├── encrypt/                   安全加解密套件（AES/RSA/MD5/Bcrypt）
│   ├── kafka/                     Kafka 客户端封装（发布/消费组/链路追踪）
│   ├── token/                     JWT 认证中心（双 Token 轮换/单端互斥/防重放）
│   ├── utils/                     常用工具函数（Snowflake/时间/字符串/网络/协程池）
│   ├── validator/                 参数校验器与翻译器
│   ├── xconfig/                   配置动态加载器（Viper 驱动）
│   ├── xdb/                       数据库集成与链路追踪适配器（智能穿透调用栈）
│   ├── xerror/                    结构化业务错误码与错误模型
│   ├── xhttp/                     统一 HTTP JSON 响应封装（标准嵌套格式/泛型支持）
│   ├── xlog/                      高性能结构化日志（Zap + OpenTelemetry 追踪）
│   ├── xredis/                    Redis 连接池与操作封装（Cluster 友好）
│   └── xserver/                   服务抽象与生命周期优雅退出（Closer）
├── test/                          单元测试与基准测试
├── Makefile                       编译与运维快捷脚本
└── README.md                      项目说明文档
```

---

## 环境要求

- **Go**: `1.25.11` 或更高版本
- **Git**
- **Wire**: `go install github.com/google/wire/cmd/wire@latest`
- **Docker & Docker-Compose** (可选，用于本地一键拉起 MySQL、Redis、Kafka)

---

## 常用开发命令

### 1. 启动服务

```bash
# 启动 HTTP API 服务
kun run

# 启动 Broker 调度与消费服务
kun run ./cmd/broker
```

### 2. 编译依赖注入 (Wire)

修改了任何服务依赖、构造函数或 DI 注册文件后，执行编译生成 `wire_gen.go`：

```bash
kun wire
```

### 3. 生成业务组件代码 (`kun gen`)

```bash
# 生成路由层代码
kun gen rt user

# 生成处理器层代码
kun gen hdl user

# 生成服务层代码
kun gen svc user

# 生成缓存层代码
kun gen cache user

# 一键生成 Handler + Service
kun gen hs user

# 一键生成 Router + Handler + Service
kun gen crud user

# 数据库逆向代码生成（自动生成 Model 与 Repository 样板代码）
kun gen db "root:123456@tcp(127.0.0.1:3306)/dbname" "*"
```

---

## 异步任务与事件驱动开发指南

`advanced` 布局内置了多后端事件驱动体系，统一由 `cmd/broker` 作为调度中心：

### 1. 消息发布 (Publisher)

在 Service 层注入 `*event.Pub`，即可发起多模式消息投递：

```go
// 模式 A：发布 Kafka 业务消息（支持按业务 Key 分区）
err := s.pub.Kafka(ctx, enum.TopicPayEvent, "order_key_1001", payloadBytes)

// 模式 B：投递 Asynq 立即异步任务
entryID, err := s.pub.AsynqSync(ctx, "default", "task:demo", payloadBytes)

// 模式 C：投递 Asynq 延迟任务 (如 30 分钟未支付自动超时关闭订单)
entryID, err := s.pub.AsynqDelay(ctx, "default", "task:order:timeout", payloadBytes, 30*time.Minute)
```

### 2. 消费者编写与任务处理

在 `internal/service/svc/broker.go` 中编写具体的消费执行逻辑：

```go
// Kafka 事件处理器
func (b *brokerSvc) SubPayRecharge(ctx context.Context, key, value string) error {
    xlog.Info(ctx, "收到充值支付事件", xlog.KVStr("key", key))
    // 执行业务逻辑...
    return nil
}

// Asynq 异步任务处理器
func (b *brokerSvc) SubAqPay(ctx context.Context, task *asynq.Task) error {
    xlog.Info(ctx, "处理异步调度任务", xlog.KVStr("type", task.Type()))
    // 解析 payload 并处理...
    return nil
}
```

并在 `internal/service/brokerDI.go` 中将处理器挂载至 `WireBrokerSet`，即可随 `broker` 进程启动自动并行消费。

### 3. 周期性 Cron 定时任务配置

利用内置精确到秒级的 Cron 调度引擎，在订阅管理中轻松配置周期性作业：

```go
// 周期性任务示例：每 2 秒执行一次清理或巡检
spec := "*/2 * * * * *"
_, err := cronRunner.AddFunc(spec, func() {
    ctx := context.Background()
    xlog.Info(ctx, "执行定时巡检任务")
    // 执行定时业务...
})
```

---

## 核心设计与开发约定

1. **编译期依赖注入**: 模块间均通过 `Wire` 进行强类型静态编排，严禁手写繁杂的单例与全局全局变量传参。
2. **零基础包依赖日志规范**: 业务模块与数据访问层 100% 仅依赖 `pkg/xlog` 包；支持 `WithCallerSkip` 动态跳层，数据库日志自动穿透
   `_gen.go` 样板代码，直达业务服务源码行号。
3. **高安全双 Token 规范**: 全量鉴权遵循 `pkg/token/README.md` 规范，支持密码学安全 JTI、双密钥强物理隔离、Redis
   单槽原子批量校验与凭据泄露自动熔断。
4. **统一错误码模型**: 错误处理严格遵循 `xerror` 约定，禁止裸返回无类型错误或向前端暴露敏感底层堆栈。
5. **缓存集中管理**: 所有 Redis 键与本地缓存 Key 严格集中在 `repository/cache/keys.go` 中定义模板，杜绝硬编码。
6. **统一 HTTP 响应与分页契约规范**: 响应外层全局严格统一为 `{ code, message, data }`。单体数据通过 `xhttp.Data` 承载，分页列表通过 `xhttp.List` 统一封装为标准嵌套结构 `data: { page, pageSize, total, items }`，杜绝平铺结构造成前端拦截器混淆。请求分页入参统一内嵌 `svc.PageReq`，支持 `form:"...,default=..."` 自动注入与 `ToDbSearchPage()` 默认值兜底，游标 `LastId` 规范为 `string` 类型，彻底规避雪花算法大整数在前端 JavaScript 中的精度截断问题。
