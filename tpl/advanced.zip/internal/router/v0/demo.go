/**
 * @Author: spruce
 * @Date: 2024-03-28 11:11
 * @Desc: v0 路由
 */

package v0

import (
	"advanced/internal/global"
	"advanced/internal/handler"
	"advanced/internal/middleware"
	"advanced/pkg/token"
	"time"

	"github.com/gin-gonic/gin"
)

func Demo(e *gin.Engine, jwt *token.Jwt, ctx *handler.Ctx) {
	// api Demo路由
	apiGroup := e.Group(global.RouterPrefixApi)
	{

		apiGroup.GET("/demo/:id", ctx.DemoHandler.Detail)
		apiGroup.GET("/demo/list", ctx.DemoHandler.List)
		apiGroup.POST("/demo/create", ctx.DemoHandler.Create)
		apiGroup.POST("/demo/update", ctx.DemoHandler.Update)
		apiGroup.POST("/demo/delete", ctx.DemoHandler.Delete)
		apiGroup.POST("/demo/softdelete", ctx.DemoHandler.SoftDelete)

		apiGroup.GET("/demo/validate", ctx.DemoHandler.Validate)

		apiGroup.GET("/demo/export", ctx.DemoHandler.Export)

		apiGroup.GET("/demo/excel", ctx.DemoHandler.Excel)

		apiGroup.GET("/demo/sse", ctx.DemoHandler.SSE)

		apiGroup.POST("/demo/send-msg", ctx.DemoHandler.SendMsg)
		apiGroup.POST("/demo/add-msg", ctx.DemoHandler.AddMsg)
		apiGroup.POST("/demo/del-msg", ctx.DemoHandler.DelMsg)

		apiGroup.GET("/demo/csrf", middleware.CSRF([]byte(jwt.CSRFKey)), ctx.DemoHandler.GetCsrf)
		apiGroup.POST("/demo/submit-csrf", middleware.CSRF([]byte(jwt.CSRFKey)), ctx.DemoHandler.SubmitCsrf)

		// WebSocket
		apiGroup.GET("/demo/ws", ctx.DemoHandler.WS)

		// 登录与会话管理(公开端点) — 登录限流: 每IP每分钟最多5次,超限封禁5分钟
		apiGroup.POST("/demo/login", middleware.RateLimiter(5, time.Minute, 5*time.Minute), ctx.DemoHandler.Login)
		apiGroup.POST("/demo/refresh", ctx.DemoHandler.Refresh)
		apiGroup.POST("/demo/logout", ctx.DemoHandler.Logout) // 登出公开放行，保证无论何种凭据状态均 100% 成功登出，绝不报 2002 错误

		// MCP Demo 端点 (Model Context Protocol)
		apiGroup.POST("/demo/mcp", ctx.DemoHandler.MCP)
		apiGroup.GET("/demo/mcp", ctx.DemoHandler.MCP)

		// 需授权路由
		authGroup := apiGroup.Group("/demo", middleware.Auth(jwt))
		{
			authGroup.GET("/info", ctx.DemoHandler.Info)
			authGroup.POST("/ws-ticket", ctx.DemoHandler.WSTicket)

			// 管理端路由: 封号、解封、强制全端下线
			authGroup.POST("/ban", ctx.DemoHandler.AdminBan)
			authGroup.POST("/unban", ctx.DemoHandler.AdminUnban)
			authGroup.POST("/kick-all", ctx.DemoHandler.AdminKickAll)
		}
	}

	// 根路径直连 /mcp (兼容外部标准 MCP 客户端直接挂载根路径)
	e.POST("/mcp", ctx.DemoHandler.MCP)
	e.GET("/mcp", ctx.DemoHandler.MCP)
}
