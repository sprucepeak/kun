package demo

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"advanced/internal/global"
	"advanced/internal/service/svc"
	"advanced/pkg/xerror"
	"advanced/pkg/xhttp"
	"advanced/pkg/xlog"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/csrf"
	"github.com/gorilla/websocket"
)

type (
	DemoHandler struct {
		DemoSvc svc.DemoSvc
	}
)

// @Summary Detail
// @Description demo详情
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/:id [get]
func (d *DemoHandler) Detail(ctx *gin.Context) {
	// 获取参数两种方式
	// 方式1:
	// idStr := ctx.Param("id")
	// if idStr == "" {
	// 	xhttp.BusCode(ctx, xerror.ParamError, errors.New("id不能为空"))
	// 	return
	// }
	// id, _ := strconv.ParseInt(idStr, 10, 64)

	//  方式2(推荐可以方便验证参数):
	type detailId struct {
		Id int64 `uri:"id" binding:"required,min=1,max=100"` // 或者 binding:"required,gte=1,lte=130"
	}
	var urlId detailId
	if err := ctx.ShouldBindUri(&urlId); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	id := urlId.Id

	info, err := d.DemoSvc.Detail(ctx.Request.Context(), id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "Get Demo Detail 成功", info)
}

// @Summary List
// @Description 根据条件查询demo列表
// @Tags api
// @Accept json
// @Produce json
// @Success 200 {string} string "{"code":0,"message":"Get Demo List 成功","data":{"page":1,"pageSize":20,"total":100,"items":[{"id":100,"name":"我是demo名称"}]}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/list [get]
func (d *DemoHandler) List(ctx *gin.Context) {
	req := &svc.DemoListReq{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	// id= (空字符串) 时 gin 会把 *int64 绑定成指向 0 的非空指针,
	// 导致 WHERE id = 0 查不到数据。这里把 0 规整为 nil,表示不按 id 过滤。
	if req.Id != nil && *req.Id == 0 {
		req.Id = nil
	}

	result, total, err := d.DemoSvc.FindList(ctx.Request.Context(), req)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.List(ctx, "Get Demo List 成功", req.Page, req.PageSize, total, result)
}

// @Summary Create
// @Description 写一个demo
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/create [post]
func (d *DemoHandler) Create(ctx *gin.Context) {
	req := &svc.DemoCreateReq{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	err := d.DemoSvc.Create(ctx.Request.Context(), req)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "Create Demo 成功")
}

// @Summary Update
// @Description 更新一个demo,有事务
// @Tags api
// @Accept json
// @Produce json
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/update [post]
func (d *DemoHandler) Update(ctx *gin.Context) {
	req := &svc.DemoUpdateReq{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	err := d.DemoSvc.Update(ctx.Request.Context(), req)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "Update Demo 成功")
}

// @Summary Delete
// @Description 删除一个demo
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /demo/delete [post]
func (d *DemoHandler) Delete(ctx *gin.Context) {
	req := &struct {
		Id int64 `form:"id" json:"id" binding:"required,gte=1,lte=130"`
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	err := d.DemoSvc.Delete(ctx.Request.Context(), req.Id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "Delete Demo 成功")
}

// @Summary SoftDelete
// @Description 逻辑删除一个demo
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /demo/softdelete [post]
func (d *DemoHandler) SoftDelete(ctx *gin.Context) {
	req := &struct {
		Id int64 `form:"id" json:"id" binding:"required,gte=1,lte=130"`
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	err := d.DemoSvc.SoftDelete(ctx.Request.Context(), req.Id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "SoftDelete Demo 成功")
}

// @Summary Validate
// @Description 示例：验证日期范围（min >= 今天，max <= 今天）
// @Tags api
// @Accept json
// @Produce json
// @Param min formData string true "最小日期(格式: YYYY-MM-DD)"
// @Param max formData string true "最大日期(格式: YYYY-MM-DD)"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /demo/validate [get]
func (d *DemoHandler) Validate(ctx *gin.Context) {
	type minMaxStruct struct {
		Min string `form:"min" json:"min" binding:"required,afterNow"`  // 必须 >= 今天 (格式: YYYY-MM-DD)
		Max string `form:"max" json:"max" binding:"required,beforeNow"` // 必须 <= 今天 (格式: YYYY-MM-DD)
	}
	var minMax minMaxStruct
	if err := ctx.ShouldBind(&minMax); err != nil {
		// 当校验失败时，BusCode 会调用 validator.Message(err) 自动翻译为中文错误提示
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	xhttp.Data(ctx, "参数校验通过", minMax)
}

// @Summary Login
// @Description demo登录(账号:name,密码:password),返回双token(同时通过HttpOnly Cookie下发refreshToken防XSS)
// @Tags api
// @Accept json
// @Produce json
// @Param name formData string true "账号(demo名称)"
// @Param password formData string true "密码"
// @Success 200 {string} string "{"code":0,"message":"Login 成功","data":{"accessToken":"","refreshToken":""}}"
// @Router /api/auth/login [post]
func (d *DemoHandler) Login(ctx *gin.Context) {
	req := &struct {
		Name     string `form:"name" json:"name" binding:"required"`         // 账号(demo名称)
		Password string `form:"password" json:"password" binding:"required"` // 密码(123456)
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	tokenInfo, err := d.DemoSvc.Login(ctx.Request.Context(), req.Name, req.Password)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	// 为 Web 端写入 HttpOnly Cookie, 彻底防御 XSS 盗取长效 refreshToken
	ctx.SetSameSite(http.SameSiteStrictMode)
	if maxAge := int(tokenInfo.RefreshExpireAt - time.Now().Unix()); maxAge > 0 {
		ctx.SetCookie("refreshToken", tokenInfo.RefreshToken, maxAge, "/api", "", ctx.Request.TLS != nil, true)
	}
	xhttp.Data(ctx, "Login 成功", tokenInfo)
}

// @Summary Refresh
// @Description 刷新双token(兼容请求参数或HttpOnly Cookie携带refreshToken)
// @Tags api
// @Accept json
// @Produce json
// @Param accessToken formData string false "访问token(可选,空则从Header Authorization获取)"
// @Param refreshToken formData string false "刷新token(可选,空则从Cookie获取)"
// @Router /api/auth/refresh [post]
func (d *DemoHandler) Refresh(ctx *gin.Context) {
	req := &struct {
		AccessToken  string `form:"accessToken" json:"accessToken"`
		RefreshToken string `form:"refreshToken" json:"refreshToken"`
	}{}
	_ = ctx.ShouldBind(req)
	// 兼容从 HttpOnly Cookie 获取 refreshToken
	if req.RefreshToken == "" {
		if cookie, err := ctx.Cookie("refreshToken"); err == nil {
			req.RefreshToken = cookie
		}
	}
	// 兼容从 Header Authorization 获取 accessToken
	if req.AccessToken == "" {
		req.AccessToken = ctx.GetHeader("Authorization")
	}
	if req.AccessToken == "" || req.RefreshToken == "" {
		xhttp.BusCode(ctx, xerror.ParamError, errors.New("accessToken 和 refreshToken 不能为空(可传参数或Header/Cookie)"))
		return
	}
	tokenInfo, err := d.DemoSvc.RefreshToken(ctx.Request.Context(), req.AccessToken, req.RefreshToken)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	// 同步更新 HttpOnly Cookie
	ctx.SetSameSite(http.SameSiteStrictMode)
	if maxAge := int(tokenInfo.RefreshExpireAt - time.Now().Unix()); maxAge > 0 {
		ctx.SetCookie("refreshToken", tokenInfo.RefreshToken, maxAge, "/api", "", ctx.Request.TLS != nil, true)
	}
	xhttp.Data(ctx, "Refresh 成功", tokenInfo)
}

// @Summary Info
// @Description 当前登录信息(需授权),从token中解析userid和roleid
// @Tags api
// @Produce json
// @Router /api/auth/info [get]
func (d *DemoHandler) Info(ctx *gin.Context) {
	userId, userIdExists := ctx.Get(global.CtxAuthUserId)
	roleId, roleIdExists := ctx.Get(global.CtxAuthRoleId)
	if !userIdExists || !roleIdExists {
		xhttp.BusCode(ctx, xerror.Unauthorized, fmt.Errorf("用户未登录或认证信息缺失"))
		return
	}
	xhttp.Data(ctx, "Get Info 成功", gin.H{
		"userId": userId,
		"roleId": roleId,
	})
}

// @Summary Logout
// @Description 登出,废弃当前 accessToken 及其对应的 refreshToken 会话(无需传参,自动从 Header/Cookie 提取 token, 保证 100% 成功)
// @Tags api
// @Accept json
// @Produce json
// @Router /api/demo/logout [post]
func (d *DemoHandler) Logout(ctx *gin.Context) {
	tokenStr := ctx.GetString(global.CtxAuthToken)
	if tokenStr == "" {
		tokenStr = ctx.GetHeader("Authorization")
	}
	if tokenStr == "" {
		if cookie, _ := ctx.Cookie("Authorization"); cookie != "" {
			tokenStr = cookie
		}
	}
	_ = d.DemoSvc.Logout(ctx.Request.Context(), tokenStr)
	// 清理客户端 HttpOnly Cookie(若有)
	ctx.SetSameSite(http.SameSiteStrictMode)
	ctx.SetCookie("refreshToken", "", -1, "/api", "", ctx.Request.TLS != nil, true)
	xhttp.Success(ctx, "Logout 成功")
}

// AdminBan 管理员封禁用户
func (d *DemoHandler) AdminBan(ctx *gin.Context) {
	req := &struct {
		UserId   int64  `json:"userId" binding:"required,min=1"`
		Duration int64  `json:"duration"` // 封禁时长(秒)，<=0 表示永久
		Reason   string `json:"reason"`
	}{}
	if err := ctx.ShouldBindJSON(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	var dDuration time.Duration
	if req.Duration > 0 {
		dDuration = time.Duration(req.Duration) * time.Second
	}
	if err := d.DemoSvc.BanUser(ctx.Request.Context(), req.UserId, dDuration, req.Reason); err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "封禁用户成功")
}

// AdminUnban 管理员解封用户
func (d *DemoHandler) AdminUnban(ctx *gin.Context) {
	req := &struct {
		UserId int64 `json:"userId" binding:"required,min=1"`
	}{}
	if err := ctx.ShouldBindJSON(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	if err := d.DemoSvc.UnbanUser(ctx.Request.Context(), req.UserId); err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "解封用户成功")
}

// AdminKickAll 管理员强制用户所有设备下线
func (d *DemoHandler) AdminKickAll(ctx *gin.Context) {
	req := &struct {
		UserId int64 `json:"userId" binding:"required,min=1"`
	}{}
	if err := ctx.ShouldBindJSON(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	if err := d.DemoSvc.KickAllDevices(ctx.Request.Context(), req.UserId); err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "强制所有设备下线成功")
}

func (d *DemoHandler) SendMsg(ctx *gin.Context) {
	err := d.DemoSvc.SendMsg(ctx.Request.Context())
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "SenMsg 成功")
}

func (d *DemoHandler) AddMsg(ctx *gin.Context) {
	err := d.DemoSvc.AddMsg(ctx.Request.Context())
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "AddMsg 成功")
}

func (d *DemoHandler) DelMsg(ctx *gin.Context) {
	err := d.DemoSvc.DelMsg(ctx.Request.Context())
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Success(ctx, "DelMsg 成功")
}

func (d *DemoHandler) GetCsrf(ctx *gin.Context) {
	csrfToken := csrf.Token(ctx.Request)
	xhttp.Data(ctx, "GetCsrf 成功", csrfToken)
}

func (d *DemoHandler) SubmitCsrf(ctx *gin.Context) {
	xhttp.Data(ctx, "SubmitCsrf 成功", "")
}

// @Summary Export
// @Description http+mysql 全链路流式导出 demo
// @Tags api
// @Accept json
// @Produce json
// @Router /api/demo/export [get]
func (d *DemoHandler) Export(ctx *gin.Context) {
	// 1. 清除当前请求的 WriteDeadline,支持长连接流式传输。
	// ResponseController.SetWriteDeadline(零值)会覆盖 http.Server.WriteTimeout(120s)
	rc := http.NewResponseController(ctx.Writer)
	if err := rc.SetWriteDeadline(time.Time{}); err != nil {
		xlog.Warn(ctx, "clear write deadline failed", xlog.KVErr(err))
	}

	// 2. 设置流式响应头
	ctx.Header("Content-Type", "application/x-ndjson; charset=utf-8")
	ctx.Header("X-Accel-Buffering", "no") // 禁止 nginx buffer
	ctx.Header("Cache-Control", "no-cache")
	ctx.Header("Connection", "keep-alive")
	ctx.Status(http.StatusOK)

	// 3. 获取 Flusher
	flusher, ok := ctx.Writer.(http.Flusher)
	if !ok {
		// 若不支持 flusher，则回退或直接报错
		return
	}
	flusher.Flush()

	// 4. 开始流式导出
	var count int64
	err := d.DemoSvc.ExportStream(ctx.Request.Context(), func(item *svc.DemoResp) error {
		line, err := json.Marshal(item)
		if err != nil {
			return err
		}
		_, err = ctx.Writer.Write(append(line, '\n'))
		if err != nil {
			return err
		}
		count++
		flusher.Flush()
		return nil
	})

	// 5. 哨兵行协议写入
	var sentinel []byte
	if err != nil {
		sentinel, _ = json.Marshal(map[string]any{
			"_end":     "err",
			"exported": count,
			"err":      err.Error(),
		})
	} else {
		sentinel, _ = json.Marshal(map[string]any{
			"_end":     "ok",
			"exported": count,
		})
	}
	_, _ = ctx.Writer.Write(append(sentinel, '\n'))
	flusher.Flush()
}

// @Summary Excel
// @Description http+mysql 全链路流式导出 Excel，浏览器直接下载
// @Tags api
// @Accept json
// @Produce application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
// @Router /api/demo/excel [get]
func (d *DemoHandler) Excel(ctx *gin.Context) {
	// 1. 清除当前请求的 WriteDeadline,支持长连接流式传输。
	// ResponseController.SetWriteDeadline(零值)会覆盖 http.Server.WriteTimeout(120s)
	rc := http.NewResponseController(ctx.Writer)
	if err := rc.SetWriteDeadline(time.Time{}); err != nil {
		xlog.Warn(ctx, "clear write deadline failed", xlog.KVErr(err))
	}

	// 2. 设置 Excel 下载响应头
	// RFC 5987/6266 规定 filename*=UTF-8'' 之后的文件名必须经过 percent-encoding
	fileName := fmt.Sprintf("demo_export_%s.xlsx", time.Now().Format("20060102150405"))
	ctx.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	ctx.Header("Content-Disposition", fmt.Sprintf("attachment; filename*=UTF-8''%s", url.PathEscape(fileName)))
	ctx.Header("Content-Transfer-Encoding", "binary")
	ctx.Header("X-Accel-Buffering", "no") // 禁止 nginx buffer
	ctx.Header("Cache-Control", "no-cache")
	ctx.Header("Connection", "keep-alive")
	ctx.Status(http.StatusOK)

	// 3. 获取 Flusher
	flusher, ok := ctx.Writer.(http.Flusher)
	if !ok {
		// 若不支持 flusher，则回退或直接报错
		xhttp.BusCode(ctx, xerror.BusinessError, fmt.Errorf("streaming not supported"))
		return
	}
	flusher.Flush()

	// 4. 调用 Svc 层进行 Excel 流式写入
	err := d.DemoSvc.ExportExcel(ctx.Request.Context(), ctx.Writer)
	if err != nil {
		xlog.Errorf(ctx.Request.Context(), "ExportExcel stream write error: %v", err)
		return
	}
	flusher.Flush()
}

// @Summary SSE
// @Description Server-Sent Events demo
// @Tags api
// @Produce text/event-stream
// @Router /api/demo/sse [get]
func (d *DemoHandler) SSE(ctx *gin.Context) {
	// 1. 清除 WriteDeadline,支持长连接流式传输(否则会被 http.Server.WriteTimeout 切断)
	rc := http.NewResponseController(ctx.Writer)
	if err := rc.SetWriteDeadline(time.Time{}); err != nil {
		// 忽略或记录日志
		xlog.Warn(ctx, "clear write deadline failed", xlog.KVErr(err))
	}

	// 2. 设置响应头
	ctx.Header("Content-Type", "text/event-stream")
	ctx.Header("Cache-Control", "no-cache")
	ctx.Header("Connection", "keep-alive")
	ctx.Header("X-Accel-Buffering", "no") // 防止 nginx 缓存
	ctx.Status(http.StatusOK)

	flusher, ok := ctx.Writer.(http.Flusher)
	if ok {
		flusher.Flush()
	}

	// 3. 调用 Svc 层进行消息发送
	_ = d.DemoSvc.SSE(ctx.Request.Context(), func(msg *svc.SSEMessage) error {
		ctx.SSEvent("message", msg)
		// gin 的 SSEvent 不保证立即刷出,这里显式 Flush 让客户端实时收到
		if flusher != nil {
			flusher.Flush()
		}
		return nil
	})
}

// @Summary WSTicket
// @Description 申请 WebSocket 一次性升级票据(需授权),用 ticket 连接 WS,避免长 token 进 URL
// @Tags api
// @Produce json
// @Router /api/auth/ws-ticket [post]
func (d *DemoHandler) WSTicket(ctx *gin.Context) {
	uid, _ := ctx.Get(global.CtxAuthUserId)
	rid, _ := ctx.Get(global.CtxAuthRoleId)
	userId, _ := uid.(int64)
	roleId, _ := rid.(int64)
	ticket, err := d.DemoSvc.WSTicket(ctx.Request.Context(), userId, roleId)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "WSTicket 成功", gin.H{"ticket": ticket})
}

// @Summary WebSocket Demo
// @Description WebSocket 示例，支持 Echo 及定时心跳数据推送(需 ticket 鉴权)
// @Tags api
// @Param ticket query string true "一次性升级票据(由 /api/auth/ws-ticket 获取)"
// @Router /api/demo/ws [get]

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		origin := r.Header.Get("Origin")
		// 非浏览器客户端(如原生 App/测试工具)通常不带 Origin,已通过 ticket 鉴权,直接放行
		if origin == "" {
			return true
		}
		u, err := url.Parse(origin)
		if err != nil {
			return false
		}
		// 仅允许同源 host,生产环境不再额外放行 localhost
		return strings.EqualFold(u.Host, r.Host)
	},
}

func (d *DemoHandler) WS(ctx *gin.Context) {
	// WS 升级无法携带自定义 Header,用一次性 ticket 鉴权,长 token 不进 URL
	ticket := ctx.Query("ticket")
	userId, roleId, err := d.DemoSvc.ConsumeWSTicket(ctx.Request.Context(), ticket)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xlog.Info(ctx.Request.Context(), fmt.Sprintf("websocket connected, userId=%d roleId=%d", userId, roleId))

	conn, err := upgrader.Upgrade(ctx.Writer, ctx.Request, nil)
	if err != nil {
		xlog.Error(ctx.Request.Context(), "websocket upgrade failed", err)
		return
	}
	defer conn.Close()

	if err := d.DemoSvc.WS(ctx.Request.Context(), conn); err != nil {
		xlog.Error(ctx.Request.Context(), "websocket session failed", err)
	}
}
