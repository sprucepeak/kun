/**
 * @Author: spruce
 * @Date: 2024-03-28 21:36
 * @Desc: demo cache (中间数据通用缓存, 可供多业务场景复用)
 */

package cache

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"advanced/pkg/xredis"
)

var _ DemoCache = (*demoCache)(nil)

type (
	DemoCache interface {
		// 查询缓存 (获取通用中间数据实体 cache.Demo)
		Get(ctx context.Context, id int64) (data *Demo, err error)
		// 添加缓存 (存入通用中间数据实体 cache.Demo)
		Set(ctx context.Context, id int64, data *Demo, expiration int64) (err error)
		// 删除缓存(Redis + 本地),用于数据更新/删除后失效缓存
		Delete(ctx context.Context, id int64) error

		// SetWSTicket 存储 WebSocket 一次性升级票据
		SetWSTicket(ctx context.Context, ticket string, userId, roleId int64, ttl time.Duration) error
		// ConsumeWSTicket 原子校验并消费票据(单次有效)
		ConsumeWSTicket(ctx context.Context, ticket string) (userId, roleId int64, err error)
	}
	demoCache struct {
		common     *xredis.Client
		localCache *LocalCache
	}

	// WSTicketPayload WebSocket 升级票据载荷
	WSTicketPayload struct {
		UserId int64 `json:"user_id"`
		RoleId int64 `json:"role_id"`
	}

	// Demo 缓存中间数据模型 (存放清洗后的业务实体通用快照, 可供多处业务场景共享复用; 密码等敏感列不入缓存)
	Demo struct {
		Id     int64   `json:"id"`
		Name   string  `json:"name"`   // 名称
		Test1  float64 `json:"test1"`  // 测试1
		Test4  int8    `json:"test4"`  // 测试4
		RoleId int64   `json:"roleId"` // 角色id
	}
)

const (
	// defaultExpiration 当调用方未指定(<=0)TTL 时的默认缓存时长。
	// 避免传 0 时 Redis Set 永不过期,导致脏数据长期残留(需手动 Delete 才能失效)。
	defaultExpiration = 5 * time.Minute
)

func NewDemoCache(c *xredis.Client) DemoCache {
	return &demoCache{
		common:     c,
		localCache: NewLocalCache(5*time.Minute, 10*time.Minute),
	}
}

func (d *demoCache) Get(ctx context.Context, id int64) (*Demo, error) {
	key := fmt.Sprintf(DemoInfoKey, id)

	// 1. 查询本地缓存
	if value, ok := d.localCache.Get(key); ok {
		if demo, ok := value.(*Demo); ok {
			cp := *demo
			return &cp, nil
		}
	}

	// 2. 查询Redis缓存
	var demo *Demo
	data, err := d.common.Get(ctx, key).Bytes()
	if err != nil {
		if errors.Is(err, xredis.Nil) {
			return nil, fmt.Errorf("cache miss: %w", ErrNotFound)
		}
		return nil, fmt.Errorf("get cache failed: %w", err)
	}
	err = json.Unmarshal(data, &demo)
	if err != nil {
		return nil, err
	}
	// 设置本地缓存
	d.localCache.Set(key, demo, 5*time.Minute)
	cp := *demo
	return &cp, nil
}

func (d *demoCache) Set(ctx context.Context, id int64, data *Demo, expiration int64) error {
	key := fmt.Sprintf(DemoInfoKey, id)

	value, valueErr := json.Marshal(data)
	if valueErr != nil {
		return valueErr
	}
	ttl := time.Duration(expiration) * time.Second
	if expiration <= 0 {
		ttl = defaultExpiration
	}
	err := d.common.Set(ctx, key, string(value), ttl).Err()
	if err != nil {
		return err
	}
	// 同步写本地缓存 (存副本, 避免外部修改污染)
	cp := *data
	d.localCache.Set(key, &cp, ttl)
	return nil
}

func (d *demoCache) Delete(ctx context.Context, id int64) error {
	key := fmt.Sprintf(DemoInfoKey, id)

	// 本地缓存是 Redis 的副本,无论 Redis 删除是否成功都先清本地,避免残留旧值。
	d.localCache.Delete(key)

	// 删除 Redis,失败时包装原始错误(不吞原因)。
	if err := d.common.Del(ctx, key).Err(); err != nil {
		return fmt.Errorf("delete cache failed: %w", err)
	}
	return nil
}

func (d *demoCache) SetWSTicket(ctx context.Context, ticket string, userId, roleId int64, ttl time.Duration) error {
	data, err := json.Marshal(&WSTicketPayload{UserId: userId, RoleId: roleId})
	if err != nil {
		return err
	}
	key := fmt.Sprintf(WSTicketKey, ticket)
	return d.common.Set(ctx, key, data, ttl).Err()
}

func (d *demoCache) ConsumeWSTicket(ctx context.Context, ticket string) (userId, roleId int64, err error) {
	key := fmt.Sprintf(WSTicketKey, ticket)
	val, err := d.common.GetDel(ctx, key).Result()
	if err != nil {
		if errors.Is(err, xredis.Nil) {
			return 0, 0, ErrNotFound
		}
		return 0, 0, err
	}
	var p WSTicketPayload
	if err := json.Unmarshal([]byte(val), &p); err != nil {
		return 0, 0, err
	}
	return p.UserId, p.RoleId, nil
}
