/**
 * @Author: spruce
 * @Date: 2024-07-02
 * @Desc: service context
 */

package svc

import (
	"advanced/internal/repository/db"
	"advanced/pkg/xconfig"
	"advanced/pkg/xredis"
)

type (
	Ctx struct {
		Conf     *xconfig.Conf
		Conn     *db.Conn
		RedisCli *xredis.Client
	}
)

// =============================================================================
// 公共分页/排序契约模型 (可供多业务 Service/Handler 统一复用)
// =============================================================================

type (
	// PageReq 通用分页查询请求入参 (支持常规 offset 分页与游标 lastId 分页)
	PageReq struct {
		OrderField string `form:"orderField" json:"orderField"`                                             // 排序字段
		OrderType  int64  `form:"orderType"  json:"orderType"`                                              // 排序类型 0:降序(默认),1:升序
		Page       int64  `form:"page,default=1"      json:"page"      binding:"omitempty,min=1"`           // 页码(从1开始)
		PageSize   int64  `form:"pageSize,default=20" json:"pageSize"  binding:"omitempty,min=1,max=10000"` // 每页条数
		LastId     string `form:"lastId"     json:"lastId"`                                                 // 游标分页: 上一页最后一条记录的 ID (支持字符串格式防前端大数精度丢失)
	}

	// PageResp 通用全量总数分页响应 (适用于带 total 的常规表格列表)
	PageResp[T any] struct {
		Page     int64 `json:"page"`     // 当前页码
		PageSize int64 `json:"pageSize"` // 每页条数
		Total    int64 `json:"total"`    // 总记录数
		Items    []T   `json:"items"`    // 当前页数据列表
	}

	// PageMoreResp 通用滚动加载/游标分页响应 (适用于移动端瀑布流、无限滚动, 避免 count(*) 开销)
	PageMoreResp[T any] struct {
		Page     int64 `json:"page"`     // 当前页码或游标
		PageSize int64 `json:"pageSize"` // 每页条数
		HasMore  bool  `json:"hasMore"`  // 是否有下一页
		Items    []T   `json:"items"`    // 当前页数据列表
	}
)

// ToDbSearchPage 将通用 PageReq 转换为持久层的 db.SearchPage (包含 Page/PageSize 默认值兜底)
func (p *PageReq) ToDbSearchPage() db.SearchPage {
	if p == nil {
		return db.SearchPage{
			Page:     1,
			PageSize: db.DefaultPageSize,
		}
	}
	page := p.Page
	if page <= 0 {
		page = 1
	}
	pageSize := p.PageSize
	if pageSize <= 0 {
		pageSize = db.DefaultPageSize
	}
	return db.SearchPage{
		OrderField: p.OrderField,
		OrderType:  p.OrderType,
		Page:       page,
		PageSize:   pageSize,
		LastId:     p.LastId,
	}
}
