package svc

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"time"

	"advanced/internal/event"
	"advanced/internal/global"
	"advanced/internal/repository/cache"
	"advanced/internal/repository/db"
	"advanced/pkg/encrypt"
	"advanced/pkg/token"
	"advanced/pkg/utils"
	"advanced/pkg/xerror"
	"advanced/pkg/xlog"

	"github.com/gorilla/websocket"
	"github.com/xuri/excelize/v2"
	"golang.org/x/sync/singleflight"
)

//go:generate mockgen -source=./demo.go -destination=../../../test/mocks/service/demo.go  -package mock_service

var _ DemoSvc = (*demoSvc)(nil)

type (
	DemoSvc interface {
		Detail(ctx context.Context, id int64) (*DemoResp, error)
		FindList(ctx context.Context, args *DemoListReq) ([]*DemoResp, int64, error)
		Create(ctx context.Context, args *DemoCreateReq) error
		Update(ctx context.Context, args *DemoUpdateReq) error
		Delete(ctx context.Context, id int64) error
		SoftDelete(ctx context.Context, id int64) error

		// Login 登录(账号:demo名称,密码:password),返回双token
		Login(ctx context.Context, name, password string) (*token.JwtToken, error)
		// RefreshToken 刷新双token
		RefreshToken(ctx context.Context, accessToken, refreshToken string) (*token.JwtToken, error)
		// Logout 登出,废弃当前 accessToken 及其会话 SID(使成对的 refreshToken 也一并注销)
		Logout(ctx context.Context, accessToken string) error

		// BanUser 管理员封禁用户 (支持指定时长与原因)
		BanUser(ctx context.Context, userId int64, duration time.Duration, reason string) error
		// UnbanUser 管理员解封用户
		UnbanUser(ctx context.Context, userId int64) error
		// KickAllDevices 管理员强制用户所有设备下线
		KickAllDevices(ctx context.Context, userId int64) error

		// WSTicket 生成 WebSocket 一次性升级票据(30s 单次有效),规避浏览器 WS 无法设置 Header
		WSTicket(ctx context.Context, userId, roleId int64) (string, error)
		// ConsumeWSTicket 校验并消费票据(单次有效),返回票据绑定的 userId/roleId
		ConsumeWSTicket(ctx context.Context, ticket string) (userId, roleId int64, err error)

		SendMsg(ctx context.Context) error
		AddMsg(ctx context.Context) error
		DelMsg(ctx context.Context) error

		ExportStream(ctx context.Context, handler func(*DemoResp) error) error
		SSE(ctx context.Context, handler func(*SSEMessage) error) error
		WS(ctx context.Context, conn *websocket.Conn) error
		ExportExcel(ctx context.Context, writer io.Writer) error
	}
	DemoCtx struct {
		*Ctx

		DemoDb    db.DemoDb
		DemoCache cache.DemoCache
		MsgPub    *event.Pub
		Jwt       *token.Jwt
	}
	demoSvc struct {
		ctx *DemoCtx
		sf  singleflight.Group
	}

	SSEMessage struct {
		Time string `json:"time"`
		Msg  string `json:"msg"`
	}

	// DemoResp 业务响应 DTO (面向 API 接口输出的纯净视图, 严格屏蔽持久层内部/敏感字段)
	DemoResp struct {
		Id     int64   `json:"id"`     // ID
		Name   string  `json:"name"`   // 名称
		Test1  float64 `json:"test1"`  // 测试1
		Test4  int8    `json:"test4"`  // 测试4
		RoleId int64   `json:"roleId"` // 角色id
	}

	// DemoCreateReq 创建 Demo 接口请求入参 (包含密码等创建期特有字段)
	DemoCreateReq struct {
		Name     string  `form:"name" json:"name" binding:"required"`
		Test1    float64 `form:"test1" json:"test1"`
		Test4    int8    `form:"test4" json:"test4"`
		RoleId   int64   `form:"roleId" json:"roleId"`
		Password string  `form:"password" json:"password" binding:"required"`
	}

	// DemoUpdateReq 更新 Demo 接口请求入参
	DemoUpdateReq struct {
		Id     int64   `json:"id" binding:"required"`
		Name   string  `json:"name"`
		Test1  float64 `json:"test1"`
		Test4  int8    `json:"test4"`
		RoleId int64   `json:"roleId"`
	}

	// DemoListReq 列表查询接口请求入参 (内嵌公共分页模型 PageReq)
	DemoListReq struct {
		PageReq

		Id   *int64 `form:"id"   json:"id"`
		Name string `form:"name" json:"name"`
	}
)

func NewDemoSvc(ctx *DemoCtx) DemoSvc {
	return &demoSvc{
		ctx: ctx,
	}
}

// 查找一个(接入 singleflight 防缓存击穿)
func (d *demoSvc) Detail(ctx context.Context, id int64) (*DemoResp, error) {
	if id <= 0 {
		return nil, xerror.NewError(xerror.InvalidArgument, "Get Demo Detail invalid id", nil)
	}
	xlog.Info(ctx, "Demo Detail")

	// 1. 优先查通用中间缓存 (多处业务共享复用)
	if cacheData, cacheErr := d.ctx.DemoCache.Get(ctx, id); cacheErr == nil {
		return CacheToDemoResp(cacheData), nil
	}

	// 2. 缓存未命中: singleflight 合并同 ID 并发请求,防缓存击穿
	val, err, _ := d.sf.Do(fmt.Sprintf("demo:detail:%d", id), func() (any, error) {
		// double check 缓存,避免并发排队协程重复打库
		if dCached, cErr := d.ctx.DemoCache.Get(ctx, id); cErr == nil {
			return CacheToDemoResp(dCached), nil
		}

		demoDb, dbErr := d.ctx.DemoDb.Find(ctx, id)
		if dbErr != nil {
			return nil, dbErr
		}

		// 将 DB 底层数据清洗为可多处复用的中间缓存数据，写入缓存
		cacheItem := ToCacheDemo(demoDb)
		_ = d.ctx.DemoCache.Set(ctx, id, cacheItem, 0)

		// 转换为当前 API 接口所需的纯净 Response DTO
		return ToDemoResp(demoDb), nil
	})

	if err != nil {
		if errors.Is(err, db.ErrNotFound) {
			return nil, xerror.NewError(xerror.BusinessError, "没有相关记录", err)
		}
		return nil, xerror.NewError(xerror.BusinessError, "Demo Detail 失败", err)
	}

	return val.(*DemoResp), nil
}

// 查找列表
func (d *demoSvc) FindList(ctx context.Context, args *DemoListReq) ([]*DemoResp, int64, error) {

	dbArgs := ToDbDemoSearch(args)

	list, total, listErr := d.ctx.DemoDb.ListWithTotal(ctx, dbArgs)
	if listErr != nil {
		if errors.Is(listErr, db.ErrNotFound) {
			return []*DemoResp{}, 0, nil
		}
		return nil, 0, xerror.NewError(xerror.BusinessError, "Get Demo List 失败", listErr)
	}
	return ToDemoRespList(list), total, nil
}

// 创建
func (d *demoSvc) Create(ctx context.Context, args *DemoCreateReq) error {
	password := args.Password
	if password == "" {
		return xerror.NewError(xerror.InvalidArgument, "密码不能为空", nil)
	}
	hash, hashErr := encrypt.BcryptHash(password)
	if hashErr != nil {
		return xerror.NewError(xerror.BusinessError, "Create Demo 密码加密失败", hashErr)
	}
	_, dbErr := d.ctx.DemoDb.Insert(ctx, ToDbDemoForCreate(args, hash))
	if dbErr != nil {
		return xerror.NewError(xerror.BusinessError, "Create Demo 失败", dbErr)
	}
	return nil
}

// 修改(事务示例)
func (d *demoSvc) Update(ctx context.Context, args *DemoUpdateReq) error {
	if args.Id <= 0 {
		// id 不合法属于调用方参数错误，应返回 400 级 InvalidArgument，而非 500 级 BusinessError
		return xerror.NewError(xerror.InvalidArgument, "Update Demo invalid id", nil)
	}
	// 两种事务方式
	// 方式1:
	//err := d.ctx.Conn.Tx(ctx, func(ctx context.Context) error {
	//    preOneId := args.Id - 1
	//    demo, err := d.ctx.DemoDb.Find(ctx, preOneId)
	//    if err != nil {
	//        return err
	//    }
	//    err = d.ctx.DemoDb.Delete(ctx, []int64{preOneId})
	//    if err != nil {
	//        return err
	//    }
	//    if demo.Id == 3 {
	//        return errors.New("id是3,不能修改")
	//    }
	//    _, err = d.ctx.DemoDb.UpdateFields(ctx, args.Id, map[string]any{"name": args.Name, "test1": args.Test1, "test4": args.Test4})
	//    return err
	//})
	// 方式2:
	err := d.ctx.DemoDb.DemoUpdateTrans(ctx, args.Id, ToDbDemoForUpdate(args))
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "Update Demo 失败", err)
	}
	// DemoUpdateTrans 内部会删除 id-1 的记录,故 args.Id 与 args.Id-1 的缓存都要失效。
	d.invalidateCache(ctx, args.Id)
	d.invalidateCache(ctx, args.Id-1)
	return nil
}

// 物理删除
func (d *demoSvc) Delete(ctx context.Context, id int64) error {
	if id <= 0 {
		return xerror.NewError(xerror.InvalidArgument, "Delete Demo invalid id", nil)
	}
	err := d.ctx.DemoDb.Delete(ctx, []int64{id})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "Delete Demo 失败", err)
	}
	d.invalidateCache(ctx, id)
	return nil
}

// 逻辑删除
func (d *demoSvc) SoftDelete(ctx context.Context, id int64) error {
	if id <= 0 {
		return xerror.NewError(xerror.InvalidArgument, "SoftDelete Demo invalid id", nil)
	}
	err := d.ctx.DemoDb.SoftDelete(ctx, []int64{id})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "SoftDelete Demo 失败", err)
	}
	d.invalidateCache(ctx, id)
	return nil
}

// invalidateCache 失效指定 id 的缓存(Redis + 本地)。
// 缓存删除失败不阻断主流程(数据已落库),仅记录日志,等 TTL 自然过期。
func (d *demoSvc) invalidateCache(ctx context.Context, id int64) {
	if id <= 0 {
		return
	}
	if err := d.ctx.DemoCache.Delete(ctx, id); err != nil {
		xlog.Error(ctx, fmt.Sprintf("invalidate demo cache failed, id=%d", id), err)
	}
}

// Login 登录(账号:demo名称,密码:password),校验通过后签发双token
func (d *demoSvc) Login(ctx context.Context, name, password string) (*token.JwtToken, error) {
	if name == "" || password == "" {
		return nil, xerror.NewError(xerror.AccountOrPasswordError, "账号或密码不能为空", nil)
	}
	demoDb, err := d.ctx.DemoDb.FindByName(ctx, name)
	if err != nil {
		if errors.Is(err, db.ErrNotFound) {
			return nil, xerror.NewError(xerror.AccountOrPasswordError, "账号或密码错误", nil)
		}
		return nil, xerror.NewError(xerror.BusinessError, "Login 失败", err)
	}
	if !encrypt.BcryptCompare(demoDb.Password, password) {
		return nil, xerror.NewError(xerror.AccountOrPasswordError, "账号或密码错误", nil)
	}
	// 登录前拦截: 检查用户是否已被管理员封禁
	if banned, reason, bErr := d.ctx.Jwt.IsUserBanned(ctx, demoDb.Id); bErr != nil {
		return nil, xerror.NewError(xerror.BusinessError, "检查用户封禁状态失败", bErr)
	} else if banned {
		msg := "账号已被封禁，如有疑问请联系管理员"
		if reason != "" {
			msg = fmt.Sprintf("账号已被封禁: %s", reason)
		}
		return nil, xerror.NewError(xerror.UserBanned, msg, nil)
	}
	tokenInfo, err := d.ctx.Jwt.Gen(demoDb.Id, demoDb.RoleId)
	if err != nil {
		return nil, xerror.NewError(xerror.BusinessError, "Login 生成token失败", err)
	}
	return tokenInfo, nil
}

// RefreshToken 刷新双token
func (d *demoSvc) RefreshToken(ctx context.Context, accessToken, refreshToken string) (*token.JwtToken, error) {
	tokenInfo, err := d.ctx.Jwt.Refresh(ctx, accessToken, refreshToken)
	if err != nil {
		var e *token.Error
		if errors.As(err, &e) && e.Errors == token.ErrorAuthorizeElsewhere {
			return nil, xerror.NewError(xerror.AuthKickedOut, "账号已在其他设备登录，当前会话已失效", err)
		}
		return nil, xerror.NewError(xerror.AuthRefreshErr, "刷新token失败", err)
	}
	return tokenInfo, nil
}

// Logout 登出,废弃当前 accessToken 及其会话 SID
// 密码学安全与幂等防御：
//  1. 严格使用 ParseWithoutBlacklist 进行 HMAC 密码学验签：只有由本服务私钥签发的真实 Token 才能通过验签，
//     任何伪造/篡改的 Token（无论其 payload 写着谁的 SID 或 Subject）均被 100% 拒绝，绝不操作 Redis，彻底消除恶意下线他人漏洞！
//  2. 真实 Token 即使已自然过期或此前已被踢出/拉黑，验签仍能正常通过，安全提取其真实 SID 并在 Redis 中闭环销毁与清理；
//  3. 对非法伪造 Token 或无凭据请求，不执行任何 Redis 销毁操作，但 HTTP 层面均静默返回成功，保证前端不出现 2002 错误。
func (d *demoSvc) Logout(ctx context.Context, accessToken string) error {
	accessToken = token.CleanToken(accessToken)
	if accessToken == "" {
		return nil
	}
	// 密码学强验签：允许已过期与已在黑名单状态，但绝不接受未验签或签名错误的伪造 Token！
	payload, err := d.ctx.Jwt.ParseWithoutBlacklist(accessToken)
	if err != nil || payload == nil {
		// 签名校验失败说明属于攻击者伪造或篡改的恶意 Token，零操作直接返回，绝不误触 Redis 销毁他人会话！
		return nil
	}

	now := time.Now().Unix()
	// 1. 废弃 accessToken 本身 (若尚未自然过期)
	if payload.ExpiresAt != nil {
		if expiration := payload.ExpiresAt.Unix() - now; expiration > 0 {
			_ = d.ctx.Jwt.Disuse(ctx, accessToken, expiration)
		}
	}
	// 2. 废弃会话 SID (连带注销对应的 refreshToken，同时 DisuseSession 内部已自动原子清理单端活跃会话)
	if payload.SID != "" {
		_ = d.ctx.Jwt.DisuseSession(ctx, payload.SID, int64(d.ctx.Jwt.RefreshTime.Seconds()))
	}
	return nil
}

// BanUser 管理员封禁用户
func (d *demoSvc) BanUser(ctx context.Context, userId int64, duration time.Duration, reason string) error {
	if userId <= 0 {
		return xerror.NewError(xerror.InvalidArgument, "用户ID无效", nil)
	}
	if err := d.ctx.Jwt.BanUser(ctx, userId, duration, reason); err != nil {
		return xerror.NewError(xerror.BusinessError, "封禁用户失败", err)
	}
	return nil
}

// UnbanUser 管理员解封用户
func (d *demoSvc) UnbanUser(ctx context.Context, userId int64) error {
	if userId <= 0 {
		return xerror.NewError(xerror.InvalidArgument, "用户ID无效", nil)
	}
	if err := d.ctx.Jwt.UnbanUser(ctx, userId); err != nil {
		return xerror.NewError(xerror.BusinessError, "解封用户失败", err)
	}
	return nil
}

// KickAllDevices 管理员强制用户所有设备下线
func (d *demoSvc) KickAllDevices(ctx context.Context, userId int64) error {
	if userId <= 0 {
		return xerror.NewError(xerror.InvalidArgument, "用户ID无效", nil)
	}
	if err := d.ctx.Jwt.KickAllDevices(ctx, userId); err != nil {
		return xerror.NewError(xerror.BusinessError, "强制下线失败", err)
	}
	return nil
}

// WSTicket 生成 WebSocket 一次性升级票据(30s,单次有效)
// 浏览器 WebSocket 升级请求无法设置自定义 Header,改用短票据换连接,长 token 不进 URL
func (d *demoSvc) WSTicket(ctx context.Context, userId, roleId int64) (string, error) {
	if userId <= 0 {
		return "", xerror.NewError(xerror.Unauthorized, "用户未登录", nil)
	}
	ticket := utils.GenUUid()
	if err := d.ctx.DemoCache.SetWSTicket(ctx, ticket, userId, roleId, 30*time.Second); err != nil {
		return "", xerror.NewError(xerror.BusinessError, "生成票据失败", err)
	}
	return ticket, nil
}

// ConsumeWSTicket 校验并消费票据(GetDel 原子取删,保证单次有效)
func (d *demoSvc) ConsumeWSTicket(ctx context.Context, ticket string) (int64, int64, error) {
	if ticket == "" {
		return 0, 0, xerror.NewError(xerror.Unauthorized, "票据不能为空", nil)
	}
	userId, roleId, err := d.ctx.DemoCache.ConsumeWSTicket(ctx, ticket)
	if err != nil {
		if errors.Is(err, cache.ErrNotFound) {
			return 0, 0, xerror.NewError(xerror.Unauthorized, "票据无效或已过期", nil)
		}
		return 0, 0, xerror.NewError(xerror.BusinessError, "票据校验失败", err)
	}
	return userId, roleId, nil
}

// 发送消息
func (d *demoSvc) SendMsg(ctx context.Context) error {
	demoMsg0, err := json.Marshal(&global.PayRecharge{
		TradeNo:    "O100",
		PayType:    global.PayTypeAlipay,
		Status:     global.PayStatusIng,
		UserId:     123,
		Cash:       utils.Yuan2Cent(1.20),
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "Kafka-无type-消息",
	})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "序列化 Kafka 消息失败", err)
	}
	if err = d.ctx.MsgPub.KafkaCtx(ctx, global.EventTopicPay, demoMsg0); err != nil {
		return err
	}

	demoMsg1, err := json.Marshal(&global.PayRecharge{
		TradeNo:    "O101",
		PayType:    global.PayTypeAlipay,
		Status:     global.PayStatusIng,
		UserId:     123,
		Cash:       utils.Yuan2Cent(1.30),
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "Kafka-type-消息",
	})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "序列化 Kafka-type 消息失败", err)
	}
	if err = d.ctx.MsgPub.KafkaWithTypeCtx(ctx, global.EventTopicPay, global.EventTypePayRecharge, demoMsg1); err != nil {
		return err
	}

	demoMsg2, err := json.Marshal(&global.PayRecharge{
		TradeNo:    "O102",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusSuccess,
		UserId:     123,
		Cash:       utils.Yuan2Cent(1.50),
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "5s延迟消息",
	})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "序列化延迟消息失败", err)
	}
	if err = d.ctx.MsgPub.DelayCtx(ctx, global.EventTopicPay, string(demoMsg2), 5); err != nil {
		return err
	}

	demoMsg3, err := json.Marshal(&global.PayRecharge{
		TradeNo:    "O103",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusSuccess,
		UserId:     123,
		Cash:       utils.Yuan2Cent(1.60),
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-异步-消息",
	})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "序列化 AQ 异步消息失败", err)
	}
	if err = d.ctx.MsgPub.SyncCtx(ctx, global.EventTopicPay, string(demoMsg3)); err != nil {
		return err
	}

	demoMsg4, err := json.Marshal(&global.PayRecharge{
		TradeNo:    "O104",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusSuccess,
		UserId:     123,
		Cash:       utils.Yuan2Cent(1.70),
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-MsgTopicPay1-异步-消息",
	})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "序列化 AQ TopicPay1 消息失败", err)
	}
	if err = d.ctx.MsgPub.SyncCtx(ctx, global.EventTopicPay1, string(demoMsg4)); err != nil {
		return err
	}

	demoMsg5, err := json.Marshal(&global.PayRecharge{
		TradeNo:    "O105",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusFail,
		UserId:     0,
		Cash:       0,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-每三秒一次-消息",
	})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "序列化定时消息失败", err)
	}
	// 先取消可能已存在的同 topic Cron 任务（幂等保护），再注册新任务，
	// 防止接口重试或并发调用导致重复注册多个定时任务引发雪崩。
	// DelCron 对不存在的 topic 不报错，可安全调用。
	_ = d.ctx.MsgPub.DelCron(global.EventTopicPay)
	if err = d.ctx.MsgPub.Cron(global.EventTopicPay, string(demoMsg5), "@every 3s"); err != nil {
		return err
	}

	return nil
}

// 手动添加消息
func (d *demoSvc) AddMsg(ctx context.Context) error {
	demoMsg0, err := json.Marshal(&global.PayRecharge{
		TradeNo:    utils.GenStr(6, 8),
		PayType:    global.PayTypeAlipay,
		Status:     global.PayStatusIng,
		UserId:     123,
		Cash:       utils.Yuan2Cent(9.99),
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "Kafka-无type-手动添加消息",
	})
	if err != nil {
		return xerror.NewError(xerror.BusinessError, "序列化 Kafka 消息失败", err)
	}
	if err = d.ctx.MsgPub.KafkaCtx(ctx, global.EventTopicPay, demoMsg0); err != nil {
		return err
	}
	return nil
}

// 发送删除消息
func (d *demoSvc) DelMsg(ctx context.Context) error {
	_ = d.ctx.MsgPub.DelCron(global.EventTopicPay)
	return nil
}

func (d *demoSvc) ExportStream(ctx context.Context, handler func(*DemoResp) error) error {
	return d.ctx.DemoDb.FindStream(ctx, func(dbItem *db.Demo) error {
		return handler(ToDemoResp(dbItem))
	})
}

func (d *demoSvc) SSE(ctx context.Context, handler func(*SSEMessage) error) error {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return nil
		case t := <-ticker.C:
			// 数据处理逻辑（数据格式化和构造完全写在 Service 层）
			msg := &SSEMessage{
				Time: t.Format("2006-01-02 15:04:05"),
				Msg:  "hello sse",
			}
			if err := handler(msg); err != nil {
				return err
			}
		}
	}
}

// wsOut websocket 写出消息
type wsOut struct {
	msgType int
	payload []byte
}

func (d *demoSvc) WS(ctx context.Context, conn *websocket.Conn) error {
	// gorilla/websocket 不支持并发写,所有写操作都经 writeCh 串行化由单个写协程执行
	writeCh := make(chan wsOut, 16)
	done := make(chan struct{})

	// 写协程:唯一调用 conn.WriteMessage 的地方
	writeCtx, writeCancel := context.WithCancel(ctx)
	defer writeCancel()
	go func() {
		for {
			select {
			case <-writeCtx.Done():
				return
			case out, ok := <-writeCh:
				if !ok {
					return
				}
				if err := conn.WriteMessage(out.msgType, out.payload); err != nil {
					xlog.Error(ctx, "websocket write failed", err)
					writeCancel()
					return
				}
			}
		}
	}()

	// 接收消息并 Echo
	go func() {
		defer close(done)
		for {
			messageType, message, err := conn.ReadMessage()
			if err != nil {
				xlog.Info(ctx, fmt.Sprintf("websocket read failed or closed: %v", err))
				return
			}
			xlog.Info(ctx, fmt.Sprintf("websocket received message: %s", string(message)))
			// 收到消息后，加上前缀 Echo 返回客户端
			echoMsg := fmt.Sprintf("echo: %s", string(message))
			select {
			case writeCh <- wsOut{msgType: messageType, payload: []byte(echoMsg)}:
			case <-writeCtx.Done():
				return
			}
		}
	}()

	// 模拟服务器主动推送:连接后立即下发一条随机字符串消息
	go func() {
		msg := fmt.Sprintf("server push: %s", utils.GenStr(utils.AlphaNoLowerZeroDigital, 16))
		select {
		case writeCh <- wsOut{msgType: websocket.TextMessage, payload: []byte(msg)}:
		case <-writeCtx.Done():
		}
	}()

	// 定时发送消息给客户端
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-done:
			return nil
		case <-ctx.Done():
			return nil
		case t := <-ticker.C:
			msg := fmt.Sprintf("server time: %s", t.Format("2006-01-02 15:04:05"))
			select {
			case writeCh <- wsOut{msgType: websocket.TextMessage, payload: []byte(msg)}:
			case <-writeCtx.Done():
				return nil
			}
		}
	}
}

// errExportRowLimit 是 ExportExcel 达到行数上限时的哨兵错误，用于正常截断，不向调用方透出。
var errExportRowLimit = errors.New("export row limit reached")

// ExportExcel 以流式方式将数据写入 Excel 并输出到 writer。
// 注意：excelize StreamWriter 底层仍会在 Flush 后将完整 ZIP 文件组装至内存再写出（f.Write），
// 因此本函数对导出行数做了硬上限（maxRows）保护，防止超大数据量导致 OOM。
// 若需导出百万级数据，建议改用 CSV 格式或异步生成后上传对象存储再返回下载链接。
func (d *demoSvc) ExportExcel(ctx context.Context, writer io.Writer) error {
	const maxRows = 100000 // 硬上限：防止超大导出 OOM

	// 创建 Excel 文件并使用 StreamWriter 流式写入
	f := excelize.NewFile()
	defer f.Close()
	sheetName := "Demo数据"
	index, _ := f.NewSheet(sheetName)
	f.SetActiveSheet(index)
	// 删除默认的 Sheet1
	_ = f.DeleteSheet("Sheet1")

	// 创建流式写入器
	sw, err := f.NewStreamWriter(sheetName)
	if err != nil {
		return err
	}

	// 写入表头
	headers := []any{"ID", "名称", "测试1", "测试4"}
	if err := sw.SetRow("A1", headers); err != nil {
		return err
	}

	// 5. 开始流式导出数据
	rowNum := 2
	exported := 0
	err = d.ExportStream(ctx, func(item *DemoResp) error {
		if exported >= maxRows {
			// 超出上限，以哨兵错误终止迭代，ExportStream 停止后由外层识别并视为正常截断
			return errExportRowLimit
		}
		// 写入数据行
		rowData := []any{item.Id, item.Name, item.Test1, item.Test4}
		if err := sw.SetRow(fmt.Sprintf("A%d", rowNum), rowData); err != nil {
			return err
		}
		rowNum++
		exported++
		return nil
	})

	// 超出行数上限视为正常截断，不向调用方透出
	if err != nil && !errors.Is(err, errExportRowLimit) {
		return err
	}

	// 结束流式写入
	if err := sw.Flush(); err != nil {
		return err
	}

	// 设置表头样式（SetCellStyle 须在 StreamWriter.Flush 之后调用）
	style, _ := f.NewStyle(&excelize.Style{
		Font: &excelize.Font{
			Bold: true,
		},
		Fill: excelize.Fill{
			Type:    "pattern",
			Pattern: 1,
			Color:   []string{"#E0E0E0"},
		},
	})
	// 使用 ColumnNumberToName 安全计算列地址，支持超过 26 列（AA、AB…）
	lastCol, _ := excelize.ColumnNumberToName(len(headers))
	_ = f.SetCellStyle(sheetName, "A1", lastCol+"1", style)

	// 设置列宽
	_ = f.SetColWidth(sheetName, "A", "A", 10)
	_ = f.SetColWidth(sheetName, "B", "B", 30)
	_ = f.SetColWidth(sheetName, "C", "C", 15)
	_ = f.SetColWidth(sheetName, "D", "D", 15)

	// 将完整的 Excel 文件写入传入的 writer
	if err := f.Write(writer); err != nil {
		return err
	}
	return nil
}

// =============================================================================
// 层间转换函数 (DO <-> Cache 中间数据 <-> DTO)
// =============================================================================

// ToCacheDemo 将底层 db.Demo 转换为可多处共享的中间缓存模型 cache.Demo
func ToCacheDemo(do *db.Demo) *cache.Demo {
	if do == nil {
		return nil
	}
	return &cache.Demo{
		Id:     do.Id,
		Name:   do.Name,
		Test1:  do.Test1,
		Test4:  do.Test4,
		RoleId: do.RoleId,
	}
}

// CacheToDemoResp 将多处通用的中间缓存数据转换为当前接口响应 DTO
func CacheToDemoResp(c *cache.Demo) *DemoResp {
	if c == nil {
		return nil
	}
	return &DemoResp{
		Id:     c.Id,
		Name:   c.Name,
		Test1:  c.Test1,
		Test4:  c.Test4,
		RoleId: c.RoleId,
	}
}

// ToDemoResp 将数据库底层实体 db.Demo 直接转换为业务响应 DTO
func ToDemoResp(do *db.Demo) *DemoResp {
	if do == nil {
		return nil
	}
	return &DemoResp{
		Id:     do.Id,
		Name:   do.Name,
		Test1:  do.Test1,
		Test4:  do.Test4,
		RoleId: do.RoleId,
	}
}

// ToDemoRespList 批量将数据库底层实体转换为业务响应 DTO 列表
func ToDemoRespList(dos []*db.Demo) []*DemoResp {
	if dos == nil {
		return []*DemoResp{}
	}
	res := make([]*DemoResp, len(dos))
	for i, do := range dos {
		res[i] = ToDemoResp(do)
	}
	return res
}

// ToDbDemoForCreate 将创建入参及加密后的密码密文转换为 db.Demo 实体
func ToDbDemoForCreate(req *DemoCreateReq, passwordHash string) *db.Demo {
	if req == nil {
		return nil
	}
	return &db.Demo{
		Name:     req.Name,
		RoleId:   req.RoleId,
		Password: passwordHash,
		Test1:    req.Test1,
		Test4:    req.Test4,
	}
}

// ToDbDemoForUpdate 将更新入参转换为 db.Demo 实体 (仅赋值允许修改的字段)
func ToDbDemoForUpdate(req *DemoUpdateReq) *db.Demo {
	if req == nil {
		return nil
	}
	return &db.Demo{
		Id:     req.Id,
		Name:   req.Name,
		RoleId: req.RoleId,
		Test1:  req.Test1,
		Test4:  req.Test4,
	}
}

// ToDbDemoSearch 将列表查询入参转换为 Repository 层的 db.DemoSearch
func ToDbDemoSearch(req *DemoListReq) *db.DemoSearch {
	if req == nil {
		return &db.DemoSearch{}
	}
	return &db.DemoSearch{
		SearchPage: req.PageReq.ToDbSearchPage(),
		Id:         req.Id,
		Name:       req.Name,
	}
}
