# JWT 双 Token 认证安全架构与全流程规范

本文档梳理并阐明 `pkg/token` 模块中 JWT Token **从启动配置、签发生效、本地验签、单槽 Redis 原子校验、无感轮换续签、单端互斥、主动登出、多级拉黑到解封恢复** 的全生命周期机制与安全架构设计。

---

## 目录

- [一、核心架构设计与关键安全机制](#一核心架构设计与关键安全机制)
- [二、Redis 键空间与单槽分片架构 (Hash Tag)](#二redis-键空间与单槽分片架构-hash-tag)
- [三、全生命周期全链路流程详解](#三全生命周期全链路流程详解)
  - [1. 配置初始化与强隔离校验 (NewJwt)](#1-配置初始化与强隔离校验-newjwt)
  - [2. Token 生成与登录认证 (Gen / GenWithSession)](#2-token-生成与登录认证-gen--genwithsession)
  - [3. 提取清洗与请求鉴权 (Find / CleanToken / Parse)](#3-提取清洗与请求鉴权-find--cleantoken--parse)
  - [4. 双 Token 轮换续签与防重放熔断 (RefreshToken)](#4-双-token-轮换续签与防重放熔断-refreshtoken)
  - [5. 主动登出 (DisuseSession)](#5-主动登出-disusesession)
  - [6. 单端互斥踢下线与全端强制下线 (Kick / KickAllDevices)](#6-单端互斥踢下线与全端强制下线-kick--kickalldevices)
  - [7. 管理员封禁与解封闭环 (BanUser / UnbanUser)](#7-管理员封禁与解封闭环-banuser--unbanuser)
- [四、全链路状态流转时序图](#四全链路状态流转时序图)
- [五、配置参数说明与错误码映射](#五配置参数说明与错误码映射)

---

## 一、核心架构设计与关键安全机制

系统采用业界推荐的 **“双 Token + 会话族绑定 + CSPRNG 随机数 + HttpOnly Cookie + 单槽 Lua 原子鉴权”** 综合防御体系：

### 1. 凭证划分与职责

* **AccessToken (访问凭据)**：
  * **短生命周期**（默认 2 小时），负责携带用户身份与权限声明（`Subject`: 用户ID, `Issuer`: 角色ID, `ID`: 密码学安全 JTI）。
  * 建议前端保存在**内存（Memory / Pinia / Vuex）**中，随 HTTP 请求头 `Authorization: Bearer <token>` 传递，天然规避 CSRF 风险。
* **RefreshToken (刷新凭据)**：
  * **长生命周期**（单次 7 天，受绝对最大有效期 `MaxRefreshTime` 约束），仅用于在 AccessToken 过期后换取新 Token 族。
  * Web 端建议写入 **HttpOnly Cookie**，禁止 JavaScript 脚本读取，彻底防御 XSS 盗取长效凭据；移动端/小程序兼容从 Body / Header 获取。

### 2. 核心密码学与安全防御亮点

1. **双密钥强物理隔离**：
   * 访问 Token 与刷新 Token 强制使用独立密钥（`Secret != RefreshSecret`），启动期强制校验；杜绝拿着 RefreshToken 伪装成 AccessToken 越权调用业务接口。
2. **CSPRNG 密码学安全 JTI**：
   * JTI 统一采用 `crypto/rand` 操作系统底层安全熵池生成 16 字节十六进制随机串，彻底杜绝伪随机序列被预测的风险。
3. **分布式 NTP 时钟漂移容错 (Clock Drift Tolerance)**：
   * 内置 `v5.WithLeeway(2 * time.Second)` 时钟容错，平抑微服务/K8s 集群跨节点毫秒至秒级 NTP 时间抖动，杜绝临界点误判过期。
4. **4KB 恶意超长包 DoS 防御**：
   * `CleanToken` 入口严格设定 `maxTokenLen = 4096`（4KB）安全上限，防范恶意超大 HTTP 请求头消耗过多内存与正则 CPU。
5. **绝对最大有效期限制 (`MaxRefreshTime`)**：
   * 每次签发的 Token 记录首次登录认证时间戳 `AuthTime`；刷新时检查 `now - AuthTime < MaxRefreshTime`，彻底封堵“无限续签”漏洞。
6. **重放攻击精确归因与安全熔断 (Compromised Rotation)**：
   * 客户端并发刷新采用 10ms~25ms 阶梯微退避平滑获取宽限期结果；
   * 若已废弃的 RefreshToken 在宽限期外再次被提交，系统判定为**凭据泄露重放攻击（Compromised）**，立即吊销该会话族全部 Token 并记录安全审计日志。

---

## 二、Redis 键空间与单槽分片架构 (Hash Tag)

为在 Redis Cluster（集群分片）环境下**彻底杜绝 CROSSSLOT 跨槽报错**，所有同一用户相关的状态键统一注入 `{u:userId}` Hash Tag，确保 100% 路由至同一 Slot 分片内执行原子 Lua 操作：

| 统一键名模式 | 存储值 | 默认 TTL | 作用说明 |
| :--- | :--- | :--- | :--- |
| `td:{u:<userId>}:t:<MD5(token)>` | `1` | Token 剩余有效秒数 | 单凭据黑名单（如旧 AccessToken 延迟作废） |
| `td:{u:<userId>}:s:<SID>` | 原因文本 (`logout` / `kicked` / `compromised`) | `RefreshTime` (7天) | 会话级黑名单：注销整对 AccessToken 与 RefreshToken |
| `td:{u:<userId>}:cs` | `<SID>` | `RefreshTime` (7天) | 单端登录控制：记录当前用户唯一的活跃会话 SID |
| `td:{u:<userId>}:b` | `<封禁原因文本>` | 指定封禁时长 (或永久) | 管理员全局封号：全端即时阻断且拦截登录 |
| `td:{u:<userId>}:m` | `<秒级时间戳>` | `RefreshTime` 或 `MaxRefreshTime` | 全端强制下线：所有 `AuthTime <= minAuth` 的旧 Token 即刻失效 |
| `td:{u:<userId>}:rot:<MD5(refreshToken)>` | `JwtToken` JSON 结构体 | 30 秒 (`GracePeriod`) | 轮换宽限期缓存：并发/网络抖动重试时幂等返回新 Token |

---

## 三、全生命周期全链路流程详解

### 1. 配置初始化与强隔离校验 (NewJwt)

* 启动期强校验 `Secret` 与 `RefreshSecret` 不为空且**绝对不相同**；
* 校验密钥长度均必须 $\ge 32$ 字节（满足 HS384 安全强度）；若配置了 CSRFKey 严格校验必须为 32 字节；
* 校验 `RefreshTime > ExpireTime` 以及 `MaxRefreshTime >= RefreshTime`；
* 预分配密钥字节切片与预编译 Parser（配置 `HS384` 单一算法要求与 `WithLeeway` 时钟容错），消除高频堆内存分配。

### 2. Token 生成与登录认证 (Gen / GenWithSession)

1. **全新登录（`sid == ""`）**：
   * 生成全新的带用户前缀的唯一会话标识 `SID = {userId}_{uuid}`；
   * 记录认证时间戳 `authTime = time.Now().Unix()`。
2. **单端互斥控制（`!MultiLogin` 单端模式）**：
   * 执行全版本兼容的 Lua 脚本（`GET` + `SETEX` 原生原子操作），置换 `td:{u:userId}:cs` 为新 `SID`，并取出 `oldSid`；
   * 若存在 `oldSid` 且不等于当前 `SID`，调用 `DisuseSessionWithReason(oldSid, TTL, "kicked")` 将旧会话标记为被顶下线。
3. **独立签发双 Token**：
   * 使用 `secretBytes` 签发 AccessToken（Audience: `somebody`，JTI: CSPRNG 随机数）；
   * 使用 `refreshSecretBytes` 签发 RefreshToken（Audience: `refresh`，JTI: CSPRNG 随机数）。

### 3. 提取清洗与请求鉴权 (Find / CleanToken / Parse)

1. **提取与边界清洗**：
   * 调用 `jwt.Find(r)`，按顺序依次从 `Header (Authorization)` ➔ `Cookie` ➔ `URL Query` 提取；
   * 调用 `CleanToken`：长度超过 4KB 直接短路拒绝，剥离 `Bearer ` 前缀并去除首尾空白。
2. **进程内零 Redis 损耗验签**：
   * 使用预绑定的 `keyFuncAccess` 和常驻 `parser` 执行验签；签名错误或算法伪造立即在进程内短路拒绝，**零 Redis 请求，杜绝伪造 Token 冲击缓存**；
   * 优先在应用内存中比对 `ExpiresAt` 与 `NotBefore`；若已过期，立即返回 `ErrExpiredToken` 供无感刷新使用，同样免于打向 Redis。
3. **Redis 单槽 Lua 脚本批量原子校验 (`checkTokenScript`)**：
   * 一次性传入携带 `{u:userId}` Hash Tag 的 4 个同槽键：`[tokenKey, sidKey, banKey, minAuthKey]` 及 `authTime`；
   * 执行 `checkTokenScript`（EVALSHA），网络带宽减少 95%：
     * **状态 1**：命中单 Token 黑名单或会话主动登出 ➔ 返回 401（`ErrInvalidToken` / `ErrRevokedToken`）；
     * **状态 2**：命中封号键 ➔ 返回 401，业务码 `2008`（`ErrUserBanned`）；
     * **状态 3**：命中被顶下线（`kicked`）或强制下线（`authTime <= minAuth`）➔ 返回 401，业务码 `2007`（`ErrAuthorizeElsewhere`）；
     * **状态 0**：放行。

### 4. 双 Token 轮换续签与防重放熔断 (RefreshToken)

前端在捕获到 AccessToken 过期（401 / `ErrExpiredToken`）后，调用 `/api/demo/refresh`：

1. **双 Token 强验签与同一族校验**：
   * 使用 `refreshSecret` 验签 RefreshToken，使用 `secret` 解析 AccessToken；
   * 严格校验 `accessClaims.Subject == refreshClaims.Subject` 且 `accessClaims.SID == refreshClaims.SID`，杜绝拼凑不同用户的凭据。
2. **绝对最大有效期熔断**：
   * 检查 `time.Now() - AuthTime >= MaxRefreshTime`，超时则拒绝续签并强制重新登录。
3. **原子抢占旧 RefreshToken (`disuseTokenIfAbsent`)**：
   * 执行 `SETNX` 试图抢占旧 `refreshToken`；
   * **抢占成功（正常轮换）**：
     * 继承原 `SID` 和 `AuthTime` 签发新 Token 对；
     * 将新 Token 写入 30 秒轮换宽限期缓存 `td:{u:userId}:rot:<tokenMd5>`；
     * 旧 AccessToken 启动后台延迟废弃（10秒 in-flight 缓冲期，闭包内附带 `recover` 兜底守护，黑名单 TTL 严格覆盖剩余时长）。
   * **抢占失败（并发或重放）**：
     * 启动 10ms~25ms 阶梯微退避轮询宽限期缓存；
     * **命中宽限期缓存**：说明是前端并发请求或网络重试，安全复用返回同一批新 Token，杜绝并发误杀；
     * **宽限期外仍被使用**：判定为**凭据泄漏重放攻击（Compromised）**，触发熔断：`DisuseSessionWithReason(sid, TTL, "compromised")`，吊销整条会话族并输出安全告警。

### 5. 主动登出 (DisuseSession)

用户主动注销登录时调用 `/api/demo/logout`：

1. **作废会话 SID**：调用 `DisuseSession(ctx, sid, ttl)` 将 `td:{u:userId}:s:<sid>` 置为 `logout`，客户端持有的成对 AccessToken 和 RefreshToken 瞬间连带失效；
2. **单端模式清理活跃键**：若为单端模式，执行 Lua 脚本原子对比并删除 `td:{u:userId}:cs`，杜绝死会话残留；
3. **客户端清理 Cookie**：响应头下发 `Set-Cookie: refreshToken=""; Max-Age=-1`。

### 6. 单端互斥踢下线与全端强制下线 (Kick / KickAllDevices)

* **单端互斥（自动触发）**：用户在设备 B 登录，设备 A 的 `SID` 即被标记为 `kicked`。设备 A 后续发起的任何请求或刷新均会被拒绝（业务码 `2007`）。
* **全端强制下线（管理员操作）**：管理员调用 `KickAllDevices(ctx, userId)`，将 `td:{u:userId}:m` 设置为当前时间戳并清除当前会话。所有设备在此时间戳前签发的 Token 立即失效，重新输入密码登录后签发的新 Token 可立即恢复使用，账号不被锁死。

### 7. 管理员封禁与解封闭环 (BanUser / UnbanUser)

* **封禁账号 (`BanUser`)**：写入 `td:{u:userId}:b = reason`（支持永久或指定时长），并**同步调用 `KickAllDevices` 刷新下线时间戳**，彻底消除被封禁前流通的旧 Token 在日后解封时“起死回生”的潜伏重放风险。
* **解封账号 (`UnbanUser`)**：删除 `td:{u:userId}:b`。解封后用户必须重新输入密码完成认证，历史泄露凭据永远无法复用。

---

## 四、全链路状态流转时序图

```mermaid
sequenceDiagram
    autonumber
    actor Client as 客户端 (Web/App)
    participant AuthMW as 鉴权中间件 (Auth)
    participant Svc as 业务服务 (DemoSvc)
    participant JWT as Token组件 (Jwt)
    participant Redis as Redis集群 (Hash Tag单槽)

    Note over Client,Redis: 1. 登录与会话置换流程 (Login)
    Client->>Svc: POST /api/demo/login (账号/密码)
    Svc->>JWT: IsUserBanned(userId)
    JWT->>Redis: GET td:{u:userId}:b
    Redis-->>JWT: nil (未被封禁)
    Svc->>JWT: Gen(userId, roleId)
    opt 单端登录互斥 (!MultiLogin)
        JWT->>Redis: Lua 脚本 (GET + SETEX td:{u:userId}:cs)
        Redis-->>JWT: 返回 oldSid
        JWT->>Redis: SET td:{u:userId}:s:oldSid = "kicked" (旧端失效)
    end
    JWT-->>Svc: 返回 JwtToken (AccessToken + RefreshToken)
    Svc-->>Client: 下发 Token (Web端写 HttpOnly Cookie)

    Note over Client,Redis: 2. 业务请求鉴权流程 (Parse via Lua)
    Client->>AuthMW: GET /api/demo/info (Header: Bearer <token>)
    AuthMW->>JWT: Parse(ctx, tokenStr)
    JWT->>JWT: 本地密码学验签 (HS384) + 进程内存过期短路
    JWT->>Redis: EVALSHA checkTokenScript (带 {u:userId} Hash Tag)
    Redis-->>JWT: 返回状态码 (0:放行 / 1:作废 / 2:封号 / 3:被踢或强制下线)
    JWT-->>AuthMW: 校验通过，返回 Claims
    AuthMW-->>Client: 200 OK (业务数据)

    Note over Client,Redis: 3. 双 Token 轮换刷新流程 (Refresh)
    Client->>Svc: POST /api/demo/refresh (携带双 Token)
    Svc->>JWT: RefreshToken(ctx, accessToken, refreshToken)
    JWT->>JWT: 双密钥独立验签 & 校验 access.SID == refresh.SID
    JWT->>Redis: SETNX td:{u:userId}:t:hash(refresh) (原子抢占)
    alt 抢占成功 (正常轮换)
        JWT->>Redis: SET td:{u:userId}:rot:hash(refresh) (宽限期缓存30s)
        JWT->>JWT: 启动 AfterFunc 异步协程(带 recover 守护，10s 后作废旧 accessToken)
        JWT-->>Svc: 返回新 Token 族
    else 抢占失败 (并发请求或重放)
        JWT->>Redis: 阶梯微退避轮询 td:{u:userId}:rot:hash(refresh)
        alt 命中宽限期缓存 (并发刷新)
            Redis-->>JWT: 返回已生成的新 Token (安全复用)
        else 宽限期外重放 (凭据泄露攻击)
            JWT->>Redis: SET td:{u:userId}:s:sid = "compromised" (熔断吊销整族)
            JWT-->>Svc: 返回 ErrRevokedToken
        end
    end
    Svc-->>Client: 刷新成功，同步更新凭证

    Note over Client,Redis: 4. 主动登出流程 (Logout)
    Client->>Svc: POST /api/demo/logout
    Svc->>JWT: DisuseSession(ctx, sid, ttl)
    JWT->>Redis: SET td:{u:userId}:s:sid = "logout" (双 Token 连带失效)
    JWT->>Redis: 清理单端活跃记录 td:{u:userId}:cs
    Svc-->>Client: 登出成功，清除本地 Cookie
```

---

## 五、配置参数说明与错误码映射

### 1. 核心配置 (`config/local.yml` / `release.yml`)

```yaml
token:
  secret: "123456ABCDEFGHIJKLMNOPQRSTUVWXYZ384bit_access_key"   # AccessToken 专用密钥 (>=32字节)
  refreshSecret: "abcdefghijklmnopqrstuvwxyz123456384bit_ref_key" # RefreshToken 专用密钥 (禁止与 secret 相同)
  csrfKey: "abcdefghijklmnopqrstuvwxyz123456"                   # CSRF 防跨站攻击密钥 (固定32字节)
  expire: 7200        # AccessToken 过期时间 (秒, 默认2小时)
  refresh: 604800     # RefreshToken 单次过期时间 (秒, 默认7天)
  maxRefresh: 2592000 # 绝对最大有效期 (秒, 默认30天, 超过后必须重新输入密码认证)
  gracePeriod: 30     # 轮换宽限期 (秒, 默认30秒, 防并发刷新误杀)
  queryKey: "Authorization" # Token 查找键 (Header/Cookie/Query)
  multiLogin: false   # 是否允许多端登录 (false: 单端互斥被顶下线; true: 多端共存)
```

### 2. 错误码与客户端处理规范

| 错误码 | 错误常量 | 提示信息 | HTTP 状态码 | 客户端建议处理方式 |
| :--- | :--- | :--- | :--- | :--- |
| `2001` | `Unauthorized` | 未知授权信息 / 用户未登录 | `401` | 引导跳转至登录页面 |
| `2002` | `AuthError` | 授权信息错误 / 签名非法 / 格式损坏 | `401` | 清理本地凭证，引导重新登录 |
| `2003` | `AuthTimeOut` | 授权信息超时 (AccessToken 过期) | `401` | 拦截器透明调用无感刷新接口 `/api/demo/refresh` |
| `2004` | `AuthRefreshErr` | 刷新 Token 失败 / 凭据泄露熔断 | `401` | 凭证已彻底失效，清理本地缓存并退出登录 |
| `2007` | `AuthKickedOut` | 账号已在其他设备登录 / 强制下线 | `401` | 弹出“您的账号已在其他设备登录”提示框，确认后跳转登录页 |
| `2008` | `UserBanned` | 账号已被封禁 | `401` | 弹出封禁提示窗口并展示具体原因，禁止后续操作 |
