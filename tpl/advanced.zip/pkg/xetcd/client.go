/**
 * @Author: spruce
 * @Date: 2026-09-29 16:18
 * @Desc: etcd 客户端与连接池管理
 */

package xetcd

import (
	"context"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
)

// Client 包装 clientv3.Client，记录归一化端点与上次健康检查时间。
type Client struct {
	*clientv3.Client

	endpoints       string    // 归一化后的地址键，供池在失效时定位并剔除
	username        string    // 认证用户名
	lastHealthCheck time.Time // 上次健康检查时间
	mu              sync.Mutex
}

// defaultDialTimeout 默认 etcd 拨号超时。
const defaultDialTimeout = 5 * time.Second

// defaultHealthCheckInterval 默认健康检查间隔；超过此时长未检查则自动执行 Status ping。
const defaultHealthCheckInterval = 30 * time.Second

// newRawClient 构造一个 etcd client 并 Ping 校验首端点可达。
// 供 ClientPool.Get、NewWatcher、NewRegistrar 等复用。username 为空则不启用认证。
// Status ping 失败时仍返回 client（仅告警），因为实际读写操作会携带凭据；
// 这样可避免 etcd 开启认证但环境单元格未配置用户名时，健康检查阻塞所有操作。
func newRawClient(endpoints []string, timeout time.Duration, username, password string) (*clientv3.Client, error) {
	if len(endpoints) == 0 {
		return nil, fmt.Errorf("etcd endpoints empty")
	}
	if timeout == 0 {
		timeout = defaultDialTimeout
	}
	cfg := clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: timeout,
	}
	if username != "" {
		cfg.Username = username
		cfg.Password = password
	}
	cli, err := clientv3.New(cfg)
	if err != nil {
		return nil, err
	}
	// Ping etcd using status — 非致命检查，失败仅告警
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	_, err = cli.Status(ctx, endpoints[0])
	if err != nil {
		pkgLogger("[xetcd] endpoint %s status check failed: %v (client returned anyway)", endpoints[0], err)
	}
	return cli, nil
}

// flightCall 单飞调用包装，用于合并并发健康检查与建连请求，防止惊群/击穿。
type flightCall struct {
	wg  sync.WaitGroup
	c   *Client
	err error
}

// ClientPool 按 etcd 地址集合+用户名缓存复用 *Client。
// 相同 endpoints（无论顺序/空白）+ 相同 username 共享同一 client，避免反复建连。
// 内部使用 singleflight 合并并发请求，杜绝健康检查击穿与并发重复建连。
type ClientPool struct {
	timeout             time.Duration
	healthCheckInterval time.Duration

	mu      sync.RWMutex
	clients map[string]*Client

	flightMu sync.Mutex
	flight   map[string]*flightCall
}

// NewClientPool 构造地址+用户 → client 缓存池。
// 支持零参数调用 NewClientPool()，或传入自定义 logger（如 *zap.Logger 等）。
func NewClientPool(logger ...any) *ClientPool {
	return &ClientPool{
		timeout:             defaultDialTimeout,
		healthCheckInterval: defaultHealthCheckInterval,
		clients:             make(map[string]*Client),
		flight:              make(map[string]*flightCall),
	}
}

// SetHealthCheckInterval 设置健康检查间隔。传入 0 禁用健康检查。
func (p *ClientPool) SetHealthCheckInterval(d time.Duration) {
	if d < 0 {
		d = defaultHealthCheckInterval
	}
	p.healthCheckInterval = d
}

// Get 按 endpoints + username 取复用 client。
// 命中缓存且距上次健康检查超过间隔时执行 Status ping，校验失败则自动重建连接。
// 并发请求时自动合并，防止击穿。
func (p *ClientPool) Get(endpoints []string, username, password string) (*Client, error) {
	key := normalizeEndpoints(endpoints, username)
	if key == "" {
		return nil, fmt.Errorf("etcd endpoints empty")
	}

	p.mu.RLock()
	c, ok := p.clients[key]
	if ok {
		// 检查是否需要健康检查
		needCheck := false
		if p.healthCheckInterval > 0 {
			c.mu.Lock()
			needCheck = time.Since(c.lastHealthCheck) > p.healthCheckInterval
			c.mu.Unlock()
		}
		if !needCheck {
			p.mu.RUnlock()
			return c, nil
		}
	}
	p.mu.RUnlock()

	// 命中需要健康检查或未命中时，使用 singleflight 合并并发建连/ping 请求
	p.flightMu.Lock()
	if call, inFlight := p.flight[key]; inFlight {
		p.flightMu.Unlock()
		call.wg.Wait()
		return call.c, call.err
	}
	call := new(flightCall)
	call.wg.Add(1)
	p.flight[key] = call
	p.flightMu.Unlock()

	call.c, call.err = p.doGet(key, username, password)
	call.wg.Done()

	p.flightMu.Lock()
	delete(p.flight, key)
	p.flightMu.Unlock()

	return call.c, call.err
}

func (p *ClientPool) doGet(key, username, password string) (*Client, error) {
	eps := splitEndpoints(key)
	if len(eps) == 0 {
		return nil, fmt.Errorf("invalid endpoints for %s", key)
	}

	p.mu.RLock()
	c, ok := p.clients[key]
	p.mu.RUnlock()

	if ok {
		// 执行 Status ping
		firstEndpoint := eps[0]
		ctx, cancel := context.WithTimeout(context.Background(), p.timeout)
		_, err := c.Status(ctx, firstEndpoint)
		cancel()
		if err == nil {
			c.mu.Lock()
			c.lastHealthCheck = time.Now()
			c.mu.Unlock()
			return c, nil
		}
		// 校验失败，剔除旧连接
		p.Invalidate(eps, username)
		pkgLogger("[xetcd] health check failed for %s, reconnecting: %v", key, err)
	}

	// 建立新连接
	raw, err := newRawClient(eps, p.timeout, username, password)
	if err != nil {
		pkgLogger("[xetcd] client connect failed for %s: %v", key, err)
		return nil, err
	}
	c = &Client{Client: raw, endpoints: key, username: username, lastHealthCheck: time.Now()}

	p.mu.Lock()
	if existing, found := p.clients[key]; found {
		p.mu.Unlock()
		_ = raw.Close()
		return existing, nil
	}
	p.clients[key] = c
	p.mu.Unlock()

	pkgLogger("[xetcd] client established for %s", key)
	return c, nil
}

// Invalidate 剔除指定地址集合+用户的缓存 client 并关闭底层连接。
func (p *ClientPool) Invalidate(endpoints []string, username string) {
	key := normalizeEndpoints(endpoints, username)
	if key == "" {
		return
	}
	p.mu.Lock()
	c, ok := p.clients[key]
	if ok {
		delete(p.clients, key)
	}
	p.mu.Unlock()
	if ok {
		_ = c.Client.Close()
		pkgLogger("[xetcd] client invalidated for %s", key)
	}
}

// Close 关闭池中所有 client。供进程退出时调用。
func (p *ClientPool) Close() {
	p.mu.Lock()
	defer p.mu.Unlock()
	for key, c := range p.clients {
		_ = c.Client.Close()
		delete(p.clients, key)
	}
}

// normalizeEndpoints 将地址切片+用户名归一为稳定的缓存键：去空、去前后空白、排序、逗号拼接。
func normalizeEndpoints(endpoints []string, username string) string {
	cleaned := make([]string, 0, len(endpoints))
	for _, e := range endpoints {
		e = strings.TrimSpace(e)
		if e != "" {
			cleaned = append(cleaned, e)
		}
	}
	sort.Strings(cleaned)
	addr := strings.Join(cleaned, ",")
	if addr == "" {
		return ""
	}
	if username != "" {
		return username + "@" + addr
	}
	return addr
}

// splitEndpoints 将归一键拆回地址切片。如果键含 "@" 前缀（username@hosts），则去掉用户名部分。
func splitEndpoints(key string) []string {
	if key == "" {
		return nil
	}
	if idx := strings.Index(key, "@"); idx >= 0 {
		key = key[idx+1:]
	}
	return strings.Split(key, ",")
}
