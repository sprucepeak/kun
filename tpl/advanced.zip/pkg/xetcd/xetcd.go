package xetcd

import (
	"context"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"go.etcd.io/etcd/api/v3/mvccpb"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.uber.org/zap"
)

// ============================================================================
// 1. Client & ClientPool (多集群客户端连接池与健康检查 - 服务端管理视角)
// ============================================================================

type Client struct {
	*clientv3.Client

	endpoints       string    // 归一化后的地址键，供池在失效时定位并剔除
	username        string    // 认证用户名
	lastHealthCheck time.Time // 上次健康检查时间
	mu              sync.Mutex
}

// defaultDialTimeout 默认 etcd 拨号超时。
const defaultDialTimeout = 5 * time.Second

// defaultHealthCheckInterval 默认健康检查间隔；超过此时长未检查则自动执行 Status ping。
const defaultHealthCheckInterval = 30 * time.Second

// newRawClient 构造一个 etcd client 并 Ping 校验首端点可达。
// 供 ClientPool.Get 复用。username 为空则不启用认证。
// Status ping 失败时仍返回 client（仅告警），因为实际读写操作会携带凭据；
// 这样可避免 etcd 开启认证但环境单元格未配置用户名时，健康检查阻塞所有操作。
func newRawClient(endpoints []string, timeout time.Duration, logger *zap.Logger, username, password string) (*clientv3.Client, error) {
	if len(endpoints) == 0 {
		return nil, fmt.Errorf("etcd endpoints empty")
	}
	if timeout == 0 {
		timeout = defaultDialTimeout
	}
	cfg := clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: timeout,
	}
	if username != "" {
		cfg.Username = username
		cfg.Password = password
	}
	cli, err := clientv3.New(cfg)
	if err != nil {
		return nil, err
	}
	// Ping etcd using status — 非致命检查，失败仅告警
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	_, err = cli.Status(ctx, endpoints[0])
	if err != nil {
		if logger != nil {
			logger.Sugar().Warnf("etcd endpoint %s status check failed: %v", endpoints[0], err)
		} else {
			zap.L().Sugar().Warnf("etcd endpoint %s status check failed: %v (client returned anyway)", endpoints[0], err)
		}
	}
	return cli, nil
}

// flightCall 单飞调用包装，用于合并并发健康检查与建连请求，防止惊群/击穿。
type flightCall struct {
	wg  sync.WaitGroup
	c   *Client
	err error
}

// ClientPool 按 etcd 地址集合+用户名缓存复用 *Client。
// 相同 endpoints（无论顺序/空白）+ 相同 username 共享同一 client，避免反复建连。
// 内部使用 singleflight 合并并发请求，杜绝健康检查击穿与并发重复建连。
type ClientPool struct {
	logger              *zap.Logger
	timeout             time.Duration
	healthCheckInterval time.Duration

	mu      sync.RWMutex
	clients map[string]*Client

	flightMu sync.Mutex
	flight   map[string]*flightCall
}

// NewClientPool 构造地址+用户 → client 缓存池。
func NewClientPool(logger *zap.Logger) *ClientPool {
	return &ClientPool{
		logger:              logger,
		timeout:             defaultDialTimeout,
		healthCheckInterval: defaultHealthCheckInterval,
		clients:             make(map[string]*Client),
		flight:              make(map[string]*flightCall),
	}
}

func (p *ClientPool) log() *zap.Logger {
	if p.logger != nil {
		return p.logger
	}
	return zap.L()
}

// SetHealthCheckInterval 设置健康检查间隔。传入 0 禁用健康检查。
func (p *ClientPool) SetHealthCheckInterval(d time.Duration) {
	if d < 0 {
		d = defaultHealthCheckInterval
	}
	p.healthCheckInterval = d
}

// Get 按 endpoints + username 取复用 client。
// 命中缓存且距上次健康检查超过间隔时执行 Status ping，校验失败则自动重建连接。
// 并发请求时自动合并，防止击穿。
func (p *ClientPool) Get(endpoints []string, username, password string) (*Client, error) {
	key := normalizeEndpoints(endpoints, username)
	if key == "" {
		return nil, fmt.Errorf("etcd endpoints empty")
	}

	p.mu.RLock()
	c, ok := p.clients[key]
	if ok {
		// 检查是否需要健康检查
		needCheck := false
		if p.healthCheckInterval > 0 {
			c.mu.Lock()
			needCheck = time.Since(c.lastHealthCheck) > p.healthCheckInterval
			c.mu.Unlock()
		}
		if !needCheck {
			p.mu.RUnlock()
			return c, nil
		}
	}
	p.mu.RUnlock()

	// 命中需要健康检查或未命中时，使用 singleflight 合并并发建连/ping 请求
	p.flightMu.Lock()
	if call, inFlight := p.flight[key]; inFlight {
		p.flightMu.Unlock()
		call.wg.Wait()
		return call.c, call.err
	}
	call := new(flightCall)
	call.wg.Add(1)
	p.flight[key] = call
	p.flightMu.Unlock()

	call.c, call.err = p.doGet(key, username, password)
	call.wg.Done()

	p.flightMu.Lock()
	delete(p.flight, key)
	p.flightMu.Unlock()

	return call.c, call.err
}

func (p *ClientPool) doGet(key, username, password string) (*Client, error) {
	p.mu.RLock()
	c, ok := p.clients[key]
	p.mu.RUnlock()

	if ok {
		// 执行 Status ping
		firstEndpoint := splitEndpoints(key)[0]
		ctx, cancel := context.WithTimeout(context.Background(), p.timeout)
		_, err := c.Status(ctx, firstEndpoint)
		cancel()
		if err == nil {
			c.mu.Lock()
			c.lastHealthCheck = time.Now()
			c.mu.Unlock()
			return c, nil
		}
		// 校验失败，剔除旧连接
		p.Invalidate(splitEndpoints(key), username)
		p.log().Warn(fmt.Sprintf("etcd health check failed for %s, reconnecting: %v", key, err),
			zap.String("key", key),
			zap.Error(err),
		)
	}

	// 建立新连接
	raw, err := newRawClient(splitEndpoints(key), p.timeout, p.logger, username, password)
	if err != nil {
		p.log().Warn(fmt.Sprintf("etcd client connect failed for %s: %v", key, err),
			zap.String("key", key),
			zap.Error(err),
		)
		return nil, err
	}
	c = &Client{Client: raw, endpoints: key, username: username, lastHealthCheck: time.Now()}

	p.mu.Lock()
	if existing, found := p.clients[key]; found {
		p.mu.Unlock()
		_ = raw.Close()
		return existing, nil
	}
	p.clients[key] = c
	p.mu.Unlock()

	p.log().Info(fmt.Sprintf("etcd client established for %s", key), zap.String("key", key))
	return c, nil
}

// Invalidate 剔除指定地址集合+用户的缓存 client 并关闭底层连接。
func (p *ClientPool) Invalidate(endpoints []string, username string) {
	key := normalizeEndpoints(endpoints, username)
	if key == "" {
		return
	}
	p.mu.Lock()
	c, ok := p.clients[key]
	if ok {
		delete(p.clients, key)
	}
	p.mu.Unlock()
	if ok {
		_ = c.Client.Close()
		p.log().Info(fmt.Sprintf("etcd client invalidated for %s", key), zap.String("key", key))
	}
}

// Close 关闭池中所有 client。供进程退出时调用。
func (p *ClientPool) Close() {
	p.mu.Lock()
	defer p.mu.Unlock()
	for key, c := range p.clients {
		_ = c.Client.Close()
		delete(p.clients, key)
	}
}

// normalizeEndpoints 将地址切片+用户名归一为稳定的缓存键：去空、去前后空白、排序、逗号拼接。
func normalizeEndpoints(endpoints []string, username string) string {
	cleaned := make([]string, 0, len(endpoints))
	for _, e := range endpoints {
		e = strings.TrimSpace(e)
		if e != "" {
			cleaned = append(cleaned, e)
		}
	}
	sort.Strings(cleaned)
	addr := strings.Join(cleaned, ",")
	if addr == "" {
		return ""
	}
	if username != "" {
		return username + "@" + addr
	}
	return addr
}

// splitEndpoints 将归一键拆回地址切片。如果键含 "@" 前缀（username@hosts），则去掉用户名部分。
func splitEndpoints(key string) []string {
	if key == "" {
		return nil
	}
	if idx := strings.Index(key, "@"); idx >= 0 {
		key = key[idx+1:]
	}
	return strings.Split(key, ",")
}

// ============================================================================
// 2. Watcher (配置动态监听与只读缓存 - 客户端订阅视角)
// ============================================================================

// WatcherOption 配置 Watcher 选项。
type WatcherOption func(*Watcher)

// WithWatcherLogger 为 Watcher 配置自定义 zap.Logger。
func WithWatcherLogger(l *zap.Logger) WatcherOption {
	return func(w *Watcher) {
		if l != nil {
			w.logger = l
		}
	}
}

// Watcher 通过 etcd Watch 实时同步配置变更。
// 一次 Watch 监听整个环境前缀，业务侧按 (group, dataId) 取值。
// 支持网络闪断自愈、全量重同步、Revision 连续监听以及优雅关闭。
// goroutine-safe。
type Watcher struct {
	cli      *clientv3.Client
	logger   *zap.Logger
	mu       sync.RWMutex
	data     map[string]*ConfigValue // key: "{group}/{dataId}"
	onChange func()

	ctx    context.Context
	cancel context.CancelFunc
	wg     sync.WaitGroup
}

func (w *Watcher) log() *zap.Logger {
	if w.logger != nil {
		return w.logger
	}
	return zap.L()
}

// SetOnChange 注册配置变更时的回调函数（热重载触发）。
func (w *Watcher) SetOnChange(fn func()) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.onChange = fn
}

// SetLogger 设置自定义日志记录器。
func (w *Watcher) SetLogger(l *zap.Logger) {
	if l != nil {
		w.logger = l
	}
}

// NewWatcher 创建配置 watcher。
func NewWatcher(endpoints []string, etcdUsername, etcdPassword string, opts ...WatcherOption) (*Watcher, error) {
	if len(endpoints) == 0 {
		return nil, fmt.Errorf("etcd endpoints empty")
	}

	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: 5 * time.Second,
		Username:    etcdUsername,
		Password:    etcdPassword,
		Logger:      zap.L().Named("etcd"),
	})
	if err != nil {
		zap.L().Error(fmt.Sprintf("[xetcd] connect etcd failed: %v (endpoints=%v)", err, endpoints),
			zap.Strings("endpoints", endpoints),
			zap.Error(err),
		)
		return nil, fmt.Errorf("connect etcd failed: %w", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	w := &Watcher{
		cli:    cli,
		data:   make(map[string]*ConfigValue),
		ctx:    ctx,
		cancel: cancel,
	}
	for _, opt := range opts {
		opt(w)
	}

	w.log().Info(fmt.Sprintf("[xetcd] connected to %v (auth=%v)", endpoints, etcdUsername != ""),
		zap.Strings("endpoints", endpoints),
		zap.Bool("auth", etcdUsername != ""),
	)
	return w, nil
}

// Watch 开始监听整个环境的配置：一次性 Watch 前缀 /{project}/config/content/{env}/
// 首次调用立即拉取前缀下全部配置；之后启动带自愈重连的后台协程监听配置变更，
// 并使用 Revision + 1 增量监听，彻底杜绝数据在拉取与监听窗口期丢失。
func (w *Watcher) Watch(ctx context.Context, project, env string) error {
	prefix := fmt.Sprintf("/%s/config/content/%s/", project, env)
	w.log().Info(fmt.Sprintf("[xetcd] start watching prefix %s", prefix),
		zap.String("prefix", prefix),
	)

	resp, err := w.cli.Get(ctx, prefix, clientv3.WithPrefix())
	if err != nil {
		w.log().Error(fmt.Sprintf("[xetcd] initial get failed under %s: %v", prefix, err),
			zap.String("prefix", prefix),
			zap.Error(err),
		)
		return fmt.Errorf("etcd get failed: %w", err)
	}
	w.mu.Lock()
	for _, kv := range resp.Kvs {
		w.upsert(string(kv.Key), kv.Value)
	}
	w.mu.Unlock()
	w.log().Info(fmt.Sprintf("[xetcd] loaded %d config(s) under %s", len(resp.Kvs), prefix),
		zap.String("prefix", prefix),
		zap.Int("count", len(resp.Kvs)),
	)

	startRev := resp.Header.Revision + 1

	w.wg.Add(1)
	go func() {
		defer w.wg.Done()
		w.watchLoop(ctx, prefix, startRev)
	}()

	return nil
}

func (w *Watcher) watchLoop(userCtx context.Context, prefix string, startRev int64) {
	currentRev := startRev
	backoff := time.Second
	const maxBackoff = 10 * time.Second

	for {
		select {
		case <-userCtx.Done():
			w.log().Info(fmt.Sprintf("[xetcd] watch stopped by user context: %s", prefix))
			return
		case <-w.ctx.Done():
			w.log().Info(fmt.Sprintf("[xetcd] watcher closed, stopping watch: %s", prefix))
			return
		default:
		}

		opts := []clientv3.OpOption{clientv3.WithPrefix()}
		if currentRev > 0 {
			opts = append(opts, clientv3.WithRev(currentRev))
		}

		watchCtx, cancelWatch := context.WithCancel(w.ctx)
		ch := w.cli.Watch(watchCtx, prefix, opts...)

		for wresp := range ch {
			if wresp.Canceled || wresp.Err() != nil {
				w.log().Warn(fmt.Sprintf("[xetcd] watch error for %s: %v", prefix, wresp.Err()),
					zap.Error(wresp.Err()),
				)
				break
			}

			if wresp.Header.Revision >= currentRev {
				currentRev = wresp.Header.Revision + 1
			}

			var hasChange bool
			w.mu.Lock()
			for _, ev := range wresp.Events {
				switch ev.Type {
				case mvccpb.PUT:
					w.upsert(string(ev.Kv.Key), ev.Kv.Value)
					hasChange = true
				case mvccpb.DELETE:
					w.remove(string(ev.Kv.Key))
					hasChange = true
				}
			}
			onChangeFn := w.onChange
			w.mu.Unlock()

			if hasChange && onChangeFn != nil {
				w.log().Info("[xetcd] config updated, triggering onChange callback")
				onChangeFn()
			}

			backoff = time.Second
		}
		cancelWatch()

		// 检查是否主动退出
		select {
		case <-userCtx.Done():
			return
		case <-w.ctx.Done():
			return
		default:
		}

		w.log().Warn(fmt.Sprintf("[xetcd] watch channel closed for %s, reconnecting in %v...", prefix, backoff),
			zap.String("prefix", prefix),
			zap.Duration("backoff", backoff),
		)

		select {
		case <-time.After(backoff):
		case <-userCtx.Done():
			return
		case <-w.ctx.Done():
			return
		}

		backoff *= 2
		if backoff > maxBackoff {
			backoff = maxBackoff
		}

		// 断线重连后全量重新同步，弥补离线期间遗漏的变更
		syncCtx, syncCancel := context.WithTimeout(w.ctx, 5*time.Second)
		syncResp, err := w.cli.Get(syncCtx, prefix, clientv3.WithPrefix())
		syncCancel()
		if err != nil {
			w.log().Error(fmt.Sprintf("[xetcd] sync after reconnect failed for %s: %v", prefix, err),
				zap.Error(err),
			)
			continue
		}

		w.mu.Lock()
		currentKeys := make(map[string]struct{}, len(syncResp.Kvs))
		for _, kv := range syncResp.Kvs {
			keyStr := string(kv.Key)
			group, dataId, ok := ParseConfigKey(keyStr)
			if ok {
				currentKeys[group+"/"+dataId] = struct{}{}
			}
			w.upsert(keyStr, kv.Value)
		}
		// 移除 etcd 中已删除的 key
		for cachedKey := range w.data {
			if _, exists := currentKeys[cachedKey]; !exists {
				delete(w.data, cachedKey)
			}
		}
		onChangeFn := w.onChange
		w.mu.Unlock()

		currentRev = syncResp.Header.Revision + 1
		w.log().Info(fmt.Sprintf("[xetcd] re-synced %d config(s) under %s", len(syncResp.Kvs), prefix),
			zap.String("prefix", prefix),
			zap.Int("count", len(syncResp.Kvs)),
		)
		if onChangeFn != nil {
			onChangeFn()
		}
	}
}

func (w *Watcher) upsert(key string, val []byte) {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return
	}
	v, err := DecodeConfigValue(string(val))
	if err != nil {
		w.log().Error(fmt.Sprintf("[xetcd] decode config failed: key=%s err=%v", key, err),
			zap.String("key", key),
			zap.Error(err),
		)
		return
	}
	w.data[group+"/"+dataId] = v
	w.log().Info(fmt.Sprintf("[xetcd] loaded %s/%s (version=%d, format=%s, size=%d)", group, dataId, v.Version, v.Format, len(v.Content)),
		zap.String("group", group),
		zap.String("dataId", dataId),
		zap.Int32("version", v.Version),
		zap.String("format", v.Format),
		zap.Int("size", len(v.Content)),
	)
}

func (w *Watcher) remove(key string) {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return
	}
	delete(w.data, group+"/"+dataId)
	w.log().Info(fmt.Sprintf("[xetcd] removed %s/%s", group, dataId),
		zap.String("group", group),
		zap.String("dataId", dataId),
	)
}

// Get 读取已缓存的配置值。goroutine-safe。
func (w *Watcher) Get(group, dataId string) *ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	return w.data[group+"/"+dataId]
}

// GetContent 返回配置内容字符串（快捷方法）。
func (w *Watcher) GetContent(group, dataId string) string {
	if v := w.Get(group, dataId); v != nil {
		return v.Content
	}
	return ""
}

// All 返回当前缓存的所有配置项（快照副本）。goroutine-safe。
func (w *Watcher) All() map[string]*ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	out := make(map[string]*ConfigValue, len(w.data))
	for k, v := range w.data {
		out[k] = v
	}
	return out
}

// Close 关闭 watcher 监听与 etcd 连接。
func (w *Watcher) Close() error {
	w.log().Info("[xetcd] closing watcher connection")
	w.cancel()
	w.wg.Wait()
	return w.cli.Close()
}

// Scan 将已缓存的配置内容按 format（yaml/json/properties）反序列化到 out。
func (w *Watcher) Scan(group, dataId string, out any) error {
	v := w.Get(group, dataId)
	if v == nil {
		return fmt.Errorf("config %s/%s not found, did you call Watch?", group, dataId)
	}
	if out == nil {
		return fmt.Errorf("out must not be nil")
	}
	return UnmarshalConfigContent(v.Format, v.Content, out)
}

// ============================================================================
// 3. Dynamic Values (动态配置项封装)
// ============================================================================

// DynamicString 一个热更新的字符串配置项。
type DynamicString struct {
	watcher *Watcher
	group   string
	dataId  string
}

// NewDynamicString 创建监听指定配置项的动态字符串。
func (w *Watcher) NewDynamicString(group, dataId string) *DynamicString {
	return &DynamicString{watcher: w, group: group, dataId: dataId}
}

// Val 返回最新配置值。
func (d *DynamicString) Val() string {
	return d.watcher.GetContent(d.group, d.dataId)
}

// DynamicInt 一个热更新的整数配置项。
type DynamicInt struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal int
}

// NewDynamicInt 创建监听指定配置项的动态整数。
func (w *Watcher) NewDynamicInt(group, dataId string, defaultVal int) *DynamicInt {
	return &DynamicInt{watcher: w, group: group, dataId: dataId, defaultVal: defaultVal}
}

// Val 返回最新整数值，解析失败时返回 defaultVal。
func (d *DynamicInt) Val() int {
	str := d.watcher.GetContent(d.group, d.dataId)
	if str == "" {
		return d.defaultVal
	}
	val, err := strconv.Atoi(strings.TrimSpace(str))
	if err != nil {
		return d.defaultVal
	}
	return val
}

// DynamicBool 一个热更新的布尔配置项。
type DynamicBool struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal bool
}

// NewDynamicBool 创建监听指定配置项的动态布尔值。
func (w *Watcher) NewDynamicBool(group, dataId string, defaultVal bool) *DynamicBool {
	return &DynamicBool{watcher: w, group: group, dataId: dataId, defaultVal: defaultVal}
}

// Val 返回最新布尔值，解析失败时返回 defaultVal。
func (d *DynamicBool) Val() bool {
	str := d.watcher.GetContent(d.group, d.dataId)
	if str == "" {
		return d.defaultVal
	}
	val, err := strconv.ParseBool(strings.TrimSpace(str))
	if err != nil {
		return d.defaultVal
	}
	return val
}

// DynamicDuration 一个热更新的时间间隔配置项。
type DynamicDuration struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal time.Duration
}

// NewDynamicDuration 创建监听指定配置项的动态时间间隔。
func (w *Watcher) NewDynamicDuration(group, dataId string, defaultVal time.Duration) *DynamicDuration {
	return &DynamicDuration{watcher: w, group: group, dataId: dataId, defaultVal: defaultVal}
}

// Val 返回最新时间间隔值，解析失败时返回 defaultVal。
func (d *DynamicDuration) Val() time.Duration {
	str := d.watcher.GetContent(d.group, d.dataId)
	if str == "" {
		return d.defaultVal
	}
	val, err := time.ParseDuration(strings.TrimSpace(str))
	if err != nil {
		return d.defaultVal
	}
	return val
}

// DynamicValue 泛型动态配置项，当内容变更时自动反序列化为结构体/复杂对象并本地缓存。
type DynamicValue[T any] struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal T
	mu         sync.RWMutex
	lastRaw    string
	cached     T
}

// NewDynamicValue 创建泛型动态配置对象。
func NewDynamicValue[T any](w *Watcher, group, dataId string, defaultVal T) *DynamicValue[T] {
	return &DynamicValue[T]{
		watcher:    w,
		group:      group,
		dataId:     dataId,
		defaultVal: defaultVal,
		cached:     defaultVal,
	}
}

// Val 返回解析后的最新配置对象（并发安全且带本地缓存）。
func (d *DynamicValue[T]) Val() T {
	cv := d.watcher.Get(d.group, d.dataId)
	if cv == nil {
		return d.defaultVal
	}

	d.mu.RLock()
	if cv.Content == d.lastRaw {
		val := d.cached
		d.mu.RUnlock()
		return val
	}
	d.mu.RUnlock()

	d.mu.Lock()
	defer d.mu.Unlock()
	if cv.Content == d.lastRaw {
		return d.cached
	}

	var parsed T
	if err := UnmarshalConfigContent(cv.Format, cv.Content, &parsed); err != nil {
		return d.defaultVal
	}
	d.cached = parsed
	d.lastRaw = cv.Content
	return d.cached
}
