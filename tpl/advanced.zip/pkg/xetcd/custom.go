/**
 * @Author: spruce
 * @Date: 2026-09-30 09:25
 * @Desc: xetcd 框架级自定义配置中心
 *
 * 使用说明：
 * 4 个工程共用本文件模板。每个工程为一个完整独立的注释区块（包含 import 与实现）。
 * 跨工程迁移时，只需【整块取消/添加注释】，仅需操作一处，无需上下翻找！
 */

package xetcd

// ============================================================================
// 1. 【go-zero 工程专用】
// 特性：自动桥接 go-zero logx 日志系统 + zrpc 权重负载均衡器
// 启用：取消本区块注释，将其他区块整块注释
// ============================================================================

//import (
//	"github.com/zeromicro/go-zero/core/logx"
//	"github.com/zeromicro/go-zero/zrpc"
//)
//
//var pkgLogger func(format string, args ...any) = func(format string, args ...any) {
//	logx.Infof(format, args...)
//}
//
//// WithWeightedBalancer 将 RpcClientConf 配置为使用 Alaya 加权 p2c 负载均衡器。
//// 自动读取实例权重（weight）进行加权路由，权重为 0 的实例不参与流量分配。
//func WithWeightedBalancer(conf zrpc.RpcClientConf) zrpc.RpcClientConf {
//	conf.BalancerName = BalancerName
//	return conf
//}

// ============================================================================
// 2. 【kun工程/zap库 专用】
// 特性：自动桥接 Zap 结构化日志系统
// 启用：取消本区块注释，将其他区块整块注释
// ============================================================================

import "go.uber.org/zap"

var pkgLogger func(format string, args ...any) = func(format string, args ...any) {
	zap.L().Sugar().Infof(format, args...)
}

// ============================================================================
// 3. 【log 标准库 专用】
// 特性：纯标准库 log.Printf，零额外第三方依赖
// 启用：取消本区块注释，将其他区块整块注释
// ============================================================================

//import "log"
//
//var pkgLogger func(format string, args ...any) = log.Printf
