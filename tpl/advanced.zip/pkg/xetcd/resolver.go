/**
 * @Author: spruce
 * @Date: 2026-09-29 16:18
 * @Desc: gRPC 服务发现解析器与加权负载均衡器
 */

// resolver.go 提供 Alaya 与 go-zero zrpc 之间的桥接。
//
// 实现 gRPC 标准 resolver.Builder，让 go-zero 的 zrpc 客户端
// 按 Alaya 的 etcd 前缀 Watch 实例、解析 InstanceInfo，从而调用层完全复用
// go-zero 原生 zrpc（负载均衡、拦截器、超时等），发现层桥接 Alaya 格式。
//
// 支持版本过滤和权重路由。

package xetcd

import (
	"context"
	"fmt"
	"math"
	"math/rand"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"google.golang.org/grpc/attributes"
	"google.golang.org/grpc/balancer"
	"google.golang.org/grpc/balancer/base"
	"google.golang.org/grpc/resolver"
)

// Attributes keys 传递给 gRPC Address 用于版本路由和权重路由。
const (
	attrKeyVersion = "alaya.version"
	attrKeyWeight  = "alaya.weight"
)

// TargetOption 用于 Target 函数的可选参数。
type TargetOption func(*targetOptions)

type targetOptions struct {
	// Version 指定目标版本，只选匹配该版本的实例。空字符串表示不限制。
	Version string
}

// WithVersion 指定目标版本，仅路由该版本的实例。
func WithVersion(version string) TargetOption {
	return func(o *targetOptions) {
		o.Version = version
	}
}

var (
	// 全局 etcd client，由 main 在启动时通过 SetEtcdClient 注入。
	etcdCli *clientv3.Client
	etcdMu  sync.RWMutex
)

// SetEtcdClient 注入 Alaya resolver 使用的 etcd client。
func SetEtcdClient(cli *clientv3.Client) {
	etcdMu.Lock()
	etcdCli = cli
	etcdMu.Unlock()
}

func getEtcdClient() *clientv3.Client {
	etcdMu.RLock()
	defer etcdMu.RUnlock()
	return etcdCli
}

// Target 构造 Alaya resolver 的 target 字符串。
// 约定格式：{project}/{env}/{serviceName}（无需 scheme 前缀，走 gRPC 默认 scheme）
//
// 可选参数：
//   - WithVersion: 指定版本路由，只选匹配版本的实例
//
// 示例：
//
//	Target("default", "dev", "order.rpc")
//	Target("default", "dev", "order.rpc", WithVersion("v2.0.0"))
func Target(project, env, serviceName string, opts ...TargetOption) string {
	o := &targetOptions{}
	for _, opt := range opts {
		opt(o)
	}
	base := fmt.Sprintf("%s/%s/%s", project, env, serviceName)
	if o.Version != "" {
		base += "@" + o.Version
	}
	return base
}

// parseTargetOptions 从 target path 解析版本选项。
// 格式: {project}/{env}/{serviceName}[@{version}]
func parseTargetOptions(path string) (cleanPath string, version string) {
	cleanPath = path

	if idx := strings.LastIndex(path, "@"); idx >= 0 {
		version = path[idx+1:]
		cleanPath = path[:idx]
	}
	return
}

// alayaBuilder 实现 grpc/resolver.Builder。
type alayaBuilder struct{}

// Build 解析 target 得到 (project,env,serviceName)，Watch Alaya etcd 前缀，
// 把 InstanceInfo 转成 resolver.Address 推给 gRPC ClientConn。
// target 必须为 {project}/{env}/{serviceName} 格式（由 Target 构造）。
func (b *alayaBuilder) Build(target resolver.Target, cc resolver.ClientConn, _ resolver.BuildOptions) (resolver.Resolver, error) {
	path := target.URL.Path
	cleanPath, version := parseTargetOptions(path)

	project, env, svc, err := ParseTarget(cleanPath)
	if err != nil {
		return nil, err
	}

	cli := getEtcdClient()
	if cli == nil {
		return nil, fmt.Errorf("alaya resolver: etcd client not set, call xetcd.SetEtcdClient first")
	}

	prefix := fmt.Sprintf("/%s/%s/%s/", project, env, svc)
	r := &alayaResolver{
		cli:     cli,
		cc:      cc,
		prefix:  prefix,
		version: version,
		done:    make(chan struct{}),
	}

	r.update()

	go r.watchLoop()

	return r, nil
}

// Scheme 返回 gRPC 默认 scheme "alaya"。
func (b *alayaBuilder) Scheme() string {
	return "alaya"
}

// alayaResolver 实现 grpc/resolver.Resolver。
type alayaResolver struct {
	cli     *clientv3.Client
	cc      resolver.ClientConn
	prefix  string
	version string // 指定版本过滤
	done    chan struct{}
	once    sync.Once
}

// update 拉取前缀下全部实例，过滤版本后转成 resolver.Address。
func (r *alayaResolver) update() {
	resp, err := r.cli.Get(context.Background(), r.prefix, clientv3.WithPrefix())
	if err != nil {
		return
	}
	addrs := make([]resolver.Address, 0, len(resp.Kvs))
	for _, kv := range resp.Kvs {
		inst, err := DecodeInstance(string(kv.Key), string(kv.Value))
		if err != nil || !inst.Enabled {
			continue
		}

		// 版本过滤
		if r.version != "" && inst.Metadata["version"] != r.version {
			continue
		}

		// 权重为 0 的实例不参与路由
		if inst.Weight <= 0 {
			continue
		}

		// 将 weight 转为 int 传递（gRPC BalancerAttributes 建议使用基本类型）
		weight := int64(inst.Weight)
		if weight < 1 {
			weight = 1
		}

		// weight 必须放在 Attributes（而非 BalancerAttributes）：
		// gRPC base balancer 的 AddressMapV2 用 Addr+ServerName+Attributes 标识 SubConn，
		// 忽略 BalancerAttributes。只有 weight 进入 Attributes，权重变更才会触发
		// SubConn 重建并让 picker 读到新权重。
		addr := resolver.Address{
			Addr: fmt.Sprintf("%s:%d", inst.Ip, inst.Port),
			Attributes: attributes.New(attrKeyVersion, inst.Metadata["version"]).
				WithValue(attrKeyWeight, weight),
		}
		addrs = append(addrs, addr)
	}
	_ = r.cc.UpdateState(resolver.State{Addresses: addrs})
}

// watchLoop 监听前缀变更，自动重连并重新同步全量实例。
func (r *alayaResolver) watchLoop() {
	for {
		select {
		case <-r.done:
			return
		default:
		}

		ch := r.cli.Watch(context.Background(), r.prefix, clientv3.WithPrefix())
	innerWatch:
		for {
			select {
			case wresp, ok := <-ch:
				if !ok || wresp.Err() != nil {
					time.Sleep(time.Second)
					break innerWatch // 跳出内层 for 循环，重新建立 Watch
				}
				r.update()
			case <-r.done:
				return
			}
		}

		// Watch 重连后全量刷新一次最新实例，弥补断线期间遗漏的变更
		r.update()
	}
}

// ResolveNow gRPC 在重解析时调用。
func (r *alayaResolver) ResolveNow(resolver.ResolveNowOptions) {}

// Close 停止 Watch。
func (r *alayaResolver) Close() {
	r.once.Do(func() { close(r.done) })
}

// ParseTarget 从 target path 解析三元组。
// 支持两种格式："/{project}/{env}/{serviceName}" 或 "{project}/{env}/{serviceName}"
// 以及带版本的扩展格式。
func ParseTarget(path string) (project, env, serviceName string, err error) {
	path = strings.TrimPrefix(path, "/")
	// 去除 @version 后缀
	if idx := strings.LastIndex(path, "@"); idx >= 0 {
		path = path[:idx]
	}
	parts := strings.Split(path, "/")
	if len(parts) != 3 || parts[0] == "" || parts[1] == "" || parts[2] == "" {
		return "", "", "", fmt.Errorf("invalid target path %q, want {project}/{env}/{serviceName}", path)
	}
	return parts[0], parts[1], parts[2], nil
}

// Register 将 Alaya resolver builder 注册到 gRPC，不修改默认 scheme。
// 使用时需在 Target 中显式指定 alaya:// scheme，或在调用方设置 RpcClientConf.Endpoints[0] = "alaya://"。
func Register() {
	resolver.Register(&alayaBuilder{})
}

// RegisterAsDefault 注册 Alaya resolver 并设为全局默认 scheme。
// 注意：这会影响进程内所有未显式指定 scheme 的 gRPC 客户端。
// 仅在所有 gRPC 发现都走 Alaya 时使用。
func RegisterAsDefault() {
	resolver.Register(&alayaBuilder{})
	resolver.SetDefaultScheme("alaya")
}

// ============================================================================
// Weighted P2C Balancer (加权负载均衡器)
// ============================================================================

const (
	// BalancerName 是加权 p2c 负载均衡器的注册名。
	BalancerName = "alaya_weighted_p2c"
	balancerName = BalancerName

	// p2c 算法参数（与 go-zero p2c 保持一致）
	decayTime    = int64(time.Second * 10)
	forcePickAge = int64(time.Second)
	initSuccess  = 1000
	throttleSuc  = initSuccess / 2
	penalty      = int64(math.MaxInt32)
	pickAttempts = 3
)

func init() {
	balancer.Register(newWeightedP2CBuilder())
}

// newWeightedP2CBuilder 创建加权 p2c balancer builder。
func newWeightedP2CBuilder() balancer.Builder {
	return base.NewBalancerBuilder(
		balancerName,
		&weightedP2CPickerBuilder{},
		base.Config{HealthCheck: true},
	)
}

// weightedP2CPickerBuilder 实现 base.PickerBuildInfo。
type weightedP2CPickerBuilder struct{}

func (b *weightedP2CPickerBuilder) Build(info base.PickerBuildInfo) balancer.Picker {
	readySCs := info.ReadySCs
	if len(readySCs) == 0 {
		return base.NewErrPicker(balancer.ErrNoSubConnAvailable)
	}

	conns := make([]*weightedSubConn, 0, len(readySCs))
	for conn, connInfo := range readySCs {
		weight := extractWeight(connInfo.Address)
		if weight <= 0 {
			weight = 1
		}
		conns = append(conns, &weightedSubConn{
			conn:       conn,
			connWeight: weight,
			success:    initSuccess,
		})
	}

	return &weightedP2CPicker{
		conns: conns,
		r:     rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

// extractWeight 从 Address.Attributes 中提取权重值。
// 必须读 Attributes（而非 BalancerAttributes）：base balancer 的 SubConn 身份
// 只按 Addr+ServerName+Attributes 匹配，weight 放在 Attributes 才能在变更时生效。
func extractWeight(addr resolver.Address) int64 {
	if addr.Attributes == nil {
		return 1
	}
	v := addr.Attributes.Value(attrKeyWeight)
	if v == nil {
		return 1
	}
	w, ok := v.(int64)
	if !ok || w < 1 {
		return 1
	}
	return w
}

// weightedP2CPicker 加权 p2c picker。
type weightedP2CPicker struct {
	conns []*weightedSubConn
	r     *rand.Rand
	lock  sync.Mutex
}

func (p *weightedP2CPicker) Pick(_ balancer.PickInfo) (balancer.PickResult, error) {
	p.lock.Lock()
	defer p.lock.Unlock()

	var chosen *weightedSubConn
	switch len(p.conns) {
	case 0:
		return balancer.PickResult{}, balancer.ErrNoSubConnAvailable
	case 1:
		chosen = p.choose(p.conns[0], nil)
	case 2:
		chosen = p.choose(p.conns[0], p.conns[1])
	default:
		var n1, n2 *weightedSubConn
		for i := 0; i < pickAttempts; i++ {
			a := p.r.Intn(len(p.conns))
			b := p.r.Intn(len(p.conns) - 1)
			if b >= a {
				b++
			}
			n1 = p.conns[a]
			n2 = p.conns[b]
			if n1.healthy() && n2.healthy() {
				break
			}
		}
		chosen = p.choose(n1, n2)
	}

	atomic.AddInt64(&chosen.inflight, 1)

	return balancer.PickResult{
		SubConn: chosen.conn,
		Done:    p.buildDoneFunc(chosen),
	}, nil
}

func (p *weightedP2CPicker) buildDoneFunc(c *weightedSubConn) func(balancer.DoneInfo) {
	start := time.Now()
	return func(info balancer.DoneInfo) {
		atomic.AddInt64(&c.inflight, -1)
		now := time.Now()
		last := atomic.SwapInt64(&c.last, int64(now.UnixNano()))
		td := int64(now.UnixNano()) - last
		if td < 0 {
			td = 0
		}

		w := math.Exp(float64(-td) / float64(decayTime))
		lag := int64(now.Sub(start).Nanoseconds())
		if lag < 0 {
			lag = 0
		}
		olag := atomic.LoadUint64(&c.lag)
		if olag == 0 {
			w = 0
		}

		atomic.StoreUint64(&c.lag, uint64(float64(olag)*w+float64(lag)*(1-w)))
		success := initSuccess
		if info.Err != nil && !isAcceptableErr(info.Err) {
			success = 0
		}
		osucc := atomic.LoadUint64(&c.success)
		atomic.StoreUint64(&c.success, uint64(float64(osucc)*w+float64(success)*(1-w)))
	}
}

// isAcceptableErr 判断错误是否可接受（与 go-zero codes.Acceptable 语义一致）。
func isAcceptableErr(err error) bool {
	if err == nil {
		return true
	}
	s := err.Error()
	// 已取消或超时的错误被视为可接受
	return strings.Contains(s, "context canceled") ||
		strings.Contains(s, "context deadline exceeded")
}

// choose 在两个候选中选取有效负载（负载/权重）更低的节点。
func (p *weightedP2CPicker) choose(c1, c2 *weightedSubConn) *weightedSubConn {
	if c2 == nil {
		atomic.StoreInt64(&c1.pick, int64(time.Now().UnixNano()))
		return c1
	}

	// 加权比较：负载 / 权重，权重越大等效负载越低
	l1 := c1.weightedLoad()
	l2 := c2.weightedLoad()

	if l1 > l2 {
		c1, c2 = c2, c1
	}

	// force pick 机制防止一个节点被长期忽略
	pick := atomic.LoadInt64(&c2.pick)
	now := int64(time.Now().UnixNano())
	if now-pick > forcePickAge && atomic.CompareAndSwapInt64(&c2.pick, pick, now) {
		return c2
	}

	atomic.StoreInt64(&c1.pick, now)
	return c1
}

// weightedSubConn 带权重的子连接。
type weightedSubConn struct {
	conn       balancer.SubConn
	connWeight int64 // 配置的权重
	lag        uint64
	inflight   int64
	success    uint64
	last       int64
	pick       int64
}

func (c *weightedSubConn) healthy() bool {
	return atomic.LoadUint64(&c.success) > throttleSuc
}

// load 计算原始负载。
// 当 lag 和 inflight 均为 0（新连接/空闲连接无历史数据）时返回 penalty，
// 确保 picker 优先探测未知节点。
func (c *weightedSubConn) load() int64 {
	rawLag := atomic.LoadUint64(&c.lag)
	rawInflight := atomic.LoadInt64(&c.inflight)
	if rawLag == 0 && rawInflight == 0 {
		return penalty
	}
	lag := int64(math.Sqrt(float64(rawLag + 1)))
	load := lag * (rawInflight + 1)
	return load
}

// weightedLoad 计算加权负载：load / weight。
// 权重越大，等效负载越低，在 p2c 选择中更有利。
func (c *weightedSubConn) weightedLoad() int64 {
	load := c.load()
	if c.connWeight <= 1 {
		return load
	}
	// 加权：除以权重，使高权重节点在比较中占优势
	// 使用整数运算：load / weight
	return load / c.connWeight
}
