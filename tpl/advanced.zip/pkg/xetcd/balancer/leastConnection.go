/**
 * @Author: spruce
 * @Date: 2026-09-30 10:00
 * @Desc: 最小连接数 / 最小活跃请求数负载均衡器 (Least Connection Balancer)
 */

package balancer

import (
	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	"google.golang.org/grpc/balancer"
	"google.golang.org/grpc/balancer/base"
)

func init() {
	RegisterLeastConnection()
}

// RegisterLeastConnection 注册最小连接数负载均衡器到 gRPC balancer 注册表
func RegisterLeastConnection() {
	builder := base.NewBalancerBuilder(
		LeastConnection,
		&leastConnectionPickerBuilder{},
		base.Config{HealthCheck: true},
	)
	balancer.Register(builder)
}

type leastConnectionPickerBuilder struct{}

func (b *leastConnectionPickerBuilder) Build(info base.PickerBuildInfo) balancer.Picker {
	if len(info.ReadySCs) == 0 {
		return base.NewErrPicker(balancer.ErrNoSubConnAvailable)
	}

	nodes := make([]*connNode, 0, len(info.ReadySCs))
	for sc, connInfo := range info.ReadySCs {
		w := ExtractWeight(connInfo.Address)
		if w <= 0 {
			w = 1
		}
		nodes = append(nodes, &connNode{
			subConn: sc,
			weight:  w,
		})
	}

	return &leastConnectionPicker{
		nodes: nodes,
		rand:  rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

type connNode struct {
	subConn  balancer.SubConn
	weight   int64
	inflight int64
}

// load 计算节点当前归一化加权负载
func (n *connNode) load() float64 {
	inflight := atomic.LoadInt64(&n.inflight)
	w := n.weight
	if w <= 0 {
		w = 1
	}
	return float64(inflight) / float64(w)
}

type leastConnectionPicker struct {
	nodes []*connNode
	mu    sync.Mutex
	rand  *rand.Rand
}

func (p *leastConnectionPicker) Pick(_ balancer.PickInfo) (balancer.PickResult, error) {
	if len(p.nodes) == 0 {
		return balancer.PickResult{}, balancer.ErrNoSubConnAvailable
	}

	var chosen *connNode
	switch len(p.nodes) {
	case 1:
		chosen = p.nodes[0]
	case 2:
		if p.nodes[0].load() <= p.nodes[1].load() {
			chosen = p.nodes[0]
		} else {
			chosen = p.nodes[1]
		}
	default:
		// P2C (Power of Two Choices) 避免全局锁竞争与惊群效应
		p.mu.Lock()
		idxA := p.rand.Intn(len(p.nodes))
		idxB := p.rand.Intn(len(p.nodes) - 1)
		p.mu.Unlock()
		if idxB >= idxA {
			idxB++
		}

		nodeA := p.nodes[idxA]
		nodeB := p.nodes[idxB]
		if nodeA.load() <= nodeB.load() {
			chosen = nodeA
		} else {
			chosen = nodeB
		}
	}

	// 活跃请求数原子递增
	atomic.AddInt64(&chosen.inflight, 1)

	return balancer.PickResult{
		SubConn: chosen.subConn,
		Done: func(info balancer.DoneInfo) {
			// RPC 请求结束，活跃请求数原子递减
			atomic.AddInt64(&chosen.inflight, -1)
		},
	}, nil
}
