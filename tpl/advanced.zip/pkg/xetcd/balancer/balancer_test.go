/**
 * @Author: spruce
 * @Date: 2026-09-30 10:15
 * @Desc: 负载均衡器单元测试用例
 */

package balancer

import (
	"context"
	"fmt"
	"sync"
	"testing"

	"google.golang.org/grpc/attributes"
	"google.golang.org/grpc/balancer"
	"google.golang.org/grpc/balancer/base"
	"google.golang.org/grpc/resolver"
)

// mockSubConn 模拟 gRPC SubConn
type mockSubConn struct {
	balancer.SubConn
	addr string
}

func (m *mockSubConn) UpdateAddresses([]resolver.Address) {}
func (m *mockSubConn) Connect()                           {}

// 辅助构造测试 PickerBuildInfo
func buildMockPickerInfo(addrs []struct {
	addr    string
	weight  int64
	version string
}) (base.PickerBuildInfo, map[string]balancer.SubConn) {
	readySCs := make(map[balancer.SubConn]base.SubConnInfo)
	scMap := make(map[string]balancer.SubConn)

	for _, a := range addrs {
		sc := &mockSubConn{addr: a.addr}
		scMap[a.addr] = sc

		attrs := attributes.New(AttrKeyWeight, a.weight).
			WithValue(AttrKeyVersion, a.version)

		readySCs[sc] = base.SubConnInfo{
			Address: resolver.Address{
				Addr:       a.addr,
				Attributes: attrs,
			},
		}
	}

	return base.PickerBuildInfo{ReadySCs: readySCs}, scMap
}

// ============================================================================
// 1. 一致性哈希 (ConsistentHash) 单元测试
// ============================================================================

func TestConsistentHash_Pick(t *testing.T) {
	info, scMap := buildMockPickerInfo([]struct {
		addr    string
		weight  int64
		version string
	}{
		{addr: "10.0.0.1:8001", weight: 10, version: "v1.0.0"},
		{addr: "10.0.0.2:8002", weight: 10, version: "v1.0.0"},
		{addr: "10.0.0.3:8003", weight: 10, version: "v1.0.0"},
	})

	builder := &consistentHashPickerBuilder{}
	picker := builder.Build(info)

	// 1. 相同 Key 必须始终命中相同的 SubConn
	testKeys := []string{"user-1001", "order-8888", "tenant-9999", "cart-123"}
	for _, k := range testKeys {
		ctx := WithHashKey(context.Background(), k)
		res1, err := picker.Pick(balancer.PickInfo{Ctx: ctx})
		if err != nil {
			t.Fatalf("pick failed: %v", err)
		}
		res2, err := picker.Pick(balancer.PickInfo{Ctx: ctx})
		if err != nil {
			t.Fatalf("pick failed: %v", err)
		}

		if res1.SubConn != res2.SubConn {
			t.Errorf("consistent hash mismatch for key %s: got %v and %v", k, res1.SubConn, res2.SubConn)
		}
	}

	// 2. 未指定 Key 时平滑兜底，不抛错
	res, err := picker.Pick(balancer.PickInfo{Ctx: context.Background()})
	if err != nil {
		t.Fatalf("pick with empty key failed: %v", err)
	}
	if res.SubConn == nil {
		t.Errorf("expected fallback subconn, got nil")
	}

	// 3. 验证通过 SubConn 能找到目标映射
	foundAny := false
	for _, sc := range scMap {
		if res.SubConn == sc {
			foundAny = true
			break
		}
	}
	if !foundAny {
		t.Errorf("picked subconn not in readySCs")
	}
}

// ============================================================================
// 2. 最小连接数 / 活跃请求数 (LeastConnection) 单元测试
// ============================================================================

func TestLeastConnection_Pick(t *testing.T) {
	info, scMap := buildMockPickerInfo([]struct {
		addr    string
		weight  int64
		version string
	}{
		{addr: "10.0.0.1:8001", weight: 10, version: "v1.0.0"},
		{addr: "10.0.0.2:8002", weight: 10, version: "v1.0.0"},
	})

	builder := &leastConnectionPickerBuilder{}
	picker := builder.Build(info)

	// 场景 A: 发起多次请求并维持其中一个节点的活跃度，验证后续请求被调度至空闲节点
	p, ok := picker.(*leastConnectionPicker)
	if !ok {
		t.Fatalf("picker type mismatch")
	}

	// 模拟 node 0 堆积了 10 个 inflight 请求
	p.nodes[0].inflight = 10
	p.nodes[1].inflight = 0

	// 连续调度 50 次，负载敏感算法应大概率倾向节点 1
	var pickedNode1Count int
	for i := 0; i < 50; i++ {
		res, err := picker.Pick(balancer.PickInfo{})
		if err != nil {
			t.Fatalf("pick failed: %v", err)
		}
		if res.SubConn == scMap["10.0.0.2:8002"] {
			pickedNode1Count++
		}
		// 模拟执行完成
		if res.Done != nil {
			res.Done(balancer.DoneInfo{})
		}
	}

	if pickedNode1Count < 40 {
		t.Errorf("expected least connection to prefer node2 (inflight=0), but only picked %d/50 times", pickedNode1Count)
	}

	// 场景 B: 验证 Done 回调的原子递减
	res, _ := picker.Pick(balancer.PickInfo{})
	beforeDone := p.nodes[0].inflight + p.nodes[1].inflight
	res.Done(balancer.DoneInfo{})
	afterDone := p.nodes[0].inflight + p.nodes[1].inflight
	if afterDone != beforeDone-1 {
		t.Errorf("Done callback failed to decrement inflight: before=%d, after=%d", beforeDone, afterDone)
	}
}

// ============================================================================
// 3. 版本优先 / 灰度路由 (Version) 单元测试
// ============================================================================

func TestVersion_Pick(t *testing.T) {
	info, scMap := buildMockPickerInfo([]struct {
		addr    string
		weight  int64
		version string
	}{
		{addr: "10.0.0.1:8001", weight: 10, version: "v1.0.0"},
		{addr: "10.0.0.2:8002", weight: 10, version: "v2.0.0"},
		{addr: "10.0.0.3:8003", weight: 10, version: "v2.0.0"},
	})

	builder := &versionPickerBuilder{}
	picker := builder.Build(info)

	// 1. 指定 v1.0.0，必须命中 10.0.0.1:8001
	for i := 0; i < 10; i++ {
		ctx := WithTargetVersion(context.Background(), "v1.0.0")
		res, err := picker.Pick(balancer.PickInfo{Ctx: ctx})
		if err != nil {
			t.Fatalf("pick v1.0.0 failed: %v", err)
		}
		if res.SubConn != scMap["10.0.0.1:8001"] {
			t.Errorf("expected to pick 10.0.0.1 for v1.0.0, got %v", res.SubConn)
		}
	}

	// 2. 指定 v2.0.0，必须命中 10.0.0.2 或 10.0.0.3，不能命中 10.0.0.1
	for i := 0; i < 10; i++ {
		ctx := WithTargetVersion(context.Background(), "v2.0.0")
		res, err := picker.Pick(balancer.PickInfo{Ctx: ctx})
		if err != nil {
			t.Fatalf("pick v2.0.0 failed: %v", err)
		}
		if res.SubConn == scMap["10.0.0.1:8001"] {
			t.Errorf("should not pick v1.0.0 node for target version v2.0.0")
		}
	}

	// 3. 指定不存在的版本 (如 v9.9.9)，平滑降级到全体节点，不发生 panic 或报错
	ctxFallback := WithTargetVersion(context.Background(), "v9.9.9")
	res, err := picker.Pick(balancer.PickInfo{Ctx: ctxFallback})
	if err != nil {
		t.Fatalf("expected fallback pick on non-existent version, got error: %v", err)
	}
	if res.SubConn == nil {
		t.Errorf("expected non-nil subconn on fallback")
	}
}

// ============================================================================
// 4. 加权 P2C (WeightedP2C) 单元测试
// ============================================================================

func TestWeightedP2C_Pick(t *testing.T) {
	info, scMap := buildMockPickerInfo([]struct {
		addr    string
		weight  int64
		version string
	}{
		{addr: "10.0.0.1:8001", weight: 10, version: "v1.0.0"},
		{addr: "10.0.0.2:8002", weight: 30, version: "v1.0.0"},
	})

	builder := &weightedP2CPickerBuilder{}
	picker := builder.Build(info)

	// 1. 验证空节点错误处理
	emptyPicker := builder.Build(base.PickerBuildInfo{ReadySCs: nil})
	_, err := emptyPicker.Pick(balancer.PickInfo{})
	if err == nil {
		t.Fatalf("expected error on empty subconns")
	}

	// 2. 正常选节点及 Done 回调正常工作
	for i := 0; i < 20; i++ {
		res, err := picker.Pick(balancer.PickInfo{})
		if err != nil {
			t.Fatalf("pick failed: %v", err)
		}
		if res.SubConn == nil {
			t.Fatalf("picked nil subconn")
		}
		if res.Done != nil {
			res.Done(balancer.DoneInfo{})
		}
	}
	_ = scMap
}

// ============================================================================
// 5. 并发安全性压测
// ============================================================================

func TestBalancers_Concurrency(t *testing.T) {
	info, _ := buildMockPickerInfo([]struct {
		addr    string
		weight  int64
		version string
	}{
		{addr: "10.0.0.1:8001", weight: 10, version: "v1.0.0"},
		{addr: "10.0.0.2:8002", weight: 20, version: "v2.0.0"},
		{addr: "10.0.0.3:8003", weight: 30, version: "v2.0.0"},
	})

	pickers := []balancer.Picker{
		(&consistentHashPickerBuilder{}).Build(info),
		(&leastConnectionPickerBuilder{}).Build(info),
		(&versionPickerBuilder{}).Build(info),
		(&weightedP2CPickerBuilder{}).Build(info),
	}

	for idx, p := range pickers {
		t.Run(fmt.Sprintf("Picker-%d", idx), func(t *testing.T) {
			var wg sync.WaitGroup
			for i := 0; i < 50; i++ {
				wg.Add(1)
				go func(id int) {
					defer wg.Done()
					for j := 0; j < 100; j++ {
						ctx := WithHashKey(context.Background(), fmt.Sprintf("key-%d", id))
						ctx = WithTargetVersion(ctx, "v2.0.0")
						res, err := p.Pick(balancer.PickInfo{Ctx: ctx})
						if err != nil {
							t.Errorf("concurrent pick error: %v", err)
							return
						}
						if res.Done != nil {
							res.Done(balancer.DoneInfo{})
						}
					}
				}(i)
			}
			wg.Wait()
		})
	}
}
