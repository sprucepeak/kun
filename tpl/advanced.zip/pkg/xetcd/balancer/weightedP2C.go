/**
 * @Author: spruce
 * @Date: 2026-09-30 10:00
 * @Desc: 加权 P2C 负载均衡器 (Weighted Power of Two Choices Balancer)
 *
 * 算法原理与 go-zero / k8s P2C 保持一致：
 * 1. 结合 EWMA（指数加权移动平均）动态感知节点历史响应延迟与成功率；
 * 2. 统计各节点并发在途请求数 (inflight)；
 * 3. 每次请求随机挑选两个候选节点 (Pick 2)，挑选加权等效负载 (load / weight) 较低的节点；
 * 4. 内置 Force Pick 兜底机制，防止冷节点或低权重节点饥饿。
 */

package balancer

import (
	"math"
	"math/rand"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"google.golang.org/grpc/balancer"
	"google.golang.org/grpc/balancer/base"
)

const (
	// p2c 算法参数（与 go-zero p2c 保持一致）
	decayTime    = int64(time.Second * 10)
	forcePickAge = int64(time.Second)
	initSuccess  = 1000
	throttleSuc  = initSuccess / 2
	penalty      = int64(math.MaxInt32)
	pickAttempts = 3
)

func init() {
	RegisterWeightedP2C()
}

// RegisterWeightedP2C 注册加权 P2C 负载均衡器到 gRPC balancer 注册表
func RegisterWeightedP2C() {
	builder := base.NewBalancerBuilder(
		WeightedP2C,
		&weightedP2CPickerBuilder{},
		base.Config{HealthCheck: true},
	)
	balancer.Register(builder)
}

// weightedP2CPickerBuilder 实现 base.PickerBuilder
type weightedP2CPickerBuilder struct{}

func (b *weightedP2CPickerBuilder) Build(info base.PickerBuildInfo) balancer.Picker {
	readySCs := info.ReadySCs
	if len(readySCs) == 0 {
		return base.NewErrPicker(balancer.ErrNoSubConnAvailable)
	}

	conns := make([]*weightedSubConn, 0, len(readySCs))
	for conn, connInfo := range readySCs {
		weight := ExtractWeight(connInfo.Address)
		if weight <= 0 {
			weight = 1
		}
		conns = append(conns, &weightedSubConn{
			conn:       conn,
			connWeight: weight,
			success:    initSuccess,
		})
	}

	return &weightedP2CPicker{
		conns: conns,
		r:     rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

// weightedP2CPicker 加权 p2c picker
type weightedP2CPicker struct {
	conns []*weightedSubConn
	r     *rand.Rand
	lock  sync.Mutex
}

func (p *weightedP2CPicker) Pick(_ balancer.PickInfo) (balancer.PickResult, error) {
	p.lock.Lock()
	defer p.lock.Unlock()

	var chosen *weightedSubConn
	switch len(p.conns) {
	case 0:
		return balancer.PickResult{}, balancer.ErrNoSubConnAvailable
	case 1:
		chosen = p.choose(p.conns[0], nil)
	case 2:
		chosen = p.choose(p.conns[0], p.conns[1])
	default:
		var n1, n2 *weightedSubConn
		for i := 0; i < pickAttempts; i++ {
			a := p.r.Intn(len(p.conns))
			b := p.r.Intn(len(p.conns) - 1)
			if b >= a {
				b++
			}
			n1 = p.conns[a]
			n2 = p.conns[b]
			if n1.healthy() && n2.healthy() {
				break
			}
		}
		chosen = p.choose(n1, n2)
	}

	atomic.AddInt64(&chosen.inflight, 1)

	return balancer.PickResult{
		SubConn: chosen.conn,
		Done:    p.buildDoneFunc(chosen),
	}, nil
}

func (p *weightedP2CPicker) buildDoneFunc(c *weightedSubConn) func(balancer.DoneInfo) {
	start := time.Now()
	return func(info balancer.DoneInfo) {
		atomic.AddInt64(&c.inflight, -1)
		now := time.Now()
		last := atomic.SwapInt64(&c.last, int64(now.UnixNano()))
		td := int64(now.UnixNano()) - last
		if td < 0 {
			td = 0
		}

		w := math.Exp(float64(-td) / float64(decayTime))
		lag := int64(now.Sub(start).Nanoseconds())
		if lag < 0 {
			lag = 0
		}
		olag := atomic.LoadUint64(&c.lag)
		if olag == 0 {
			w = 0
		}

		atomic.StoreUint64(&c.lag, uint64(float64(olag)*w+float64(lag)*(1-w)))
		success := initSuccess
		if info.Err != nil && !isAcceptableErr(info.Err) {
			success = 0
		}
		osucc := atomic.LoadUint64(&c.success)
		atomic.StoreUint64(&c.success, uint64(float64(osucc)*w+float64(success)*(1-w)))
	}
}

// isAcceptableErr 判断错误是否可接受（与 go-zero codes.Acceptable 语义一致）
func isAcceptableErr(err error) bool {
	if err == nil {
		return true
	}
	s := err.Error()
	// 已取消或超时的错误被视为可接受
	return strings.Contains(s, "context canceled") ||
		strings.Contains(s, "context deadline exceeded")
}

// choose 在两个候选中选取有效负载（负载/权重）更低的节点
func (p *weightedP2CPicker) choose(c1, c2 *weightedSubConn) *weightedSubConn {
	if c2 == nil {
		atomic.StoreInt64(&c1.pick, int64(time.Now().UnixNano()))
		return c1
	}

	// 加权比较：负载 / 权重，权重越大等效负载越低
	l1 := c1.weightedLoad()
	l2 := c2.weightedLoad()

	if l1 > l2 {
		c1, c2 = c2, c1
	}

	// force pick 机制防止一个节点被长期忽略
	pick := atomic.LoadInt64(&c2.pick)
	now := int64(time.Now().UnixNano())
	if now-pick > forcePickAge && atomic.CompareAndSwapInt64(&c2.pick, pick, now) {
		return c2
	}

	atomic.StoreInt64(&c1.pick, now)
	return c1
}

// weightedSubConn 带权重的子连接
type weightedSubConn struct {
	conn       balancer.SubConn
	connWeight int64 // 配置的权重
	lag        uint64
	inflight   int64
	success    uint64
	last       int64
	pick       int64
}

func (c *weightedSubConn) healthy() bool {
	return atomic.LoadUint64(&c.success) > throttleSuc
}

// load 计算原始负载
func (c *weightedSubConn) load() int64 {
	rawLag := atomic.LoadUint64(&c.lag)
	rawInflight := atomic.LoadInt64(&c.inflight)
	if rawLag == 0 && rawInflight == 0 {
		return penalty
	}
	lag := int64(math.Sqrt(float64(rawLag + 1)))
	load := lag * (rawInflight + 1)
	return load
}

// weightedLoad 计算加权负载：load / weight
func (c *weightedSubConn) weightedLoad() int64 {
	load := c.load()
	if c.connWeight <= 1 {
		return load
	}
	return load / c.connWeight
}
