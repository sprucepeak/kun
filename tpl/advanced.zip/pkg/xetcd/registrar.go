/**
 * @Author: spruce
 * @Date: 2026-09-29 16:18
 * @Desc: 服务实例注册与服务发现
 */

package xetcd

import (
	"context"
	"fmt"
	"math/rand"
	"sync"
	"time"

	"go.etcd.io/etcd/api/v3/mvccpb"
	clientv3 "go.etcd.io/etcd/client/v3"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// Registrar 管理服务实例在 etcd 中的注册与心跳。
// etcd key: /{project}/{env}/{serviceName}/{ip}:{port}
// etcd value: {weight}|{enabled}|{version}
type Registrar struct {
	cli           *clientv3.Client
	cliMu         sync.RWMutex // 保护 cli 的并发读写（heartbeatLoop 重连 vs Deregister）
	leaseMu       sync.RWMutex // 保护 leaseID 并发读写
	leaseID       clientv3.LeaseID
	key           string
	info          InstanceInfo
	leaseTTL      int64
	etcdEndpoints []string
	etcdUsername  string
	etcdPassword  string
	done          chan struct{}
	once          sync.Once
	wg            sync.WaitGroup
}

// RegisterParam 注册参数。
type RegisterParam struct {
	EtcdEndpoints []string          // 该环境对应的 etcd 地址
	EtcdUsername  string            // 可选，etcd 开启认证时填写账号
	EtcdPassword  string            // 可选，etcd 开启认证时填写密码
	Project       string            // Alaya 项目编码（project.code）
	Env           string            // 环境 code（如 dev、staging、prod）
	ServiceName   string            // 服务名
	IP            string            // 本机 IP
	Port          int32             // 监听端口
	Weight        float64           // 权重（默认 100）
	Metadata      map[string]string // 元数据（如 version）
	LeaseTTL      int64             // Lease TTL 秒数（默认 15）
}

// NewRegistrar 注册服务到 etcd 并启动心跳。
// value  weight|enabled|version，比 JSON 存储缩小 ~15x。
func NewRegistrar(ctx context.Context, param RegisterParam) (*Registrar, error) {
	ttl := param.LeaseTTL
	if ttl <= 0 {
		ttl = 15
	}
	if param.Weight <= 0 {
		param.Weight = 100
	}

	cli, err := newRawClient(param.EtcdEndpoints, defaultDialTimeout, param.EtcdUsername, param.EtcdPassword)
	if err != nil {
		return nil, fmt.Errorf("connect etcd failed: %w", err)
	}

	info := InstanceInfo{
		ServiceName: param.ServiceName,
		Env:         param.Env,
		Ip:          param.IP,
		Port:        param.Port,
		Weight:      param.Weight,
		Enabled:     true,
		Metadata:    param.Metadata,
	}

	r := &Registrar{
		cli:           cli,
		key:           fmt.Sprintf("/%s/%s/%s/%s:%d", param.Project, param.Env, param.ServiceName, param.IP, param.Port),
		info:          info,
		leaseTTL:      ttl,
		etcdEndpoints: param.EtcdEndpoints,
		etcdUsername:  param.EtcdUsername,
		etcdPassword:  param.EtcdPassword,
		done:          make(chan struct{}),
	}

	if err := r.putWithLease(ctx); err != nil {
		cli.Close()
		return nil, err
	}

	pkgLogger("[xetcd] registered %s (lease=%d, ttl=%ds)", r.key, r.leaseID, ttl)

	r.wg.Add(1)
	go r.heartbeatLoop(ctx)

	return r, nil
}

// putWithLease 创建/续期 lease 并写入实例数据。
func (r *Registrar) putWithLease(ctx context.Context) error {
	r.cliMu.RLock()
	cli := r.cli
	r.cliMu.RUnlock()

	lease, err := cli.Grant(ctx, r.leaseTTL)
	if err != nil {
		return fmt.Errorf("grant lease failed: %w", err)
	}
	val := EncodeInstance(&r.info)
	if _, err := cli.Put(ctx, r.key, val, clientv3.WithLease(lease.ID)); err != nil {
		return fmt.Errorf("put instance failed: %w", err)
	}

	r.leaseMu.Lock()
	r.leaseID = lease.ID
	r.leaseMu.Unlock()
	return nil
}

// heartbeatLoop 心跳续期循环。
func (r *Registrar) heartbeatLoop(ctx context.Context) {
	defer r.wg.Done()
	interval := time.Duration(r.leaseTTL/3) * time.Second
	if interval <= 0 {
		interval = 5 * time.Second
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			r.cliMu.RLock()
			cli := r.cli
			r.cliMu.RUnlock()

			r.leaseMu.RLock()
			lid := r.leaseID
			r.leaseMu.RUnlock()

			if _, err := cli.KeepAliveOnce(ctx, lid); err != nil {
				pkgLogger("[xetcd] keepalive failed: %v", err)
				if isEtcdUnauthenticated(err) {
					pkgLogger("[xetcd] etcd token expired, closing current client and reconnecting")
					cli.Close()
					newCli, cerr := newRawClient(r.etcdEndpoints, defaultDialTimeout, r.etcdUsername, r.etcdPassword)
					if cerr != nil {
						pkgLogger("[xetcd] reconnect etcd failed: %v", cerr)
						continue
					}
					r.cliMu.Lock()
					r.cli = newCli
					r.cliMu.Unlock()
				}
				if rerr := r.putWithLease(ctx); rerr != nil {
					pkgLogger("[xetcd] re-register failed: %v", rerr)
				} else {
					r.leaseMu.RLock()
					newLid := r.leaseID
					r.leaseMu.RUnlock()
					pkgLogger("[xetcd] re-registered %s (new lease=%d)", r.key, newLid)
				}
			}
		case <-r.done:
			return
		case <-ctx.Done():
			return
		}
	}
}

// isEtcdUnauthenticated 检测 etcd 操作错误是否为认证令牌过期。
func isEtcdUnauthenticated(err error) bool {
	if err == nil {
		return false
	}
	st, ok := status.FromError(err)
	return ok && st.Code() == codes.Unauthenticated
}

// Deregister 主动注销（退出时调用）。
func (r *Registrar) Deregister(ctx context.Context) error {
	r.once.Do(func() {
		close(r.done)
	})
	r.wg.Wait()

	r.cliMu.RLock()
	cli := r.cli
	r.cliMu.RUnlock()

	r.leaseMu.RLock()
	lid := r.leaseID
	r.leaseMu.RUnlock()

	if _, err := cli.Delete(ctx, r.key); err != nil {
		return err
	}
	_, _ = cli.Revoke(ctx, lid)
	return cli.Close()
}

// ============================================================================
// Service Discoverer (服务发现客户端)
// ============================================================================

// Discoverer 通过 etcd Watch 实时同步某服务的实例列表。
type Discoverer struct {
	cli       *clientv3.Client
	mu        sync.RWMutex
	instances map[string]*InstanceInfo // key: "{ip}:{port}"
	prefix    string
	done      chan struct{}
	once      sync.Once
}

// NewDiscoverer 创建服务发现客户端。
func NewDiscoverer(ctx context.Context, endpoints []string, project, env, serviceName, etcdUsername, etcdPassword string) (*Discoverer, error) {
	cli, err := newRawClient(endpoints, defaultDialTimeout, etcdUsername, etcdPassword)
	if err != nil {
		return nil, fmt.Errorf("connect etcd failed: %w", err)
	}

	prefix := fmt.Sprintf("/%s/%s/%s/", project, env, serviceName)

	d := &Discoverer{
		cli:       cli,
		instances: make(map[string]*InstanceInfo),
		prefix:    prefix,
		done:      make(chan struct{}),
	}

	resp, err := cli.Get(ctx, prefix, clientv3.WithPrefix())
	if err != nil {
		cli.Close()
		return nil, fmt.Errorf("etcd get failed: %w", err)
	}
	d.mu.Lock()
	for _, kv := range resp.Kvs {
		d.upsert(string(kv.Key), string(kv.Value))
	}
	d.mu.Unlock()

	go d.watchLoop(ctx)
	return d, nil
}

func (d *Discoverer) upsert(key, value string) {
	inst, err := DecodeInstance(key, value)
	if err != nil {
		return
	}
	d.instances[fmt.Sprintf("%s:%d", inst.Ip, inst.Port)] = inst
}

func (d *Discoverer) watchLoop(ctx context.Context) {
	for {
		select {
		case <-d.done:
			return
		case <-ctx.Done():
			return
		default:
		}

		ch := d.cli.Watch(ctx, d.prefix, clientv3.WithPrefix())
	innerWatch:
		for {
			select {
			case wresp, ok := <-ch:
				if !ok || wresp.Err() != nil {
					time.Sleep(time.Second)
					break innerWatch // 跳出内层循环，重新建立 Watch
				}
				d.mu.Lock()
				for _, ev := range wresp.Events {
					switch ev.Type {
					case mvccpb.PUT:
						d.upsert(string(ev.Kv.Key), string(ev.Kv.Value))
					case mvccpb.DELETE:
						// 从 key 末段提取 {ip}:{port} 作为删除索引
						if ipPort, ok := ParseInstanceKey(string(ev.Kv.Key)); ok {
							delete(d.instances, ipPort)
						}
					}
				}
				d.mu.Unlock()
			case <-d.done:
				return
			case <-ctx.Done():
				return
			}
		}

		// 断线重连后全量刷新一次当前实例，防止重连期间遗漏实例变更
		if resp, err := d.cli.Get(ctx, d.prefix, clientv3.WithPrefix()); err == nil {
			d.mu.Lock()
			newInsts := make(map[string]*InstanceInfo, len(resp.Kvs))
			for _, kv := range resp.Kvs {
				inst, err := DecodeInstance(string(kv.Key), string(kv.Value))
				if err == nil {
					newInsts[fmt.Sprintf("%s:%d", inst.Ip, inst.Port)] = inst
				}
			}
			d.instances = newInsts
			d.mu.Unlock()
		}
	}
}

// Instances 返回当前所有启用实例（过滤 enabled=false）。
func (d *Discoverer) Instances() []*InstanceInfo {
	d.mu.RLock()
	defer d.mu.RUnlock()
	out := make([]*InstanceInfo, 0, len(d.instances))
	for _, inst := range d.instances {
		if inst.Enabled {
			out = append(out, inst)
		}
	}
	return out
}

// AllInstances 返回所有实例（含下线）。
func (d *Discoverer) AllInstances() []*InstanceInfo {
	d.mu.RLock()
	defer d.mu.RUnlock()
	out := make([]*InstanceInfo, 0, len(d.instances))
	for _, inst := range d.instances {
		out = append(out, inst)
	}
	return out
}

// Pick 按权重随机选取一个启用实例。
func (d *Discoverer) Pick() *InstanceInfo {
	insts := d.Instances()
	if len(insts) == 0 {
		return nil
	}
	// 使用局部变量累加权重，不修改共享 InstanceInfo 对象
	type weightedInst struct {
		inst   *InstanceInfo
		weight int64
	}
	items := make([]weightedInst, 0, len(insts))
	var totalWeight int64
	for _, inst := range insts {
		w := int64(inst.Weight)
		if w <= 0 {
			w = 1
		}
		items = append(items, weightedInst{inst: inst, weight: w})
		totalWeight += w
	}
	if totalWeight <= 0 {
		return insts[0]
	}
	r := rand.Int63n(totalWeight)
	for _, item := range items {
		r -= item.weight
		if r < 0 {
			return item.inst
		}
	}
	return items[len(items)-1].inst
}

// Close 关闭 etcd 连接。
func (d *Discoverer) Close() error {
	d.once.Do(func() {
		close(d.done)
	})
	return d.cli.Close()
}
