/**
 * @Author: spruce
 * @Date: 2026-09-29 16:18
 * @Desc: 配置动态监听与业务动态配置项
 */

package xetcd

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"go.etcd.io/etcd/api/v3/mvccpb"
	clientv3 "go.etcd.io/etcd/client/v3"
)

// WatcherOption 配置 Watcher 选项。
type WatcherOption func(*Watcher)

// Watcher 通过 etcd Watch 实时同步配置变更。
// 一次 Watch 监听整个环境前缀，业务侧按 (group, dataId) 取值。
// 支持网络闪断自愈、全量重同步、Revision 连续监听以及优雅关闭。
// 日志统一使用标准库 "log" 输出规范格式 [xetcd] ...
// goroutine-safe。
type Watcher struct {
	cli      *clientv3.Client
	mu       sync.RWMutex
	data     map[string]*ConfigValue // key: "{group}/{dataId}"
	onChange func()

	ctx    context.Context
	cancel context.CancelFunc
	once   sync.Once
	wg     sync.WaitGroup
}

// SetOnChange 注册配置变更时的回调函数（热重载触发）。
func (w *Watcher) SetOnChange(fn func()) {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.onChange = fn
}

// NewWatcher 创建配置 watcher。
func NewWatcher(endpoints []string, etcdUsername, etcdPassword string, opts ...WatcherOption) (*Watcher, error) {
	cli, err := newRawClient(endpoints, defaultDialTimeout, etcdUsername, etcdPassword)
	if err != nil {
		pkgLogger("[xetcd] connect etcd failed: %v (endpoints=%v)", err, endpoints)
		return nil, fmt.Errorf("connect etcd failed: %w", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	w := &Watcher{
		cli:    cli,
		data:   make(map[string]*ConfigValue),
		ctx:    ctx,
		cancel: cancel,
	}
	for _, opt := range opts {
		opt(w)
	}

	pkgLogger("[xetcd] connected to %v (auth=%v)", endpoints, etcdUsername != "")
	return w, nil
}

// Watch 开始监听整个环境的配置：一次性 Watch 前缀 /{project}/config/content/{env}/
// 首次调用立即拉取前缀下全部配置；之后启动带自愈重连的后台协程监听配置变更，
// 并使用 Revision + 1 增量监听，彻底杜绝数据在拉取与监听窗口期丢失。
func (w *Watcher) Watch(ctx context.Context, project, env string) error {
	prefix := fmt.Sprintf("/%s/config/content/%s/", project, env)
	pkgLogger("[xetcd] start watching prefix %s", prefix)

	resp, err := w.cli.Get(ctx, prefix, clientv3.WithPrefix())
	if err != nil {
		pkgLogger("[xetcd] initial get failed under %s: %v", prefix, err)
		return fmt.Errorf("etcd get failed: %w", err)
	}
	w.mu.Lock()
	for _, kv := range resp.Kvs {
		w.upsert(string(kv.Key), kv.Value)
	}
	w.mu.Unlock()
	pkgLogger("[xetcd] loaded %d config(s) under %s", len(resp.Kvs), prefix)

	startRev := resp.Header.Revision + 1

	w.wg.Add(1)
	go func() {
		defer w.wg.Done()
		w.watchLoop(ctx, prefix, startRev)
	}()

	return nil
}

func (w *Watcher) watchLoop(userCtx context.Context, prefix string, startRev int64) {
	currentRev := startRev
	backoff := time.Second
	const maxBackoff = 10 * time.Second

	for {
		select {
		case <-userCtx.Done():
			pkgLogger("[xetcd] watch stopped by user context: %s", prefix)
			return
		case <-w.ctx.Done():
			pkgLogger("[xetcd] watcher closed, stopping watch: %s", prefix)
			return
		default:
		}

		opts := []clientv3.OpOption{clientv3.WithPrefix()}
		if currentRev > 0 {
			opts = append(opts, clientv3.WithRev(currentRev))
		}

		watchCtx, cancelWatch := context.WithCancel(w.ctx)
		ch := w.cli.Watch(watchCtx, prefix, opts...)

		for wresp := range ch {
			if wresp.Canceled || wresp.Err() != nil {
				pkgLogger("[xetcd] watch error for %s: %v", prefix, wresp.Err())
				break
			}

			if wresp.Header.Revision >= currentRev {
				currentRev = wresp.Header.Revision + 1
			}

			var hasChange bool
			w.mu.Lock()
			for _, ev := range wresp.Events {
				switch ev.Type {
				case mvccpb.PUT:
					w.upsert(string(ev.Kv.Key), ev.Kv.Value)
					hasChange = true
				case mvccpb.DELETE:
					w.remove(string(ev.Kv.Key))
					hasChange = true
				}
			}
			onChangeFn := w.onChange
			w.mu.Unlock()

			if hasChange && onChangeFn != nil {
				pkgLogger("[xetcd] config updated, triggering onChange callback")
				onChangeFn()
			}

			backoff = time.Second
		}
		cancelWatch()

		// 检查是否主动退出
		select {
		case <-userCtx.Done():
			return
		case <-w.ctx.Done():
			return
		default:
		}

		pkgLogger("[xetcd] watch channel closed for %s, reconnecting in %v...", prefix, backoff)

		select {
		case <-time.After(backoff):
		case <-userCtx.Done():
			return
		case <-w.ctx.Done():
			return
		}

		backoff *= 2
		if backoff > maxBackoff {
			backoff = maxBackoff
		}

		// 断线重连后全量重新同步，弥补离线期间遗漏的变更
		syncCtx, syncCancel := context.WithTimeout(w.ctx, 5*time.Second)
		syncResp, err := w.cli.Get(syncCtx, prefix, clientv3.WithPrefix())
		syncCancel()
		if err != nil {
			pkgLogger("[xetcd] sync after reconnect failed for %s: %v", prefix, err)
			continue
		}

		w.mu.Lock()
		currentKeys := make(map[string]struct{}, len(syncResp.Kvs))
		var hasSyncChange bool
		for _, kv := range syncResp.Kvs {
			keyStr := string(kv.Key)
			group, dataId, ok := ParseConfigKey(keyStr)
			if ok {
				currentKeys[group+"/"+dataId] = struct{}{}
			}
			if w.upsert(keyStr, kv.Value) {
				hasSyncChange = true
			}
		}
		// 移除 etcd 中已删除的 key
		for cachedKey := range w.data {
			if _, exists := currentKeys[cachedKey]; !exists {
				delete(w.data, cachedKey)
				hasSyncChange = true
			}
		}
		onChangeFn := w.onChange
		w.mu.Unlock()

		currentRev = syncResp.Header.Revision + 1
		pkgLogger("[xetcd] re-synced %d config(s) under %s (changed=%v)", len(syncResp.Kvs), prefix, hasSyncChange)
		if hasSyncChange && onChangeFn != nil {
			onChangeFn()
		}
	}
}

func (w *Watcher) upsert(key string, val []byte) bool {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return false
	}
	v, err := DecodeConfigValue(string(val))
	if err != nil {
		pkgLogger("[xetcd] decode config failed: key=%s err=%v", key, err)
		return false
	}
	cacheKey := group + "/" + dataId
	oldVal := w.data[cacheKey]
	if oldVal != nil && oldVal.Version == v.Version && oldVal.Md5 == v.Md5 && oldVal.Content == v.Content {
		return false
	}
	w.data[cacheKey] = v
	pkgLogger("[xetcd] loaded %s/%s (version=%d, format=%s, size=%d)", group, dataId, v.Version, v.Format, len(v.Content))
	return true
}

func (w *Watcher) remove(key string) bool {
	group, dataId, ok := ParseConfigKey(key)
	if !ok {
		return false
	}
	cacheKey := group + "/" + dataId
	if _, exists := w.data[cacheKey]; !exists {
		return false
	}
	delete(w.data, cacheKey)
	pkgLogger("[xetcd] removed %s/%s", group, dataId)
	return true
}

// Get 读取已缓存的配置值。goroutine-safe。
func (w *Watcher) Get(group, dataId string) *ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	return w.data[group+"/"+dataId]
}

// GetContent 返回配置内容字符串（快捷方法）。
func (w *Watcher) GetContent(group, dataId string) string {
	if v := w.Get(group, dataId); v != nil {
		return v.Content
	}
	return ""
}

// All 返回当前缓存的所有配置项（快照副本）。goroutine-safe。
func (w *Watcher) All() map[string]*ConfigValue {
	w.mu.RLock()
	defer w.mu.RUnlock()
	out := make(map[string]*ConfigValue, len(w.data))
	for k, v := range w.data {
		out[k] = v
	}
	return out
}

// Close 关闭 watcher 监听与 etcd 连接。
func (w *Watcher) Close() error {
	var err error
	w.once.Do(func() {
		pkgLogger("[xetcd] closing watcher connection")
		w.cancel()
		w.wg.Wait()
		err = w.cli.Close()
	})
	return err
}

// Scan 将已缓存的配置内容按 format（yaml/json/properties）反序列化到 out。
func (w *Watcher) Scan(group, dataId string, out any) error {
	v := w.Get(group, dataId)
	if v == nil {
		return fmt.Errorf("config %s/%s not found, did you call Watch?", group, dataId)
	}
	if out == nil {
		return fmt.Errorf("out must not be nil")
	}
	return UnmarshalConfigContent(v.Format, v.Content, out)
}

// ============================================================================
// Dynamic Values (业务动态配置项封装)
// ============================================================================

// DynamicString 一个热更新的字符串配置项。
type DynamicString struct {
	watcher *Watcher
	group   string
	dataId  string
}

// NewDynamicString 创建监听指定配置项的动态字符串。
func (w *Watcher) NewDynamicString(group, dataId string) *DynamicString {
	return &DynamicString{watcher: w, group: group, dataId: dataId}
}

// Val 返回最新配置值。
func (d *DynamicString) Val() string {
	if d.watcher == nil {
		return ""
	}
	return d.watcher.GetContent(d.group, d.dataId)
}

// DynamicInt 一个热更新的整数配置项。
type DynamicInt struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal int
}

// NewDynamicInt 创建监听指定配置项的动态整数。
func (w *Watcher) NewDynamicInt(group, dataId string, defaultVal int) *DynamicInt {
	return &DynamicInt{watcher: w, group: group, dataId: dataId, defaultVal: defaultVal}
}

// Val 返回最新整数值，解析失败时返回 defaultVal。
func (d *DynamicInt) Val() int {
	if d.watcher == nil {
		return d.defaultVal
	}
	str := d.watcher.GetContent(d.group, d.dataId)
	if str == "" {
		return d.defaultVal
	}
	val, err := strconv.Atoi(strings.TrimSpace(str))
	if err != nil {
		return d.defaultVal
	}
	return val
}

// DynamicBool 一个热更新的布尔配置项。
type DynamicBool struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal bool
}

// NewDynamicBool 创建监听指定配置项的动态布尔值。
func (w *Watcher) NewDynamicBool(group, dataId string, defaultVal bool) *DynamicBool {
	return &DynamicBool{watcher: w, group: group, dataId: dataId, defaultVal: defaultVal}
}

// Val 返回最新布尔值，解析失败时返回 defaultVal。
func (d *DynamicBool) Val() bool {
	if d.watcher == nil {
		return d.defaultVal
	}
	str := d.watcher.GetContent(d.group, d.dataId)
	if str == "" {
		return d.defaultVal
	}
	val, err := strconv.ParseBool(strings.TrimSpace(str))
	if err != nil {
		return d.defaultVal
	}
	return val
}

// DynamicDuration 一个热更新的时间间隔配置项。
type DynamicDuration struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal time.Duration
}

// NewDynamicDuration 创建监听指定配置项的动态时间间隔。
func (w *Watcher) NewDynamicDuration(group, dataId string, defaultVal time.Duration) *DynamicDuration {
	return &DynamicDuration{watcher: w, group: group, dataId: dataId, defaultVal: defaultVal}
}

// Val 返回最新时间间隔值，解析失败时返回 defaultVal。
func (d *DynamicDuration) Val() time.Duration {
	if d.watcher == nil {
		return d.defaultVal
	}
	str := d.watcher.GetContent(d.group, d.dataId)
	if str == "" {
		return d.defaultVal
	}
	val, err := time.ParseDuration(strings.TrimSpace(str))
	if err != nil {
		return d.defaultVal
	}
	return val
}

// DynamicValue 泛型动态配置项，当内容变更时自动反序列化为结构体/复杂对象并本地缓存。
type DynamicValue[T any] struct {
	watcher    *Watcher
	group      string
	dataId     string
	defaultVal T
	mu         sync.RWMutex
	lastRaw    string
	cached     T
}

// NewDynamicValue 创建泛型动态配置对象。
func NewDynamicValue[T any](w *Watcher, group, dataId string, defaultVal T) *DynamicValue[T] {
	return &DynamicValue[T]{
		watcher:    w,
		group:      group,
		dataId:     dataId,
		defaultVal: defaultVal,
		cached:     defaultVal,
	}
}

// Val 返回解析后的最新配置对象（并发安全且带本地缓存）。
func (d *DynamicValue[T]) Val() T {
	if d.watcher == nil {
		return d.defaultVal
	}
	cv := d.watcher.Get(d.group, d.dataId)
	if cv == nil {
		return d.defaultVal
	}

	d.mu.RLock()
	if cv.Content == d.lastRaw {
		val := d.cached
		d.mu.RUnlock()
		return val
	}
	d.mu.RUnlock()

	d.mu.Lock()
	defer d.mu.Unlock()
	if cv.Content == d.lastRaw {
		return d.cached
	}

	var parsed T
	if err := UnmarshalConfigContent(cv.Format, cv.Content, &parsed); err != nil {
		return d.defaultVal
	}
	d.cached = parsed
	d.lastRaw = cv.Content
	return d.cached
}
