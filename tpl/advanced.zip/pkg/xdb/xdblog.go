/**
 * @Author:
 * @Date: 2024-03-28 15:06
 * @Desc: 数据库日志适配器(集成 GORM 与统一 xlog)
 */

package xdb

import (
	"context"
	"errors"
	"fmt"
	"runtime"
	"strconv"
	"strings"
	"time"

	"advanced/pkg/xlog"

	"gorm.io/gorm/logger"
)

type xdbLogger struct {
	logger.Config
}

// findCaller 向上回溯调用栈，跳过 GORM 内部框架、runtime 以及 pkg/xdb、pkg/xlog 适配层、代码生成层(_gen.go)，
// 精准定位到触发数据库操作的真实业务代码文件与行号（如 service 层业务函数或手写 repository 层），并返回相对于当前调用点的跳层深度 skip。
func findCaller() (string, int) {
	for i := 2; i < 25; i++ {
		_, file, line, ok := runtime.Caller(i)
		if !ok {
			break
		}
		norm := strings.ReplaceAll(file, "\\", "/")
		// 过滤 gorm 内部源码、runtime 源码以及项目自身的 xdb/xlog 适配层、自动生成的 _gen.go 单表 CRUD 样板代码
		if strings.Contains(norm, "gorm.io") ||
			strings.HasSuffix(norm, "xdblog.go") || strings.HasSuffix(norm, "xdb.go") ||
			strings.Contains(norm, "pkg/xlog") ||
			strings.HasSuffix(norm, "_gen.go") ||
			strings.Contains(norm, "runtime/") {
			continue
		}
		// i 为相对于 findCaller 调用的栈深度，对于调用 findCaller 的上一层（如 Trace/Info/Warn/Error），
		// 其相对于真实业务代码的额外跳层深度恰好为 i - 1。
		return trimCallerPath(norm, line), i - 1
	}
	return "", 0
}

// trimCallerPath 裁剪绝对路径前缀，保留如 "/repository/db/demo.go:125"
func trimCallerPath(file string, line int) string {
	norm := strings.ReplaceAll(file, "\\", "/")
	// 查找典型的业务目录前缀
	for _, marker := range []string{"/repository/", "/service/", "/handler/", "/internal/", "/cmd/"} {
		if idx := strings.Index(norm, marker); idx != -1 {
			return fmt.Sprintf("%s:%d", norm[idx:], line)
		}
	}
	// 兜底保留最后 3 级路径
	parts := strings.Split(norm, "/")
	if len(parts) > 3 {
		return fmt.Sprintf("/%s:%d", strings.Join(parts[len(parts)-3:], "/"), line)
	}
	return fmt.Sprintf("%s:%d", norm, line)
}

// initLog 构建走 xlog 的 GORM logger。
func initLog(_ logger.Writer, config logger.Config) logger.Interface {
	return &xdbLogger{
		Config: config,
	}
}

func (l *xdbLogger) LogMode(level logger.LogLevel) logger.Interface {
	newLogger := *l
	newLogger.LogLevel = level
	return &newLogger
}

func (l *xdbLogger) Info(ctx context.Context, msg string, data ...any) {
	if l.LogLevel >= logger.Info {
		caller, skip := findCaller()
		prefix := "[info] "
		if skip == 0 && caller != "" {
			prefix = caller + " [info] "
		}
		content := prefix + fmt.Sprintf(msg, data...)
		xlog.InfoWithSkip(ctx, skip, content)
	}
}

func (l *xdbLogger) Warn(ctx context.Context, msg string, data ...any) {
	if l.LogLevel >= logger.Warn {
		caller, skip := findCaller()
		prefix := "[warn] "
		if skip == 0 && caller != "" {
			prefix = caller + " [warn] "
		}
		content := prefix + fmt.Sprintf(msg, data...)
		xlog.WarnWithSkip(ctx, skip, content)
	}
}

func (l *xdbLogger) Error(ctx context.Context, msg string, data ...any) {
	if l.LogLevel >= logger.Error {
		caller, skip := findCaller()
		prefix := "[error] "
		if skip == 0 && caller != "" {
			prefix = caller + " [error] "
		}
		content := prefix + fmt.Sprintf(msg, data...)
		xlog.ErrorWithSkip(ctx, skip, content, nil)
	}
}

func (l *xdbLogger) Trace(ctx context.Context, begin time.Time, fc func() (string, int64), err error) {
	if l.LogLevel <= logger.Silent {
		return
	}

	elapsed := time.Since(begin)
	duration := float64(elapsed.Nanoseconds()) / 1e6
	isNotFound := errors.Is(err, logger.ErrRecordNotFound)

	// 判断是否需要记录日志
	isErr := err != nil && l.LogLevel >= logger.Error && !(isNotFound && l.IgnoreRecordNotFoundError)
	isSlow := l.SlowThreshold != 0 && elapsed > l.SlowThreshold && l.LogLevel >= logger.Warn
	isInfo := l.LogLevel == logger.Info

	if !isErr && !isSlow && !isInfo {
		return
	}

	caller, skip := findCaller()

	sql, rows := fc()
	rowsStr := "-"
	if rows != -1 {
		rowsStr = strconv.FormatInt(rows, 10)
	}

	// 优先由 xlog.InfoWithSkip 让 zap 的 Caller 字段直接精准显示真实业务调用代码(如 /repository/db/demo.go:188)
	// 仅在未能找到业务跳层(skip == 0)时兜底将 caller 拼入 msg
	prefix := ""
	if skip == 0 && caller != "" {
		prefix = caller + " "
	}

	switch {
	case isErr:
		msg := fmt.Sprintf("%s%v [%.3fms] [rows:%s] %s", prefix, err, duration, rowsStr, sql)
		xlog.ErrorWithSkip(ctx, skip, msg, err)
	case isSlow:
		msg := fmt.Sprintf("%sSLOW SQL >= %v [%.3fms] [rows:%s] %s", prefix, l.SlowThreshold, duration, rowsStr, sql)
		xlog.WarnWithSkip(ctx, skip, msg)
	case isInfo:
		msg := fmt.Sprintf("%s[%.3fms] [rows:%s] %s", prefix, duration, rowsStr, sql)
		xlog.InfoWithSkip(ctx, skip, msg)
	}
}
