/**
 * @Author:
 * @Date: 2024-03-28 17:01
 * @Desc: 数据库操作
 */

package xdb

import (
	"context"
	"fmt"
	"strings"
	"time"

	"advanced/pkg/xconfig"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	gormLogger "gorm.io/gorm/logger"
	"gorm.io/plugin/dbresolver"
	"gorm.io/plugin/opentelemetry/tracing"
)

type (
	Client    = gorm.DB
	DeletedAt = gorm.DeletedAt
)

var ErrRecordNotFound = gorm.ErrRecordNotFound

// newDialector 根据驱动类型分发构建 GORM Dialector。
// 切换数据库时，只需在此处切换对应的 openXxx 函数调用即可，无需改动 New() 主流程。
func newDialector(driver, dsn string) (gorm.Dialector, error) {
	switch strings.ToLower(strings.TrimSpace(driver)) {
	case "mysql", "":
		return openMySQL(dsn), nil

	// 如需切换数据库驱动：在 import 中引入对应驱动包，取消对应分支与下方函数的注释即可：
	// case "postgres", "pgsql", "postgresql":
	// 	return openPostgres(dsn), nil
	// case "sqlite", "sqlite3":
	// 	return openSQLite(dsn), nil
	// case "clickhouse":
	// 	return openClickHouse(dsn), nil

	default:
		return nil, fmt.Errorf("不支持的数据库驱动类型: %s", driver)
	}
}

// openMySQL 构建 MySQL Dialector
func openMySQL(dsn string) gorm.Dialector {
	return mysql.New(mysql.Config{
		DSN:                       dsn,
		DefaultStringSize:         1024, // string 类型字段的默认长度
		DisableDatetimePrecision:  true, // 禁用 datetime 精度，兼容低版本 MySQL
		DontSupportRenameIndex:    true, // 重命名索引时采用删除并新建的方式
		DontSupportRenameColumn:   true, // 用 `change` 重命名列
		SkipInitializeWithVersion: true, // 跳过版本自动探测(automatic server version initialization);配置固定,不依赖运行时 MySQL 版本自适应
	})
}

// openPostgres 构建 PostgreSQL Dialector (需引入 "gorm.io/driver/postgres")
// func openPostgres(dsn string) gorm.Dialector {
// 	return postgres.New(postgres.Config{
// 		DSN:                  dsn,
// 		PreferSimpleProtocol: true, // 禁用隐式 prepared statement 缓存
// 	})
// }

// openSQLite 构建 SQLite Dialector (需引入 "gorm.io/driver/sqlite" 或 "github.com/glebarez/sqlite")
// func openSQLite(dsn string) gorm.Dialector {
// 	if !strings.Contains(dsn, "?") {
// 		dsn += "?_journal_mode=WAL&_busy_timeout=5000&_foreign_keys=1&_cache=shared"
// 	}
// 	return sqlite.Open(dsn)
// }

// openClickHouse 构建 ClickHouse Dialector (需引入 "gorm.io/driver/clickhouse")
// func openClickHouse(dsn string) gorm.Dialector {
// 	return clickhouse.Open(dsn)
// }

func New(conf *xconfig.Conf) (*Client, error) {
	if len(conf.Database.Source) == 0 {
		return nil, fmt.Errorf("数据库配置错误: source 不能为空")
	}

	logLevel := gormLogger.Warn
	if conf.Database.LogLevel == "debug" {
		logLevel = gormLogger.Info
	}

	// xdbLogger 所有日志方法走 xlog,不需要 writer,传 nil 即可。
	newLogger := initLog(
		nil,
		gormLogger.Config{
			SlowThreshold:             200 * time.Millisecond, // 慢 SQL 阈值
			IgnoreRecordNotFoundError: true,                   // 忽略 ErrRecordNotFound 记录到日志
			LogLevel:                  logLevel,               // Log level  gormlog.Silent
		},
	)

	masterDialector, err := newDialector(conf.Database.Driver, conf.Database.Source[0])
	if err != nil {
		return nil, fmt.Errorf("初始化主库驱动失败: %w", err)
	}

	db, err := gorm.Open(masterDialector, &gorm.Config{
		Logger:                   newLogger,
		QueryFields:              true,
		DisableNestedTransaction: true, // 禁用嵌套事务
	})
	if err != nil {
		return nil, fmt.Errorf("初始化数据库失败: %w", err)
	}
	connMaxLifetime := conf.Database.ConnMaxLifetime
	if connMaxLifetime <= 0 {
		connMaxLifetime = 3600 // 默认 1 小时
	}

	// 从库只读副本配置 (优先读取 replicas，若未配置且 source > 1 则兼容取第 2 条起为从库)
	replicasSources := conf.Database.Replicas
	if len(replicasSources) == 0 && len(conf.Database.Source) > 1 {
		replicasSources = conf.Database.Source[1:]
	}

	if len(replicasSources) > 0 {
		replicas := make([]gorm.Dialector, 0, len(replicasSources))
		for _, src := range replicasSources {
			replicaDialector, err := newDialector(conf.Database.Driver, src)
			if err != nil {
				return nil, fmt.Errorf("初始化从库驱动失败: %w", err)
			}
			replicas = append(replicas, replicaDialector)
		}
		// dbresolver 连接池设置作用于从库副本(Replicas)连接池;
		// 主库连接池由下方的 sqlDB 直接设置,两者作用域不同,分属不同连接池。
		err = db.Use(dbresolver.Register(dbresolver.Config{
			Replicas: replicas,
			Policy:   dbresolver.RandomPolicy{},
		}).
			SetMaxIdleConns(conf.Database.MaxIdleConns).
			SetMaxOpenConns(conf.Database.MaxOpenConns).
			SetConnMaxLifetime(time.Duration(connMaxLifetime) * time.Second).
			SetConnMaxIdleTime(time.Minute * 10))
		if err != nil {
			return nil, fmt.Errorf("初始化从数据库失败: %w", err)
		}
	}

	// 添加 OpenTelemetry 插件
	if err = db.Use(tracing.NewPlugin()); err != nil {
		return nil, fmt.Errorf("初始化 tracing 插件失败: %w", err)
	}

	// 设置主库底层 sql.DB 连接池(若未启用 dbresolver,这也是唯一生效的连接池)
	sqlDB, err := db.DB()
	if err != nil {
		return nil, fmt.Errorf("获取sql.DB失败: %w", err)
	}
	sqlDB.SetMaxIdleConns(conf.Database.MaxIdleConns) // 设置空闲连接池中连接的最大数量
	sqlDB.SetMaxOpenConns(conf.Database.MaxOpenConns) // 设置打开数据库连接的最大数量
	sqlDB.SetConnMaxLifetime(time.Duration(connMaxLifetime) * time.Second)
	// 限制空闲连接最大存活时间,避免长期空闲的连接被 MySQL wait_timeout 单方面关闭后,
	// 下次复用时拿到坏连接报 bad connection。
	sqlDB.SetConnMaxIdleTime(time.Minute * 10)

	// 启动阶段快速失败 (Fail-Fast): 校验主库网络连通性与认证,防止依赖未就绪时服务带病启动
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err = sqlDB.PingContext(ctx); err != nil {
		return nil, fmt.Errorf("ping 数据库主库[%v]失败: %w", conf.Database.Source[0], err)
	}

	return db, nil
}
