/**
 * @Author:
 * @Date: 2024-03-28 10:00
 * @Desc: encrypt (移除 Go 1.24 废弃的 CFB/OFB 模式，采用最新的 AEAD 与流加密标准)
 */

package encrypt

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/des"
	"crypto/hkdf"
	"crypto/hmac"
	"crypto/md5"
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"io"

	"golang.org/x/crypto/chacha20poly1305"

	"github.com/speps/go-hashids/v2"
)

// 对字符串进行MD5加密(直接基于 md5.Sum 计算,避免堆分配)
func MD5(str string) string {
	h := md5.Sum([]byte(str))
	return hex.EncodeToString(h[:])
}

// 16位md5
func MD5to16(str string) string {
	return MD5(str)[8:24]
}

// sha256加密
func Sha256(data, secret string) string {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

// sha512加密
func Sha512(data, secret string) string {
	h := hmac.New(sha512.New, []byte(secret))
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

// Sha1加密
func Sha1(data, secret string) string {
	h := hmac.New(sha1.New, []byte(secret))
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

// PBKDF2 基于口令的密钥派生 (RFC 8018，Go 1.24+ 标准库 crypto/pbkdf2)
func PBKDF2(str, salt string, iterations, keySize int) string {
	cipherText, err := pbkdf2.Key(sha256.New, str, []byte(salt), iterations, keySize)
	if err != nil {
		return ""
	}
	return fmt.Sprintf("%x", md5.Sum(cipherText))
}

// HKDF 密钥派生 (RFC 5869，Go 1.24+ 标准库 crypto/hkdf)
func HKDF(secret, salt []byte, info string, keyLength int) ([]byte, error) {
	return hkdf.Key(sha256.New, secret, salt, info, keyLength)
}

// ==========================================
// AES 加密
// ==========================================

// AESEncrypt 默认推荐使用最新的现代 AEAD 认证加密 (AES-GCM 模式，自带防篡改校验与高性能硬件加速)
func AESEncrypt(plainText, encryptKey string, additionalData ...[]byte) (string, error) {
	return AESEncryptGCM(plainText, encryptKey, additionalData...)
}

// AESDecrypt 默认使用最新的现代 AEAD 认证加密 (AES-GCM 模式)
func AESDecrypt(cipherText, encryptKey string, additionalData ...[]byte) (string, error) {
	return AESDecryptGCM(cipherText, encryptKey, additionalData...)
}

// AESEncryptCBC AES CBC 模式加密 (Cipher Block Chaining，保留用于兼容传统系统)
// 随机 IV, 密文格式: base64(iv + ciphertext)
func AESEncryptCBC(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	blockMode := cipher.NewCBCEncrypter(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.CryptBlocks(cipherText, originStr)

	// 将 iv 拼接到密文前,解密时可自动提取
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// AESDecryptCBC AES CBC 模式解密 — 自动从密文前提取 iv
func AESDecryptCBC(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		// 兼容旧格式:显式传入 IV
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("iv length mismatch")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		// 新格式:密文前 blockSize 字节为 iv
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}
	if len(encrypted)%blockSize != 0 {
		return "", errors.New("cipherText is not a multiple of the block size")
	}

	blockModel := cipher.NewCBCDecrypter(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.CryptBlocks(originStr, encrypted)
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// AESEncryptECB ECB 模式加密 (不安全，仅用于兼容老旧协议)
func AESEncryptECB(plainText, encryptKey string) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)
	cipherText := make([]byte, len(originStr))
	for bs, be := 0, blockSize; bs < len(originStr); bs, be = bs+blockSize, be+blockSize {
		block.Encrypt(cipherText[bs:be], originStr[bs:be])
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

// AESDecryptECB ECB 模式解密
func AESDecryptECB(cipherText, encryptKey string) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := make([]byte, len(baseByte))
	for bs, be := 0, blockSize; bs < len(baseByte); bs, be = bs+blockSize, be+blockSize {
		block.Decrypt(originStr[bs:be], baseByte[bs:be])
	}
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// AESEncryptCTR CTR 计数器流加密模式 (Go 1.24 推荐的流模式替代方案)
// 密文格式: base64(iv + ciphertext)
func AESEncryptCTR(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]

	// CTR 为流模式,明文长度=密文长度,不做块填充
	originStr := []byte(plainText)
	blockMode := cipher.NewCTR(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.XORKeyStream(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// AESDecryptCTR CTR 模式解密 — 自动从密文前提取 iv
func AESDecryptCTR(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("iv length mismatch")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}

	blockModel := cipher.NewCTR(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.XORKeyStream(originStr, encrypted)
	// CTR 为流模式,无需去填充
	return string(originStr), nil
}

// GCM:伽罗瓦/计数器模式（Galois/Counter Mode）AEAD 认证加密 (推荐,自带防篡改校验+硬件加速高性能)
// AES GCM Encrypt — 密文格式: base64(nonce + ciphertext + tag)
// encryptKey 长度必须是 16 (AES-128)、24 (AES-192) 或 32 (AES-256) 字节
// 可选 additionalData (AAD): 附加认证数据(不被加密但参与完整性防篡改校验)
func AESEncryptGCM(plainText, encryptKey string, additionalData ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	nonce := make([]byte, aesGCM.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}

	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}

	// Seal 将密文和 16 字节 Auth Tag 追加到 nonce 之后
	cipherBytes := aesGCM.Seal(nonce, nonce, []byte(plainText), aad)
	return base64.StdEncoding.EncodeToString(cipherBytes), nil
}

// AES GCM Decrypt — 自动从密文前提取 nonce，并校验数据完整性与解密
// 支持兼容标准 Base64、URL 安全 Base64 与 RawURL Base64
func AESDecryptGCM(cipherText, encryptKey string, additionalData ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	data, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		data, err = base64.URLEncoding.DecodeString(cipherText)
		if err != nil {
			data, err = base64.RawURLEncoding.DecodeString(cipherText)
			if err != nil {
				return "", err
			}
		}
	}

	nonceSize := aesGCM.NonceSize()
	if len(data) < nonceSize+aesGCM.Overhead() {
		return "", errors.New("cipherText too short")
	}

	nonce, cipherBytes := data[:nonceSize], data[nonceSize:]

	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}

	plainBytes, err := aesGCM.Open(nil, nonce, cipherBytes, aad)
	if err != nil {
		return "", fmt.Errorf("aes gcm decrypt failed: %w", err)
	}

	return string(plainBytes), nil
}

// AES256GCMEncrypt AES-256-GCM 加密，强制要求 32 字节(256 bit)密钥
func AES256GCMEncrypt(plainText, encryptKey string, additionalData ...[]byte) (string, error) {
	if len(encryptKey) != 32 {
		return "", errors.New("AES-256 requires a 32-byte (256-bit) key")
	}
	return AESEncryptGCM(plainText, encryptKey, additionalData...)
}

// AES256GCMDecrypt AES-256-GCM 解密，强制要求 32 字节(256 bit)密钥
func AES256GCMDecrypt(cipherText, encryptKey string, additionalData ...[]byte) (string, error) {
	if len(encryptKey) != 32 {
		return "", errors.New("AES-256 requires a 32-byte (256-bit) key")
	}
	return AESDecryptGCM(cipherText, encryptKey, additionalData...)
}

// ==========================================
// ChaCha20-Poly1305 认证加密 (AEAD 最新标准，RFC 8439)
// ==========================================

// ChaCha20Poly1305Encrypt 现代高性能 AEAD 认证加密 (RFC 8439, 适用移动端/无 AES-NI 硬件加速场景)
// encryptKey 长度必须为 32 字节 (256 bit)
func ChaCha20Poly1305Encrypt(plainText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.New(encryptKey)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	cipherBytes := aead.Seal(nonce, nonce, []byte(plainText), aad)
	return base64.StdEncoding.EncodeToString(cipherBytes), nil
}

// ChaCha20Poly1305Decrypt 解密
func ChaCha20Poly1305Decrypt(cipherText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.New(encryptKey)
	if err != nil {
		return "", err
	}
	data, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		data, err = base64.URLEncoding.DecodeString(cipherText)
		if err != nil {
			data, err = base64.RawURLEncoding.DecodeString(cipherText)
			if err != nil {
				return "", err
			}
		}
	}
	nonceSize := aead.NonceSize()
	if len(data) < nonceSize+aead.Overhead() {
		return "", errors.New("cipherText too short")
	}
	nonce, cipherBytes := data[:nonceSize], data[nonceSize:]
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	plainBytes, err := aead.Open(nil, nonce, cipherBytes, aad)
	if err != nil {
		return "", fmt.Errorf("chacha20poly1305 decrypt failed: %w", err)
	}
	return string(plainBytes), nil
}

// XChaCha20Poly1305Encrypt 扩展 Nonce (192-bit / 24 字节) AEAD 变体，随机 Nonce 碰撞概率极低，推荐用于大规模加密场景
func XChaCha20Poly1305Encrypt(plainText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.NewX(encryptKey)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	cipherBytes := aead.Seal(nonce, nonce, []byte(plainText), aad)
	return base64.StdEncoding.EncodeToString(cipherBytes), nil
}

// XChaCha20Poly1305Decrypt 解密
func XChaCha20Poly1305Decrypt(cipherText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.NewX(encryptKey)
	if err != nil {
		return "", err
	}
	data, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		data, err = base64.URLEncoding.DecodeString(cipherText)
		if err != nil {
			data, err = base64.RawURLEncoding.DecodeString(cipherText)
			if err != nil {
				return "", err
			}
		}
	}
	nonceSize := aead.NonceSize()
	if len(data) < nonceSize+aead.Overhead() {
		return "", errors.New("cipherText too short")
	}
	nonce, cipherBytes := data[:nonceSize], data[nonceSize:]
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	plainBytes, err := aead.Open(nil, nonce, cipherBytes, aad)
	if err != nil {
		return "", fmt.Errorf("xchacha20poly1305 decrypt failed: %w", err)
	}
	return string(plainBytes), nil
}

// ==========================================
// DES 加密 (传统兼容)
// ==========================================

// DES CBC Encrypt — 密文格式: base64(iv + ciphertext)
func DESEncrypt(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]
	blockMode := cipher.NewCBCEncrypter(block, ivValue)

	cipherText := make([]byte, len(originStr))
	blockMode.CryptBlocks(cipherText, originStr)

	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// DES CBC Decrypt — 自动从密文前提取 iv
func DESDecrypt(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}
	if len(encrypted)%blockSize != 0 {
		return "", errors.New("cipherText is not a multiple of the block size")
	}

	blockModel := cipher.NewCBCDecrypter(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.CryptBlocks(originStr, encrypted)

	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// DES ECB Encrypt (不安全)
func DESEncryptECB(plainText, encryptKey string) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)
	cipherText := make([]byte, len(originStr))
	for bs, be := 0, blockSize; bs < len(originStr); bs, be = bs+blockSize, be+blockSize {
		block.Encrypt(cipherText[bs:be], originStr[bs:be])
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

// DES ECB Decrypt
func DESDecryptECB(cipherText, encryptKey string) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := make([]byte, len(baseByte))
	for bs, be := 0, blockSize; bs < len(baseByte); bs, be = bs+blockSize, be+blockSize {
		block.Decrypt(originStr[bs:be], baseByte[bs:be])
	}
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// DES CTR Encrypt — 密文格式: base64(iv + ciphertext)
func DESEncryptCTR(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]

	// CTR 为流模式,明文长度=密文长度,不做块填充
	originStr := []byte(plainText)
	blockMode := cipher.NewCTR(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.XORKeyStream(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// DES CTR Decrypt — 自动从密文前提取 iv
func DESDecryptCTR(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}

	blockModel := cipher.NewCTR(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.XORKeyStream(originStr, encrypted)
	// CTR 为流模式,无需去填充
	return string(originStr), nil
}

// ==========================================
// 3DES 加密 (传统兼容)
// ==========================================

// 3DES CBC Encrypt — 密文格式: base64(iv + ciphertext)
func DES3Encrypt(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]
	blockMode := cipher.NewCBCEncrypter(block, ivValue)

	cipherText := make([]byte, len(originStr))
	blockMode.CryptBlocks(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// 3DES CBC Decrypt — 自动从密文前提取 iv
func DES3Decrypt(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}
	if len(encrypted)%blockSize != 0 {
		return "", errors.New("cipherText is not a multiple of the block size")
	}

	blockModel := cipher.NewCBCDecrypter(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.CryptBlocks(originStr, encrypted)

	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// 3DES ECB Encrypt (不安全)
func DES3EncryptECB(plainText, encryptKey string) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)
	cipherText := make([]byte, len(originStr))
	for bs, be := 0, blockSize; bs < len(originStr); bs, be = bs+blockSize, be+blockSize {
		block.Encrypt(cipherText[bs:be], originStr[bs:be])
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

// 3DES ECB Decrypt
func DES3DecryptECB(cipherText, encryptKey string) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := make([]byte, len(baseByte))
	for bs, be := 0, blockSize; bs < len(baseByte); bs, be = bs+blockSize, be+blockSize {
		block.Decrypt(originStr[bs:be], baseByte[bs:be])
	}
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// 3DES CTR Encrypt — 密文格式: base64(iv + ciphertext)
func DES3EncryptCTR(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]

	// CTR 为流模式,明文长度=密文长度,不做块填充
	originStr := []byte(plainText)
	blockMode := cipher.NewCTR(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.XORKeyStream(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// 3DES CTR Decrypt — 自动从密文前提取 iv
func DES3DecryptCTR(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}

	blockModel := cipher.NewCTR(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.XORKeyStream(originStr, encrypted)

	// CTR 为流模式,无需去填充
	return string(originStr), nil
}

// ==========================================
// 填充辅助方法
// ==========================================

func PKCS5Padding(src []byte, blockSize int) []byte {
	return PKCS7Padding(src, blockSize)
}

func PKCS5UnPadding(src []byte) ([]byte, error) {
	return PKCS7UnPadding(src)
}

func PKCS7Padding(src []byte, blockSize int) []byte {
	padding := blockSize - len(src)%blockSize
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(src, padText...)
}

func PKCS7UnPadding(src []byte) ([]byte, error) {
	length := len(src)
	if length == 0 {
		return src, errors.New("invalid data len")
	}
	unPadding := int(src[length-1])
	if unPadding < 1 || unPadding > length {
		return src, errors.New("invalid padding")
	}
	return src[:(length - unPadding)], nil
}

func ZerosPadding(src []byte, blockSize int) []byte {
	paddingCount := blockSize - len(src)%blockSize
	if paddingCount == 0 {
		return src
	}
	return append(src, bytes.Repeat([]byte{0}, paddingCount)...)
}

func ZerosUnPadding(src []byte) ([]byte, error) {
	for i := len(src) - 1; i >= 0; i-- {
		if src[i] != 0 {
			return src[:i+1], nil
		}
	}
	return nil, nil
}

// ==========================================
// Hashids 混淆编解码 (将整数 ID 混淆编码为短字符串，防遍历与自增暴露)
// ==========================================

// HashID 封装 Hashids 实例
type HashID struct {
	h *hashids.HashID
}

// Hashids 创建一个 HashID 实例 (基于 salt 盐值与最小长度 minLength，可选自定义 alphabet 字母表)
// 用于将数据库自增 ID 混淆编码为非连续、URL 安全的短字符串，防止敏感数字被猜测或枚举遍历
func Hashids(salt string, minLength int, alphabet ...string) (*HashID, error) {
	hd := hashids.NewData()
	hd.Salt = salt
	hd.MinLength = minLength
	if len(alphabet) > 0 && alphabet[0] != "" {
		hd.Alphabet = alphabet[0]
	}
	h, err := hashids.NewWithData(hd)
	if err != nil {
		return nil, err
	}
	return &HashID{h: h}, nil
}

// Encode 将一组 int 数字编码为 Hashid 短字符串
func (hid *HashID) Encode(numbers ...int) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.Encode(numbers)
}

// EncodeInt64 将一组 int64 数字编码为 Hashid 短字符串
func (hid *HashID) EncodeInt64(numbers ...int64) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.EncodeInt64(numbers)
}

// Decode 将 Hashid 字符串解码为一组 int 数字
func (hid *HashID) Decode(hash string) ([]int, error) {
	if hid == nil || hid.h == nil {
		return nil, errors.New("hashid instance is nil")
	}
	return hid.h.DecodeWithError(hash)
}

// DecodeInt64 将 Hashid 字符串解码为一组 int64 数字
func (hid *HashID) DecodeInt64(hash string) ([]int64, error) {
	if hid == nil || hid.h == nil {
		return nil, errors.New("hashid instance is nil")
	}
	return hid.h.DecodeInt64WithError(hash)
}

// EncodeHex 将十六进制字符串编码为 Hashid
func (hid *HashID) EncodeHex(hexStr string) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.EncodeHex(hexStr)
}

// DecodeHex 将 Hashid 解码为十六进制字符串
func (hid *HashID) DecodeHex(hash string) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.DecodeHex(hash)
}

// HashidsEncode 便捷函数：使用指定 salt 与 minLength 直接将一组 int64 数字编码为 Hashid
func HashidsEncode(salt string, minLength int, numbers ...int64) (string, error) {
	h, err := Hashids(salt, minLength)
	if err != nil {
		return "", err
	}
	return h.EncodeInt64(numbers...)
}

// HashidsDecode 便捷函数：使用指定 salt 与 minLength 直接将 Hashid 解码还原为一组 int64 数字
func HashidsDecode(salt string, minLength int, hash string) ([]int64, error) {
	h, err := Hashids(salt, minLength)
	if err != nil {
		return nil, err
	}
	return h.DecodeInt64(hash)
}

