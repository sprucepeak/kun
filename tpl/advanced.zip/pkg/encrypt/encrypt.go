/**
 * @Author: spruce
 * @Date: 2026-07-06
 * @Desc: 全功能安全加解密套件（哈希摘要、Bcrypt 口令、AES 全模式、ChaCha20、DES/3DES、RSA 签名加密、Hashids 混淆）
 */

package encrypt

import (
	"bytes"
	"crypto"
	"crypto/aes"
	"crypto/cipher"
	"crypto/des"
	"crypto/hkdf"
	"crypto/hmac"
	"crypto/md5"
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"fmt"
	"hash"
	"io"

	"github.com/speps/go-hashids/v2"
	"golang.org/x/crypto/bcrypt"
	"golang.org/x/crypto/chacha20poly1305"
)

// ==========================================
// 一、哈希摘要与密钥派生 (MD5 / SHA / PBKDF2 / HKDF)
// ==========================================

// MD5 对字符串进行 MD5 加密 (基于 md5.Sum 计算，避免堆分配)
func MD5(str string) string {
	h := md5.Sum([]byte(str))
	return hex.EncodeToString(h[:])
}

// MD5to16 获取 16 位 MD5 摘要 (取 32 位 MD5 的中间 [8:24] 区间)
func MD5to16(str string) string {
	return MD5(str)[8:24]
}

// Sha256 使用 HMAC-SHA256 加密
func Sha256(data, secret string) string {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

// Sha512 使用 HMAC-SHA512 加密
func Sha512(data, secret string) string {
	h := hmac.New(sha512.New, []byte(secret))
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

// Sha1 使用 HMAC-SHA1 加密
func Sha1(data, secret string) string {
	h := hmac.New(sha1.New, []byte(secret))
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

// PBKDF2 基于口令的密钥派生 (RFC 8018，Go 标准库 crypto/pbkdf2)
func PBKDF2(str, salt string, iterations, keySize int) string {
	cipherText, err := pbkdf2.Key(sha256.New, str, []byte(salt), iterations, keySize)
	if err != nil {
		return ""
	}
	return fmt.Sprintf("%x", md5.Sum(cipherText))
}

// HKDF 密钥派生 (RFC 5869，Go 标准库 crypto/hkdf)
func HKDF(secret, salt []byte, info string, keyLength int) ([]byte, error) {
	return hkdf.Key(sha256.New, secret, salt, info, keyLength)
}

// ==========================================
// 二、Bcrypt 密码安全散列 (加盐自适应慢哈希)
// ==========================================

// bcryptMaxLen 是 bcrypt 密钥的最大字节数(72)。
// bcrypt 会静默截断超过 72 字节的密码，导致两个前缀相同的长密码被视为相同，
// 因此在加密与校验前统一拒绝超长密码，避免静默截断漏洞。
const bcryptMaxLen = 72

// BcryptHash 使用 bcrypt 对明文密码加密，返回密文哈希
func BcryptHash(password string) (string, error) {
	if len(password) > bcryptMaxLen {
		return "", errors.New("password too long: bcrypt accepts at most 72 bytes")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(hash), nil
}

// BcryptCompare 校验明文密码与密文哈希是否匹配
func BcryptCompare(hash, password string) bool {
	if len(password) > bcryptMaxLen {
		return false
	}
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)) == nil
}

// ==========================================
// 三、AES 对称加解密 (GCM / CBC / CTR / ECB)
// ==========================================

// HashKey32 将任意字符串哈希为 32 字节密钥（用于 AES-256）
func HashKey32(secret string) []byte {
	h := sha256.New()
	h.Write([]byte(secret))
	return h.Sum(nil)
}

// AESGCMEncrypt 配置中心专用：使用 AES-256-GCM 对明文字节切片加密，返回 base64 密文字符串
func AESGCMEncrypt(plaintext []byte, key []byte) (string, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	nonce := make([]byte, aesgcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}

	ciphertext := aesgcm.Seal(nonce, nonce, plaintext, nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

// AESGCMDecrypt 配置中心专用：使用 AES-256-GCM 对 base64 密文字符串解密，返回明文字节切片
func AESGCMDecrypt(base64Ciphertext string, key []byte) ([]byte, error) {
	data, err := base64.StdEncoding.DecodeString(base64Ciphertext)
	if err != nil {
		return nil, err
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	aesgcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	nonceSize := aesgcm.NonceSize()
	if len(data) < nonceSize {
		return nil, fmt.Errorf("ciphertext too short")
	}

	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := aesgcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, err
	}

	return plaintext, nil
}

// AESEncrypt 默认推荐使用现代 AEAD 认证加密 (AES-GCM 模式，自带防篡改校验与硬件加速)
func AESEncrypt(plainText, encryptKey string, additionalData ...[]byte) (string, error) {
	return AESEncryptGCM(plainText, encryptKey, additionalData...)
}

// AESDecrypt 默认使用现代 AEAD 认证加密 (AES-GCM 模式)
func AESDecrypt(cipherText, encryptKey string, additionalData ...[]byte) (string, error) {
	return AESDecryptGCM(cipherText, encryptKey, additionalData...)
}

// AESEncryptGCM AES GCM Encrypt — 密文格式: base64(nonce + ciphertext + tag)
// encryptKey 长度必须是 16 (AES-128)、24 (AES-192) 或 32 (AES-256) 字节
func AESEncryptGCM(plainText, encryptKey string, additionalData ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	nonce := make([]byte, aesGCM.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}

	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}

	cipherBytes := aesGCM.Seal(nonce, nonce, []byte(plainText), aad)
	return base64.StdEncoding.EncodeToString(cipherBytes), nil
}

// AESDecryptGCM AES GCM Decrypt — 自动从密文前提取 nonce，并校验数据完整性与解密
func AESDecryptGCM(cipherText, encryptKey string, additionalData ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	data, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		data, err = base64.URLEncoding.DecodeString(cipherText)
		if err != nil {
			data, err = base64.RawURLEncoding.DecodeString(cipherText)
			if err != nil {
				return "", err
			}
		}
	}

	nonceSize := aesGCM.NonceSize()
	if len(data) < nonceSize+aesGCM.Overhead() {
		return "", errors.New("cipherText too short")
	}

	nonce, cipherBytes := data[:nonceSize], data[nonceSize:]

	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}

	plainBytes, err := aesGCM.Open(nil, nonce, cipherBytes, aad)
	if err != nil {
		return "", fmt.Errorf("aes gcm decrypt failed: %w", err)
	}

	return string(plainBytes), nil
}

// AES256GCMEncrypt AES-256-GCM 加密，强制要求 32 字节(256 bit)密钥
func AES256GCMEncrypt(plainText, encryptKey string, additionalData ...[]byte) (string, error) {
	if len(encryptKey) != 32 {
		return "", errors.New("AES-256 requires a 32-byte (256-bit) key")
	}
	return AESEncryptGCM(plainText, encryptKey, additionalData...)
}

// AES256GCMDecrypt AES-256-GCM 解密，强制要求 32 字节(256 bit)密钥
func AES256GCMDecrypt(cipherText, encryptKey string, additionalData ...[]byte) (string, error) {
	if len(encryptKey) != 32 {
		return "", errors.New("AES-256 requires a 32-byte (256-bit) key")
	}
	return AESDecryptGCM(cipherText, encryptKey, additionalData...)
}

// AESEncryptCBC AES CBC 模式加密 (Cipher Block Chaining，随机 IV，密文格式: base64(iv + ciphertext))
func AESEncryptCBC(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	blockMode := cipher.NewCBCEncrypter(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.CryptBlocks(cipherText, originStr)

	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// AESDecryptCBC AES CBC 模式解密 — 自动从密文前提取 iv
func AESDecryptCBC(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("iv length mismatch")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}
	if len(encrypted)%blockSize != 0 {
		return "", errors.New("cipherText is not a multiple of the block size")
	}

	blockModel := cipher.NewCBCDecrypter(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.CryptBlocks(originStr, encrypted)
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// AESEncryptCTR CTR 计数器流加密模式
func AESEncryptCTR(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]

	originStr := []byte(plainText)
	blockMode := cipher.NewCTR(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.XORKeyStream(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// AESDecryptCTR CTR 模式解密 — 自动从密文前提取 iv
func AESDecryptCTR(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("iv length mismatch")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}

	blockModel := cipher.NewCTR(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.XORKeyStream(originStr, encrypted)
	return string(originStr), nil
}

// AESEncryptECB ECB 模式加密 (不安全，仅用于兼容老旧协议)
func AESEncryptECB(plainText, encryptKey string) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)
	cipherText := make([]byte, len(originStr))
	for bs, be := 0, blockSize; bs < len(originStr); bs, be = bs+blockSize, be+blockSize {
		block.Encrypt(cipherText[bs:be], originStr[bs:be])
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

// AESDecryptECB ECB 模式解密
func AESDecryptECB(cipherText, encryptKey string) (string, error) {
	block, err := aes.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := make([]byte, len(baseByte))
	for bs, be := 0, blockSize; bs < len(baseByte); bs, be = bs+blockSize, be+blockSize {
		block.Decrypt(originStr[bs:be], baseByte[bs:be])
	}
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// ==========================================
// 四、ChaCha20-Poly1305 认证加密 (RFC 8439)
// ==========================================

// ChaCha20Poly1305Encrypt 现代高性能 AEAD 认证加密 (RFC 8439)
func ChaCha20Poly1305Encrypt(plainText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.New(encryptKey)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	cipherBytes := aead.Seal(nonce, nonce, []byte(plainText), aad)
	return base64.StdEncoding.EncodeToString(cipherBytes), nil
}

// ChaCha20Poly1305Decrypt ChaCha20-Poly1305 解密
func ChaCha20Poly1305Decrypt(cipherText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.New(encryptKey)
	if err != nil {
		return "", err
	}
	data, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		data, err = base64.URLEncoding.DecodeString(cipherText)
		if err != nil {
			data, err = base64.RawURLEncoding.DecodeString(cipherText)
			if err != nil {
				return "", err
			}
		}
	}
	nonceSize := aead.NonceSize()
	if len(data) < nonceSize+aead.Overhead() {
		return "", errors.New("cipherText too short")
	}
	nonce, cipherBytes := data[:nonceSize], data[nonceSize:]
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	plainBytes, err := aead.Open(nil, nonce, cipherBytes, aad)
	if err != nil {
		return "", fmt.Errorf("chacha20poly1305 decrypt failed: %w", err)
	}
	return string(plainBytes), nil
}

// XChaCha20Poly1305Encrypt 扩展 Nonce (192-bit / 24 字节) AEAD 变体
func XChaCha20Poly1305Encrypt(plainText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.NewX(encryptKey)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	cipherBytes := aead.Seal(nonce, nonce, []byte(plainText), aad)
	return base64.StdEncoding.EncodeToString(cipherBytes), nil
}

// XChaCha20Poly1305Decrypt 解密
func XChaCha20Poly1305Decrypt(cipherText string, encryptKey []byte, additionalData ...[]byte) (string, error) {
	aead, err := chacha20poly1305.NewX(encryptKey)
	if err != nil {
		return "", err
	}
	data, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		data, err = base64.URLEncoding.DecodeString(cipherText)
		if err != nil {
			data, err = base64.RawURLEncoding.DecodeString(cipherText)
			if err != nil {
				return "", err
			}
		}
	}
	nonceSize := aead.NonceSize()
	if len(data) < nonceSize+aead.Overhead() {
		return "", errors.New("cipherText too short")
	}
	nonce, cipherBytes := data[:nonceSize], data[nonceSize:]
	var aad []byte
	if len(additionalData) > 0 {
		aad = additionalData[0]
	}
	plainBytes, err := aead.Open(nil, nonce, cipherBytes, aad)
	if err != nil {
		return "", fmt.Errorf("xchacha20poly1305 decrypt failed: %w", err)
	}
	return string(plainBytes), nil
}

// ==========================================
// 五、DES / 3DES (传统兼容)
// ==========================================

// DESEncrypt DES CBC Encrypt — 密文格式: base64(iv + ciphertext)
func DESEncrypt(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]
	blockMode := cipher.NewCBCEncrypter(block, ivValue)

	cipherText := make([]byte, len(originStr))
	blockMode.CryptBlocks(cipherText, originStr)

	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// DESDecrypt DES CBC Decrypt — 自动从密文前提取 iv
func DESDecrypt(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}
	if len(encrypted)%blockSize != 0 {
		return "", errors.New("cipherText is not a multiple of the block size")
	}

	blockModel := cipher.NewCBCDecrypter(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.CryptBlocks(originStr, encrypted)

	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// DESEncryptECB DES ECB Encrypt (不安全)
func DESEncryptECB(plainText, encryptKey string) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)
	cipherText := make([]byte, len(originStr))
	for bs, be := 0, blockSize; bs < len(originStr); bs, be = bs+blockSize, be+blockSize {
		block.Encrypt(cipherText[bs:be], originStr[bs:be])
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

// DESDecryptECB DES ECB Decrypt
func DESDecryptECB(cipherText, encryptKey string) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := make([]byte, len(baseByte))
	for bs, be := 0, blockSize; bs < len(baseByte); bs, be = bs+blockSize, be+blockSize {
		block.Decrypt(originStr[bs:be], baseByte[bs:be])
	}
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// DESEncryptCTR DES CTR Encrypt — 密文格式: base64(iv + ciphertext)
func DESEncryptCTR(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]

	originStr := []byte(plainText)
	blockMode := cipher.NewCTR(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.XORKeyStream(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// DESDecryptCTR DES CTR Decrypt — 自动从密文前提取 iv
func DESDecryptCTR(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}

	blockModel := cipher.NewCTR(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.XORKeyStream(originStr, encrypted)
	return string(originStr), nil
}

// DES3Encrypt 3DES CBC Encrypt — 密文格式: base64(iv + ciphertext)
func DES3Encrypt(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]
	blockMode := cipher.NewCBCEncrypter(block, ivValue)

	cipherText := make([]byte, len(originStr))
	blockMode.CryptBlocks(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// DES3Decrypt 3DES CBC Decrypt — 自动从密文前提取 iv
func DES3Decrypt(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}
	if len(encrypted)%blockSize != 0 {
		return "", errors.New("cipherText is not a multiple of the block size")
	}

	blockModel := cipher.NewCBCDecrypter(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.CryptBlocks(originStr, encrypted)

	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// DES3EncryptECB 3DES ECB Encrypt (不安全)
func DES3EncryptECB(plainText, encryptKey string) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()
	originStr := PKCS5Padding([]byte(plainText), blockSize)
	cipherText := make([]byte, len(originStr))
	for bs, be := 0, blockSize; bs < len(originStr); bs, be = bs+blockSize, be+blockSize {
		block.Encrypt(cipherText[bs:be], originStr[bs:be])
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

// DES3DecryptECB 3DES ECB Decrypt
func DES3DecryptECB(cipherText, encryptKey string) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}

	blockSize := block.BlockSize()
	originStr := make([]byte, len(baseByte))
	for bs, be := 0, blockSize; bs < len(baseByte); bs, be = bs+blockSize, be+blockSize {
		block.Decrypt(originStr[bs:be], baseByte[bs:be])
	}
	output, err := PKCS5UnPadding(originStr)
	if err != nil {
		return "", err
	}
	return string(output), nil
}

// DES3EncryptCTR 3DES CTR Encrypt — 密文格式: base64(iv + ciphertext)
func DES3EncryptCTR(plainText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	var ivValue []byte
	if len(iv) > 0 {
		ivValue = iv[0]
	} else {
		ivValue = make([]byte, blockSize)
		if _, err := io.ReadFull(rand.Reader, ivValue); err != nil {
			return "", err
		}
	}
	if len(ivValue) < blockSize {
		return "", errors.New("need a multiple of the block size")
	}
	ivValue = ivValue[:blockSize]

	originStr := []byte(plainText)
	blockMode := cipher.NewCTR(block, ivValue)
	cipherText := make([]byte, len(originStr))
	blockMode.XORKeyStream(cipherText, originStr)
	return base64.StdEncoding.EncodeToString(append(ivValue, cipherText...)), nil
}

// DES3DecryptCTR 3DES CTR Decrypt — 自动从密文前提取 iv
func DES3DecryptCTR(cipherText, encryptKey string, iv ...[]byte) (string, error) {
	block, err := des.NewTripleDESCipher([]byte(encryptKey))
	if err != nil {
		return "", err
	}
	blockSize := block.BlockSize()

	baseByte, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return "", err
	}
	if len(baseByte) < blockSize*2 {
		return "", errors.New("cipherText too short")
	}

	var ivValue []byte
	var encrypted []byte
	if len(iv) > 0 {
		ivValue = iv[0]
		if len(ivValue) < blockSize {
			return "", errors.New("need a multiple of the block size")
		}
		ivValue = ivValue[:blockSize]
		encrypted = baseByte
	} else {
		ivValue = baseByte[:blockSize]
		encrypted = baseByte[blockSize:]
	}

	blockModel := cipher.NewCTR(block, ivValue)
	originStr := make([]byte, len(encrypted))
	blockModel.XORKeyStream(originStr, encrypted)
	return string(originStr), nil
}

// ==========================================
// 六、填充辅助方法
// ==========================================

func PKCS5Padding(src []byte, blockSize int) []byte {
	return PKCS7Padding(src, blockSize)
}

func PKCS5UnPadding(src []byte) ([]byte, error) {
	return PKCS7UnPadding(src)
}

func PKCS7Padding(src []byte, blockSize int) []byte {
	padding := blockSize - len(src)%blockSize
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(src, padText...)
}

func PKCS7UnPadding(src []byte) ([]byte, error) {
	length := len(src)
	if length == 0 {
		return src, errors.New("invalid data len")
	}
	unPadding := int(src[length-1])
	if unPadding < 1 || unPadding > length {
		return src, errors.New("invalid padding")
	}
	return src[:(length - unPadding)], nil
}

func ZerosPadding(src []byte, blockSize int) []byte {
	paddingCount := blockSize - len(src)%blockSize
	if paddingCount == 0 {
		return src
	}
	return append(src, bytes.Repeat([]byte{0}, paddingCount)...)
}

func ZerosUnPadding(src []byte) ([]byte, error) {
	for i := len(src) - 1; i >= 0; i-- {
		if src[i] != 0 {
			return src[:i+1], nil
		}
	}
	return nil, nil
}

// ==========================================
// 七、RSA 非对称加密与签名 (RSASecurity)
// ==========================================

var (
	ErrDataToLarge = errors.New("message too long for RSA public key size")
	ErrDataLen     = errors.New("data length error")
	ErrPublicKey   = errors.New("get public key error")
	ErrPrivateKey  = errors.New("get private key error")
	ErrSignature   = errors.New("rsa signature verification failed")
)

// rsaHash 签名/验签使用的哈希算法，固定 SHA-256。
const rsaHash = crypto.SHA256

func newHash() hash.Hash {
	return sha256.New()
}

// NewRSASecurity 创建一个新的 RSASecurity 实例
func NewRSASecurity() *RSASecurity {
	return &RSASecurity{}
}

type RSASecurity struct {
	pubStr string          // 公钥字符串
	priStr string          // 私钥字符串
	pubKey *rsa.PublicKey  // 公钥
	priKey *rsa.PrivateKey // 私钥
}

// SetPublicKey 设置公钥
func (s *RSASecurity) SetPublicKey(pubStr string) (err error) {
	s.pubStr = pubStr
	s.pubKey, err = s.GetPublicKey()
	return err
}

// SetPrivateKey 设置私钥
func (s *RSASecurity) SetPrivateKey(priStr string) (err error) {
	s.priStr = priStr
	s.priKey, err = s.GetPrivateKey()
	return err
}

// GetPrivateKey 获得私钥 *rsa.PrivateKey
func (s *RSASecurity) GetPrivateKey() (*rsa.PrivateKey, error) {
	return getPriKey([]byte(s.priStr))
}

// GetPublicKey 获得公钥 *rsa.PublicKey
func (s *RSASecurity) GetPublicKey() (*rsa.PublicKey, error) {
	return getPubKey([]byte(s.pubStr))
}

// PubKeyEncrypt 公钥加密 (OAEP，推荐用于加密场景；明文超长自动分块)
func (s *RSASecurity) PubKeyEncrypt(input string) (string, error) {
	if s.pubKey == nil {
		return "", errors.New(`please set the public key in advance`)
	}
	output := bytes.NewBuffer(nil)
	if err := pubKeyEncryptOAEP(s.pubKey, bytes.NewReader([]byte(input)), output); err != nil {
		return "", err
	}
	binaryByte, err := io.ReadAll(output)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(binaryByte), nil
}

// PriKeyDecrypt 私钥解密 (对应 PubKeyEncrypt 的 OAEP 加密)
func (s *RSASecurity) PriKeyDecrypt(input string) (string, error) {
	if s.priKey == nil {
		return "", errors.New(`please set the private key in advance`)
	}
	if input == "" {
		return "", errors.New(`input is empty`)
	}
	base64Input, err := base64.StdEncoding.DecodeString(input)
	if err != nil {
		return "", err
	}
	output := bytes.NewBuffer(nil)
	if err := priKeyDecryptOAEP(s.priKey, bytes.NewReader(base64Input), output); err != nil {
		return "", err
	}
	binaryByte, err := io.ReadAll(output)
	if err != nil {
		return "", err
	}
	return string(binaryByte), nil
}

// PriKeyEncrypt 私钥签名——对消息做 SHA-256 + PKCS1v15 签名，返回 base64 签名串
func (s *RSASecurity) PriKeyEncrypt(input string) (string, error) {
	if s.priKey == nil {
		return "", errors.New(`please set the private key in advance`)
	}
	sig, err := priKeySign(s.priKey, []byte(input))
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(sig), nil
}

// PubKeyDecrypt 历史签名校验兼容接口
func (s *RSASecurity) PubKeyDecrypt(input string) (string, error) {
	if s.pubKey == nil {
		return "", errors.New(`please set the public key in advance`)
	}
	if _, err := base64.StdEncoding.DecodeString(input); err != nil {
		return "", err
	}
	return "", errors.New("PubKeyDecrypt is deprecated: use Verify(message, signature)")
}

// Verify 用公钥校验消息与签名是否匹配 (校验 PriKeyEncrypt 产出的签名)
func (s *RSASecurity) Verify(message, signature string) error {
	if s.pubKey == nil {
		return errors.New(`please set the public key in advance`)
	}
	sig, err := base64.StdEncoding.DecodeString(signature)
	if err != nil {
		return err
	}
	return pubKeyVerify(s.pubKey, []byte(message), sig)
}

func getPubKey(publicKey []byte) (*rsa.PublicKey, error) {
	block, _ := pem.Decode(publicKey)
	if block == nil {
		return nil, errors.New("get public key error")
	}
	pub, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	rsaPub, ok := pub.(*rsa.PublicKey)
	if !ok {
		return nil, ErrPublicKey
	}
	return rsaPub, nil
}

func getPriKey(privateKey []byte) (*rsa.PrivateKey, error) {
	block, _ := pem.Decode(privateKey)
	if block == nil {
		return nil, errors.New("get private key error")
	}
	if pri, err := x509.ParsePKCS1PrivateKey(block.Bytes); err == nil {
		return pri, nil
	}
	pri2, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	rsaPri, ok := pri2.(*rsa.PrivateKey)
	if !ok {
		return nil, ErrPrivateKey
	}
	return rsaPri, nil
}

func oaepMaxBlockLen(pub *rsa.PublicKey) int {
	k := (pub.N.BitLen() + 7) / 8
	return k - 2*newHash().Size() - 2
}

func keyByteLen(pub *rsa.PublicKey) int {
	return (pub.N.BitLen() + 7) / 8
}

func pubKeyEncryptOAEP(pub *rsa.PublicKey, in io.Reader, out io.Writer) error {
	chunk := oaepMaxBlockLen(pub)
	if chunk <= 0 {
		return ErrDataToLarge
	}
	buf := make([]byte, chunk)
	for {
		n, err := in.Read(buf)
		if err != nil {
			if errors.Is(err, io.EOF) {
				return nil
			}
			return err
		}
		block, err := rsa.EncryptOAEP(newHash(), rand.Reader, pub, buf[:n], nil)
		if err != nil {
			return err
		}
		if _, err = out.Write(block); err != nil {
			return err
		}
	}
}

func priKeyDecryptOAEP(pri *rsa.PrivateKey, in io.Reader, out io.Writer) error {
	k := keyByteLen(&pri.PublicKey)
	buf := make([]byte, k)
	for {
		n, err := io.ReadFull(in, buf)
		if err != nil {
			if errors.Is(err, io.EOF) {
				return nil
			}
			if errors.Is(err, io.ErrUnexpectedEOF) {
				if n == 0 {
					return nil
				}
				block, derr := rsa.DecryptOAEP(newHash(), rand.Reader, pri, buf[:n], nil)
				if derr != nil {
					return derr
				}
				_, err = out.Write(block)
				return err
			}
			return err
		}
		block, err := rsa.DecryptOAEP(newHash(), rand.Reader, pri, buf[:n], nil)
		if err != nil {
			return err
		}
		if _, err = out.Write(block); err != nil {
			return err
		}
	}
}

func priKeySign(pri *rsa.PrivateKey, message []byte) ([]byte, error) {
	h := newHash()
	if _, err := h.Write(message); err != nil {
		return nil, err
	}
	return rsa.SignPKCS1v15(rand.Reader, pri, rsaHash, h.Sum(nil))
}

func pubKeyVerify(pub *rsa.PublicKey, message, signature []byte) error {
	h := newHash()
	if _, err := h.Write(message); err != nil {
		return err
	}
	if err := rsa.VerifyPKCS1v15(pub, rsaHash, h.Sum(nil), signature); err != nil {
		return ErrSignature
	}
	return nil
}

// ==========================================
// 八、Hashids 混淆编解码 (数字 ID 防遍历)
// ==========================================

// HashID 封装 Hashids 实例
type HashID struct {
	h *hashids.HashID
}

// Hashids 创建一个 HashID 实例
func Hashids(salt string, minLength int, alphabet ...string) (*HashID, error) {
	hd := hashids.NewData()
	hd.Salt = salt
	hd.MinLength = minLength
	if len(alphabet) > 0 && alphabet[0] != "" {
		hd.Alphabet = alphabet[0]
	}
	h, err := hashids.NewWithData(hd)
	if err != nil {
		return nil, err
	}
	return &HashID{h: h}, nil
}

func (hid *HashID) Encode(numbers ...int) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.Encode(numbers)
}

func (hid *HashID) EncodeInt64(numbers ...int64) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.EncodeInt64(numbers)
}

func (hid *HashID) Decode(hash string) ([]int, error) {
	if hid == nil || hid.h == nil {
		return nil, errors.New("hashid instance is nil")
	}
	return hid.h.DecodeWithError(hash)
}

func (hid *HashID) DecodeInt64(hash string) ([]int64, error) {
	if hid == nil || hid.h == nil {
		return nil, errors.New("hashid instance is nil")
	}
	return hid.h.DecodeInt64WithError(hash)
}

func (hid *HashID) EncodeHex(hexStr string) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.EncodeHex(hexStr)
}

func (hid *HashID) DecodeHex(hash string) (string, error) {
	if hid == nil || hid.h == nil {
		return "", errors.New("hashid instance is nil")
	}
	return hid.h.DecodeHex(hash)
}

// HashidsEncode 便捷函数：将一组 int64 数字编码为 Hashid
func HashidsEncode(salt string, minLength int, numbers ...int64) (string, error) {
	h, err := Hashids(salt, minLength)
	if err != nil {
		return "", err
	}
	return h.EncodeInt64(numbers...)
}

// HashidsDecode 便捷函数：将 Hashid 解码为一组 int64 数字
func HashidsDecode(salt string, minLength int, hash string) ([]int64, error) {
	h, err := Hashids(salt, minLength)
	if err != nil {
		return nil, err
	}
	return h.DecodeInt64(hash)
}
